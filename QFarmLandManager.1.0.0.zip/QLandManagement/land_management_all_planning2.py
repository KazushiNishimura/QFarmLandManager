# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
#画面構成は↓の番号を変えるだけでOK!
from land_management_all_planning3_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import random
import time
import math



class Dialog(QDialog,Ui_Dialog):


    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.list_borrower=[]
        self.list_lender=[]
        self.list_exclusion=[]
        #self.ui.rbtn_all.setChecked(1)


        #self.populate_tablewidget_farmers()
        #self.populate_tablewidget_farmers_area()
        self.populate_tablewidget_configuration()


        #self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
        #self.connect(self.ui.btn_calc_route, SIGNAL("clicked()"),self.calc_route)
        #self.connect(self.ui.btn_show_route,SIGNAL("clicked()"),self.show_route)
        #self.connect(self.ui.btn_start,SIGNAL("clicked()"),self.start_edit)
        #self.connect(self.ui.btn_select_farmer, SIGNAL("clicked()"),self.select_farmer)
        #self.connect(self.ui.btn_run,SIGNAL("clicked()"),self.run_main_select)
        #self.connect(self.ui.btn_re_calc,SIGNAL("clicked()"),self.re_calc)
        #self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_info_selected)
        self.connect(self.ui.btn_run,SIGNAL("clicked()"),self.run_planning)
        self.connect(self.ui.btn_renderer,SIGNAL("clicked()"),self.renderer)
        self.connect(self.ui.btn_select_borrower,SIGNAL("clicked()"),self.open_select_borrower)
        self.connect(self.ui.btn_select_lender,SIGNAL("clicked()"),self.open_select_lender)
        self.connect(self.ui.btn_select_exclusion,SIGNAL("clicked()"),self.open_select_exclusion)
        self.connect(self.ui.btn_show_scattered,SIGNAL("clicked()"),self.show_scattered)
        #self.connect(self.ui.btn_delete_borrower,SIGNAL("clicked()"),self.delete_borrower)

#     def delete_borrower(self):
#         row_count=self.ui.tablewidget_configuration.rowCount()
#         for i in range(row_count):
#             try:
#                 if self.ui.tablewidget_configuration.item(i,0).checkState()==Qt.Checked:
#                     self.ui.tablewidget_configuration.removeRow(i)
#             except:
#                 pass

    def show_scattered(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmers.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmers.item(i,0).checkState()==Qt.Checked:
                list_farmers.append((self.ui.tablewidget_farmers.item(i,1).text()))


        self.populate_tablewidget_farmers_area(list_farmers)

    def open_select_exclusion(self):
        from land_management_all_select_exclusion import Dialog
        self.dlg=Dialog(self)
        self.dlg.show()
        self.dlg.exec_()
        self.populate_tablewidget_exclusion()

    def open_select_lender(self):
        from land_management_all_select_lender import Dialog
        self.dlg=Dialog(self)
        self.dlg.show()
        self.dlg.exec_()
        self.populate_tablewidget_lender()

    def open_select_borrower(self):
        from land_management_all_select_borrower import Dialog
        self.dlg=Dialog(self)
        self.dlg.show()
        self.dlg.exec_()
        self.populate_tablewidget_configuration()


    def get_list_district(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select district
                        from farmland_table
                        group by district"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows


    def populate_tablewidget_exclusion(self):
        self.ui.tablewidget_exclusion.clear()
        self.ui.tablewidget_exclusion.setRowCount(0)
        self.ui.tablewidget_exclusion.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"耕作者",u"面積小計"]
        self.ui.tablewidget_exclusion.setColumnCount(len(headers))
        self.ui.tablewidget_exclusion.setHorizontalHeaderLabels(headers)
        #list_farmers=self.make_farmers_list()
        #print list_farmer
        i=0
        for farmer in self.list_exclusion:

#                 chk =QTableWidgetItem()
#                 chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
#                 chk.setCheckState(Qt.Unchecked)
            self.ui.tablewidget_exclusion.insertRow(i)
            #self.ui.tablewidget_configuration.setItem(i,0,chk)
            #self.ui.tablewidget_configuration.setItem(i,1,chk)
            #self.ui.tablewidget_exclusion.setItem(i,1,QTableWidgetItem(item[0]))
            self.ui.tablewidget_exclusion.setItem(i,0,QTableWidgetItem(farmer[0]))
            self.ui.tablewidget_exclusion.setItem(i,1,QTableWidgetItem(farmer[1]))
            i=i+1
        #self.sum_area()


        self.ui.tablewidget_configuration.resizeColumnsToContents()

    def populate_tablewidget_lender(self):
        self.ui.tablewidget_lender.clear()
        self.ui.tablewidget_lender.setRowCount(0)
        self.ui.tablewidget_lender.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"エリア",u"貸出希望面積"]
        self.ui.tablewidget_lender.setColumnCount(len(headers))
        self.ui.tablewidget_lender.setHorizontalHeaderLabels(headers)
        #list_farmers=self.make_farmers_list()
        #print list_farmer
        i=0
        for item in self.sumation_lender():
#                 chk =QTableWidgetItem()
#                 chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
#                 chk.setCheckState(Qt.Unchecked)
            self.ui.tablewidget_lender.insertRow(i)
            #self.ui.tablewidget_configuration.setItem(i,0,chk)
            #self.ui.tablewidget_configuration.setItem(i,1,chk)
            self.ui.tablewidget_lender.setItem(i,0,QTableWidgetItem(item[0]))
            self.ui.tablewidget_lender.setItem(i,1,QTableWidgetItem("{:,.0f}".format(item[1])))
            i=i+1
        #self.sum_area()



        self.ui.tablewidget_lender.resizeColumnsToContents()

    def populate_tablewidget_configuration(self):
        self.ui.tablewidget_configuration.clear()
        self.ui.tablewidget_configuration.setRowCount(0)
        self.ui.tablewidget_configuration.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"割当順",u"担い手",u"エリア",u"目標面積"]
        self.ui.tablewidget_configuration.setColumnCount(len(headers))
        self.ui.tablewidget_configuration.setHorizontalHeaderLabels(headers)
        #list_farmers=self.make_farmers_list()
        #print list_farmer
        i=0
        for farmer in self.list_borrower:
            for item in self.sumation_by_district(farmer[0]):
#                 chk =QTableWidgetItem()
#                 chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
#                 chk.setCheckState(Qt.Unchecked)
                self.ui.tablewidget_configuration.insertRow(i)
                #self.ui.tablewidget_configuration.setItem(i,0,chk)
                #self.ui.tablewidget_configuration.setItem(i,1,chk)
                self.ui.tablewidget_configuration.setItem(i,1,QTableWidgetItem(item[0]))
                self.ui.tablewidget_configuration.setItem(i,2,QTableWidgetItem(item[1]))
                self.ui.tablewidget_configuration.setItem(i,3,QTableWidgetItem("{:,.0f}".format(item[2])))
                i=i+1
        #self.sum_area()

        #個別経営の設定
        for district in self.get_list_district():
            self.ui.tablewidget_configuration.insertRow(i)
            #self.ui.tablewidget_configuration.setItem(i,0,chk)
            #self.ui.tablewidget_configuration.setItem(i,1,chk)
            self.ui.tablewidget_configuration.setItem(i,1,QTableWidgetItem(u"その他個別経営"))
            self.ui.tablewidget_configuration.setItem(i,2,QTableWidgetItem(district[0]))
            #self.ui.tablewidget_configuration.setItem(i,3,QTableWidgetItem("{:,.0f}".format(item[2])))
            i=i+1

        self.ui.tablewidget_configuration.resizeColumnsToContents()


    def sumation_lender(self):
        #count_lender=0
        dist_area=[]
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        for district in self.get_list_district():
            sumation_area=0
            count_render=0
            for farmer in self.list_lender:
                sql_string="""select total(land_area)
                        from farmland_table
                        where farm_name=? and district=?
                        group by farm_name , district """
                cursor=db.cursor()
                cursor.execute(sql_string,(farmer[0],district[0]))
                row=cursor.fetchone()
                try:
                    sumation_area=sumation_area+row[0]
                except:
                    pass
            dist_area.append((district[0],sumation_area))

        return dist_area

    def sumation_by_district(self,farmer):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql_string="""select farm_name ,district,total(land_area)
                        from farmland_table
                        where farm_name=?
                        group by farm_name , district """
        cursor=db.cursor()
        cursor.execute(sql_string,(farmer,))
        rows=cursor.fetchall()
        return rows

    #全域調整
    def run_planning(self):
        #ルートはベースルートを参照。都度、ルート検索は行わない
        scenario=self.ui.lineedit_scenario.text()
#         self.run_subdistrict()
#         self.run_main()
        self.make_solution()
        result_table=self.get_result_table()
        query_string=""" "scenario" = '""" + self.ui.lineedit_scenario.text() + """' """
        pyqgis_processing.set_query(result_table, query_string)
        self.populate_tablewidget_farmers(scenario)
        self.renderer()



    #圃区巡回経路探索
    def run_subdistrict(self):
        from land_management_tsp_subdistrict import City
        from land_management_tsp_subdistrict import district
        from land_management_tsp_subdistrict import TourManager
        from land_management_tsp_subdistrict import OPT_2
        from land_management_tsp_subdistrict import Run_Greedy
        from land_management_tsp_subdistrict import re_define_start

        start = time.time()
        tourmanager=TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="subdistrict_table":
                layer1=lyr
            elif lyr.name()=="area":
                layer2=lyr

        list_area=[]
        for feature in layer2.getFeatures():
            list_area.append([feature[feature.fieldNameIndex('area_name')],feature[feature.fieldNameIndex('route')]])
        list_area.sort(key=lambda x:x[1])
      #  print list_area

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        for feature in layer1.getFeatures():
            city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('district')],feature.id())
            tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            #print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        #print "Finished"
        #print "Final distance: " + str(pop.getFittest().getDistance())
       # print "Final distance: " #+ str(besttour.getDistance())
       # print "Solution:"

        rds= re_define_start(besttour)
        besttour=rds.OperateRDS()

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        route_name=self.ui.lineedit_scenario.text()
        sql=""" insert into route_table_sub (subdistrict_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

    #耕区巡回経路
    def run_main(self):
        from land_management_tsp_main import City
        from land_management_tsp_main import district
        from land_management_tsp_main import TourManager
        from land_management_tsp_main import OPT_2
        from land_management_tsp_main import Run_Greedy
        start = time.time()

        tourmanager = TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
            elif lyr.name()=="subdistrict_table":
                layer2=lyr
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql="select subdistrict_id,route,scenario from route_table_sub where scenario=?"
        cursor.execute(sql,(self.ui.lineedit_scenario.text(),))
        rows=cursor.fetchall()
        list_area=[]
        for row in rows:
            list_area.append((row[0],row[1],row[2]))


        list_area.sort(key=lambda x:x[1])

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        #layer1=iface.activeLayer()
        for feature in layer1.getFeatures():
            city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('subdistrict_code')],feature.id())
            tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
          #  print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
       # print "Finished"
       # print "Final distance: " #+ str(besttour.getDistance())
       # print "Solution:"


        route_name=self.ui.lineedit_scenario.text()
        sql=""" insert into route_table2 (farmland_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()


    def make_solution(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        #ルート名を取得
        route_name="base"
        #選択されているルートで対象となっているエリアを抽出する
        cursor=db.cursor()
        sql="""select farmland_table.district from farmland_table  inner join route_table2 on farmland_table.id=route_table2.farmland_id
        where route_table2.scenario=? """
        cursor.execute(sql,(route_name,))
        rows=cursor.fetchall()
        list_area=[]
        for row in rows:
            if row[0] not in list_area:
                list_area.append(row[0])
        list_area.sort()
        #print list_area
        #耕作者・エリア別の面積はテーブルウィジェットから取得→クエリで抽出し直す
        list_farmer=[]
        for area in list_area:
            cursor=db.cursor()
            #sql="select district ,farm_name from farmland_table where district=?"
            sql="""select farmland_table.district,farmland_table.farm_name from farmland_table
            inner join route_table2 on farmland_table.id=route_table2.farmland_id
            where farmland_table.district=? and route_table2.scenario=?  """
            cursor.execute(sql,(area[0],route_name))
            rows=cursor.fetchall()
            for row in rows:
                if  row  not in list_farmer:
                    list_farmer.append(row)
        #print list_farmer
        #担い手のエリア別設定面積をテーブルウィジェトから取得
        list_farmer_area=[]
        row_count=self.ui.tablewidget_configuration.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_configuration.item(i,1).text()!=u"その他個別経営":
                #print self.ui.tablewidget_configuration.item(i,1).text()
                list_farmer_area.append((self.ui.tablewidget_configuration.item(i,0).text(),self.ui.tablewidget_configuration.item(i,1).text(),self.ui.tablewidget_configuration.item(i,2).text(),self.convert_text_to_int(self.ui.tablewidget_configuration.item(i,3).text())))
            else:
                list_farmer_area.append((self.ui.tablewidget_configuration.item(i,0).text(),self.ui.tablewidget_configuration.item(i,1).text(),self.ui.tablewidget_configuration.item(i,2).text(),0))
#         for item in list_farmer:
#             cursor=db.cursor()
#             sql="""select total (farmland_table.land_area) from farmland_table
#             inner join route_table2 on farmland_table.id=route_table2.farmland_id
#             where farmland_table.district=? and farmland_table.farm_name=? and route_table2.scenario=?"""
#             value=(item[0],item[1],route_name)
#             cursor.execute(sql,value)
#             total=cursor.fetchmany(1)
#             list_farmer_area.append((item[0],item[1],total[0][0]))

        #検証用→クリア！
#         for item in list_farmer_area:
#             print item[0],item[1],item[2],item[3]

        for area in list_area:
            list_partial=filter(lambda x: x[2]==area, list_farmer_area)
            list_partial.sort(key=lambda x:x[0])
            district=area
            sql="""select farmland_table.farmland_code ,farmland_table.land_area,route_table2.route,farmland_table.farm_name from farmland_table inner join
            route_table2 on farmland_table.id = route_table2.farmland_id  where farmland_table.district=? and route_table2.scenario=? """
            cursor=db.cursor()
            cursor.execute(sql,(district,route_name))
            rows=cursor.fetchall()
            list_land=[]
            for row in rows:
                if self.check_category3(row[3])==False:
                    list_land.append(row)
            list_land.sort(key=lambda x:x[2])
            i=0
            for item in list_partial:
                if item[1] !=u"その他個別経営":
                    #検証用print
                    #print item[0],item[1],item[2],item[3]
                    farm_name=item[1]
                    farm_area=float(item[3])
                    area_count=0
                    while i <len(list_land):
                        if area_count>farm_area:
                            break
                        else:
        #                     print area
        #                     print farmer
        #                     print row[0]
                            #print list_land[i]
                            area_count=area_count+list_land[i][1]
                            #sql_update="update farmland_table set solution=? where farmland_code=?"
                            sql_insert="""insert into result_table ( scenario,farmland_code,farm_name) values(?,?,?) """
                            #db.execute(sql_update,(farm_name,list_land[i][0],))
                            db.execute(sql_insert,(self.ui.lineedit_scenario.text(),list_land[i][0],farm_name,))
                            i=i+1
                    db.commit()
                else:
                    list_others=self.get_others(area)
                    for farmer in list_others:
                        farm_name=farmer[0]
                        farm_area=float(farmer[1])
                        #criterion=farm_area
                        if farm_area<10000:
                            criterion=0.9*farm_area
                        elif farm_area<20000:
                            criterion=0.9*farm_area
                        elif farm_area<30000:
                            criterion=0.95*farm_area
                        else:
                            criterion=0.95*farm_area
                        area_count=0
                        while i <len(list_land):
                            #割当基準は再考
                           # if area_count>0.85*farm_area:
                            if area_count>criterion:
                                break
                            else:
            #                     print area
            #                     print farmer
            #                     print row[0]
                                #print list_land[i]
                                area_count=area_count+list_land[i][1]
                                #sql_update="update farmland_table set solution=? where farmland_code=?"
                                sql_insert="""insert into result_table ( scenario,farmland_code,farm_name) values(?,?,?) """
                                #db.execute(sql_update,(farm_name,list_land[i][0],))
                                db.execute(sql_insert,(self.ui.lineedit_scenario.text(),list_land[i][0],farm_name,))
                                i=i+1
                        db.commit()

        db.execute("insert into scenario_table (scenario) values(?)",(self.ui.lineedit_scenario.text(),))
        db.commit()


    def check_category(self,farmer):
        flag=False
        for item in self.list_borrower:
            if farmer==item[0]:
#                     print farmer
#                     print item[0]
                    flag=True

        return flag

    def check_category2(self,farmer):
        flag=False
        for item in self.list_lender:
            if farmer==item[0]:
#                     print farmer
#                     print item[0]
                    flag=True

        return flag

    def check_category3(self,farmer):
        flag=False
        for item in self.list_exclusion:
            if farmer==item[0]:
#                     print farmer
#                     print item[0]
                    flag=True

        return flag
    #対象エリアを限定して抽出する必要有り
    def get_others(self,district):
        #print "get_others"
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select farm_name ,total(land_area)
                        from farmland_table
                        where district=?
                        group by farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,(district,))
        rows=cursor.fetchall()
        list_others=[]
        for row in rows:
            #print row[0]
            if self.check_category(row[0])==False:
                if self.check_category2(row[0])==False:
                    if self.check_category3(row[0])==False:
                        list_others.append((row[0],row[1]))
                        #print row[0]
        return list_others


    def convert_text_to_int(self,text_int):
        try:
            return_int=int(text_int.replace(',',''))
        except:
            return_int=0

        return return_int

    def populate_tablewidget_farmers(self,scenario):
        self.ui.tablewidget_farmers.clear()
        self.ui.tablewidget_farmers.setRowCount(0)
        self.ui.tablewidget_farmers.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_farmers.setColumnCount(len(headers))
        self.ui.tablewidget_farmers.setHorizontalHeaderLabels(headers)
        list_farmers=self.make_farmers_list(scenario)
        #print list_farmer
        i=0
        for farmer in list_farmers:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_farmers.insertRow(i)
            self.ui.tablewidget_farmers.setItem(i,0,chk)
            self.ui.tablewidget_farmers.setItem(i,1,QTableWidgetItem(farmer[0]))
            self.ui.tablewidget_farmers.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[1])))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_farmers.resizeColumnsToContents()

    def make_farmers_list(self,scenario):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select result_table.farm_name ,total(farmland_table.land_area)
                        from farmland_table inner join result_table on farmland_table.farmland_code = result_table.farmland_code
                        where result_table.scenario=?
                        group by result_table.farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,(scenario,))
        rows=cursor.fetchall()

        return rows

    def renderer(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmers.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmers.item(i,0).checkState()==Qt.Checked:
                list_farmers.append((self.ui.tablewidget_farmers.item(i,1).text()))

        list_rule=[]
        for farmer in list_farmers:
            label_string=   farmer
            query_string= '\"result_table_farm_name\" ='+ '\''+ farmer +'\' '
            list_rule.append([label_string,query_string])

        farmland_table=pyqgis_processing.get_farmland_table()
        pyqgis_processing.renderer_map1(farmland_table, list_rule)
        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()

        self.populate_tablewidget_farmers_area_not_scattered(list_farmers)

    def get_result_table(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=='result_table':
                layer1=lyr
                return layer1
                break

    def populate_tablewidget_farmers_area(self,farmers_list):

        scenario=self.ui.lineedit_scenario.text()
        self.ui.tablewidget_farmers_area.clear()
        self.ui.tablewidget_farmers_area.setSortingEnabled(True)
        self.ui.tablewidget_farmers_area.setRowCount(0)
        headers=[u"耕作者名",u"エリア",u"現状面積小計",u"現状圃場分散度",u"調整案面積小計",u"調整案圃場分散度"]
        self.ui.tablewidget_farmers_area.setColumnCount(len(headers))
        self.ui.tablewidget_farmers_area.setHorizontalHeaderLabels(headers)
        list_farmers_area=self.make_farmers_area_list()
        #print list_farmer

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'圃場分散度計算中')
        max = len(list_farmers_area)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        i=0
        for farmer in list_farmers_area:
            pbar.setValue(process_counter)
            if farmer[0] in farmers_list:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_farmers_area.insertRow(i)
                self.ui.tablewidget_farmers_area.setItem(i,0,QTableWidgetItem(farmer[0]))
                self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem(farmer[1]))
                self.ui.tablewidget_farmers_area.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[2])))
                self.ui.tablewidget_farmers_area.setItem(i,3,QTableWidgetItem("{:,.0f}".format(self.calc_length(farmer[0], farmer[1], farmer[2]))))
                self.ui.tablewidget_farmers_area.setItem(i,4,QTableWidgetItem("{:,.0f}".format(self.sum_area_plan(scenario,farmer[0], farmer[1])[0])))
                self.ui.tablewidget_farmers_area.setItem(i,5,QTableWidgetItem("{:,.0f}".format(self.calc_length_plan(farmer[0], farmer[1], farmer[2]))))
                i=i+1
            process_counter=process_counter+1
        #self.sum_area()
        self.ui.tablewidget_farmers_area.resizeColumnsToContents()

    def populate_tablewidget_farmers_area_not_scattered(self,farmers_list):

        scenario=self.ui.lineedit_scenario.text()
        self.ui.tablewidget_farmers_area.clear()
        self.ui.tablewidget_farmers_area.setSortingEnabled(True)
        self.ui.tablewidget_farmers_area.setRowCount(0)
        headers=[u"耕作者名",u"エリア",u"現状面積小計",u"現状圃場分散度",u"調整案面積小計",u"調整案圃場分散度"]
        self.ui.tablewidget_farmers_area.setColumnCount(len(headers))
        self.ui.tablewidget_farmers_area.setHorizontalHeaderLabels(headers)
        list_farmers_area=self.make_farmers_area_list()
        #print list_farmer

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'圃場分散度計算中')
        max = len(list_farmers_area)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        i=0
        for farmer in list_farmers_area:
            pbar.setValue(process_counter)
            if farmer[0] in farmers_list:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_farmers_area.insertRow(i)
                self.ui.tablewidget_farmers_area.setItem(i,0,QTableWidgetItem(farmer[0]))
                self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem(farmer[1]))
                self.ui.tablewidget_farmers_area.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[2])))
                #self.ui.tablewidget_farmers_area.setItem(i,3,QTableWidgetItem("{:,.0f}".format(self.calc_length(farmer[0], farmer[1], farmer[2]))))
                self.ui.tablewidget_farmers_area.setItem(i,4,QTableWidgetItem("{:,.0f}".format(self.sum_area_plan(scenario,farmer[0], farmer[1])[0])))
                #self.ui.tablewidget_farmers_area.setItem(i,5,QTableWidgetItem("{:,.0f}".format(self.calc_length_plan(farmer[0], farmer[1], farmer[2]))))
                i=i+1
            process_counter=process_counter+1
        #self.sum_area()
        self.ui.tablewidget_farmers_area.resizeColumnsToContents()

    def make_farmers_area_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql_string="select farm_name,district,total(land_area) from farmland_table group by farm_name,district"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows

    def calc_length(self,farm_name,district,area):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('farm_name')] ==farm_name:
                if feature[feature.fieldNameIndex('district')] ==district:
                    land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)

        dist=0
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql_string=""" select  dist from dist_table where id_from=? and id_to=?"""

        for i in xrange(0,len(best_route)-2):
            land_from=best_route[i]
            land_to=best_route[i+1]
            id_from=land_from[1]
            id_to=land_to[1]
            query_row=(id_from,id_to)
            cursor=db.cursor()
            cursor.execute(sql_string,query_row)
            row=cursor.fetchone()
            if row is None:
                distance_x = abs(land_from[2]-land_to[2])
                distance_y = abs(land_from[3]-land_to[3])
                dist_part = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
                dist=dist+dist_part

        return dist/area*1000

#         from land_management_tsp1 import run_simple_tsp
#         farmland_table=pyqgis_processing.get_farmland_table()
#         land_list=[]
#         for feature in farmland_table.getFeatures():
#             if feature[feature.fieldNameIndex('farm_name')] ==farm_name:
#                 if feature[feature.fieldNameIndex('district')] ==district:
#                     land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#         best_route=run_simple_tsp(land_list)
#         qpoint=[]
#
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         crs = farmland_table.crs().authid()#toWkt()
#         geom = f.geometry()
#         return geom.length()/area*1000

    def sum_area_plan(self,scenario,farmer,district):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select total(farmland_table.land_area)
                        from farmland_table inner join result_table on farmland_table.farmland_code = result_table.farmland_code
                        where result_table.scenario=? and result_table.farm_name=? and farmland_table.district=?
                        group by result_table.farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,(scenario,farmer,district))
        row=cursor.fetchone()
        #print row

        return row

    def calc_length_plan(self,farm_name,district,area):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('result_table_farm_name')] ==farm_name:
                if feature[feature.fieldNameIndex('district')] ==district:
                    land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)

        dist=0
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql_string=""" select  dist from dist_table where id_from=? and id_to=?"""

        for i in xrange(0,len(best_route)-2):
            land_from=best_route[i]
            land_to=best_route[i+1]
            id_from=land_from[1]
            id_to=land_to[1]
            query_row=(id_from,id_to)
            cursor=db.cursor()
            cursor.execute(sql_string,query_row)
            row=cursor.fetchone()
            if row is None:
                distance_x = abs(land_from[2]-land_to[2])
                distance_y = abs(land_from[3]-land_to[3])
                dist_part = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
                dist=dist+dist_part

        return dist/area*1000
#         from land_management_tsp1 import run_simple_tsp
#         farmland_table=pyqgis_processing.get_farmland_table()
#         land_list=[]
#         for feature in farmland_table.getFeatures():
#             if feature[feature.fieldNameIndex('result_table_farm_name')] ==farm_name:
#                 if feature[feature.fieldNameIndex('district')] ==district:
#                     land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#         best_route=run_simple_tsp(land_list)
#         qpoint=[]
#
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         crs = farmland_table.crs().authid()#toWkt()
#         geom = f.geometry()
#         return geom.length()/area*1000
