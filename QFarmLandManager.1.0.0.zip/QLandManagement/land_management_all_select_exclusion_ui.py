# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_all_select_exclusion_ui.ui'
#
# Created: Mon Jul 02 15:30:36 2018
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(347, 470)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.tablewidget_farmer = QtGui.QTableWidget(Dialog)
        self.tablewidget_farmer.setObjectName(_fromUtf8("tablewidget_farmer"))
        self.tablewidget_farmer.setColumnCount(0)
        self.tablewidget_farmer.setRowCount(0)
        self.verticalLayout.addWidget(self.tablewidget_farmer)
        self.btn_select_exclusion = QtGui.QPushButton(Dialog)
        self.btn_select_exclusion.setObjectName(_fromUtf8("btn_select_exclusion"))
        self.verticalLayout.addWidget(self.btn_select_exclusion)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "除外設定", None))
        self.btn_select_exclusion.setText(_translate("Dialog", "決定", None))

