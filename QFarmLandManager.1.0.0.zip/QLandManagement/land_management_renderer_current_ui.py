# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_renderer_current_ui.ui'
#
# Created: Thu Feb 21 13:55:34 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(400, 431)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tablewidget_farmers = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_farmers.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tablewidget_farmers.setObjectName(_fromUtf8("tablewidget_farmers"))
        self.tablewidget_farmers.setColumnCount(0)
        self.tablewidget_farmers.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_farmers)
        self.btn_renderer = QtGui.QPushButton(self.groupBox_2)
        self.btn_renderer.setObjectName(_fromUtf8("btn_renderer"))
        self.verticalLayout_2.addWidget(self.btn_renderer)
        self.verticalLayout.addWidget(self.groupBox_2)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.groupBox_3)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.tablewidget_farmers_area = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_farmers_area.setObjectName(_fromUtf8("tablewidget_farmers_area"))
        self.tablewidget_farmers_area.setColumnCount(0)
        self.tablewidget_farmers_area.setRowCount(0)
        self.verticalLayout_3.addWidget(self.tablewidget_farmers_area)
        self.btn_show_scattered = QtGui.QPushButton(self.groupBox_3)
        self.btn_show_scattered.setObjectName(_fromUtf8("btn_show_scattered"))
        self.verticalLayout_3.addWidget(self.btn_show_scattered)
        self.verticalLayout.addWidget(self.groupBox_3)
        self.btn_show_route = QtGui.QPushButton(Dialog)
        self.btn_show_route.setObjectName(_fromUtf8("btn_show_route"))
        self.verticalLayout.addWidget(self.btn_show_route)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "耕作者毎の色分け", None))
        self.groupBox_2.setTitle(_translate("Dialog", "耕作者一覧", None))
        self.btn_renderer.setText(_translate("Dialog", "表示の更新", None))
        self.groupBox_3.setTitle(_translate("Dialog", "耕作者・エリア毎集計結果", None))
        self.btn_show_scattered.setText(_translate("Dialog", "圃場分散度を算出・表示する", None))
        self.btn_show_route.setText(_translate("Dialog", "経路の表示", None))

