# -*- coding: utf-8 -*-


# eclipseからデバッグするときに必要なコード
# import os,sys
# sys.path.append("C:\pleiades\eclipse\dropins\PyDev\eclipse\plugins\org.python.pydev_5.2.0.201608171824\pysrc")
# import pydevd
# pydevd.settrace()

def classFactory(iface):
  from .main import main
  return main(iface)