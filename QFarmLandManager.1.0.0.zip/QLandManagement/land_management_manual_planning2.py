# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_manual_planning_ui2 import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import random
import time
import math
import csv



class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)


        #self.ui.rbtn_all.setChecked(1)


        #self.populate_tablewidget_farmers()
        #self.populate_tablewidget_farmers_area()
        self.populate_tablewidget_scenario()


        #self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
        #self.connect(self.ui.btn_calc_route, SIGNAL("clicked()"),self.calc_route)
        #self.connect(self.ui.btn_show_route,SIGNAL("clicked()"),self.show_route)
        self.connect(self.ui.btn_start,SIGNAL("clicked()"),self.start_edit)
        self.connect(self.ui.btn_csv,SIGNAL("clicked()"),self.set_csv)
        self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
        #self.connect(self.ui.btn_re_calc,SIGNAL("clicked()"),self.re_calc)
        self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_info_selected)

    def set_csv(self):
        file = QFileDialog.getOpenFileName(None, "Open CSVfile", ".", "CSVfiles (*.csv)")
        #filInfo = QFileInfo(fil)
        if file !="":
            self.ui.lineedit_csv.setText(file)
            self.populate_tablewidget_farmers(file)

    def populate_tablewidget_scenario(self):
        self.ui.tablewidget_scenario.clear()
        self.ui.tablewidget_scenario.setRowCount(0)
        self.ui.tablewidget_scenario.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"シナリオ名"]
        self.ui.tablewidget_scenario.setColumnCount(len(headers))
        self.ui.tablewidget_scenario.setHorizontalHeaderLabels(headers)
        #self.ui.tablewidget_.setSelectionBehavior(QAbstractItemView.SelectRows)

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        cursor=db.cursor()
        sql="""select scenario from result_table group by scenario  """
        cursor.execute(sql)
        rows=cursor.fetchall()
        i=0
        for scenario in rows:

            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_scenario.insertRow(i)
            #self.ui.tablewidget_scenario.setItem(i,0,chk)
            self.ui.tablewidget_scenario.setItem(i,0,QTableWidgetItem(scenario[0]))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_scenario.resizeColumnsToContents()

    def join_table(self):
        farmland_table=self.get_farmland_table()
        result_table=self.get_result_table()
        joinObject = QgsVectorJoinInfo()
        joinObject.joinLayerId = result_table.id()
        joinObject.joinFieldName = "farmland_code"
        joinObject.targetFieldName = "farmland_code"
        joinObject.memoryCache=True
        farmland_table.addJoin(joinObject)

    def get_farmland_table(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=='farmland_table':
                layer1=lyr
                return layer1
                break

    def get_result_table(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=='result_table':
                layer1=lyr
                return layer1
                break
    def remove_join(self):
        farmland_table=self.get_farmland_table()
        result_table=self.get_result_table()
        farmland_table.removeJoin(result_table.id())


    def create_new_scenario(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        scenario_name=self.ui.lineedit_scenario_name.text()
        farmland_table=pyqgis_processing.get_farmland_table()

        #現状の耕作状況を結果テーブルにコピーする
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'初期データ構築中')
        max = farmland_table.featureCount()
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
#             farm_name=feature[feature.fieldNameIndex('farm_name')]
            farm_name=u"未設定"
            farmland_code=feature[feature.fieldNameIndex('farmland_code')]
            sql_insert="""insert into result_table ( scenario,farmland_code,farm_name) values(?,?,?) """
            db.execute(sql_insert,(scenario_name,farmland_code,farm_name,))
            process_counter=process_counter+1

        db.commit()

    def start_edit(self):
        result_table=self.get_result_table()
        if self.ui.rbtn_new.isChecked()==True:
            self.create_new_scenario()
            query_string=""" "scenario" = '""" + self.ui.lineedit_scenario_name.text() + """' """
            pyqgis_processing.set_query(result_table, query_string)
            #self.populate_tablewidget_farmers(self.ui.lineedit_scenario_name.text())
        elif self.ui.rbtn_update.isChecked()==True:
            row = self.ui.tablewidget_scenario.currentRow()
            if row !=-1:
              
                    
                scenario=self.ui.tablewidget_scenario.item(row,0).text()
                query_string=""" "scenario" = '""" + scenario + """' """
                pyqgis_processing.set_query(result_table, query_string)
                #self.populate_tablewidget_farmers(scenario)
            else:
                pyqgis_processing.show_msgbox(u"既存案を作成してください")
                return
        else:
            pyqgis_processing.show_msgbox(u"新規作成か既存案の修正か選択してください")

    def populate_tablewidget_farmers(self,csv_path):
        self.ui.tablewidget_farmers.clear()
        self.ui.tablewidget_farmers.setRowCount(0)
        self.ui.tablewidget_farmers.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_farmers.setColumnCount(len(headers))
        self.ui.tablewidget_farmers.setHorizontalHeaderLabels(headers)
        #list_farmers=self.make_farmers_list(scenario)
        #print list_farmer
        i=0
        for farmer in self.load_csv(csv_path):
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_farmers.insertRow(i)
            self.ui.tablewidget_farmers.setItem(i,0,chk)
            self.ui.tablewidget_farmers.setItem(i,1,QTableWidgetItem(farmer[0].decode("cp932")))
            self.ui.tablewidget_farmers.setItem(i,2,QTableWidgetItem("{:,.0f}".format(float(farmer[1].decode("cp932")))))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_farmers.resizeColumnsToContents()

    def make_farmers_list(self,scenario):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select result_table.farm_name ,total(farmland_table.land_area)
                        from farmland_table inner join result_table on farmland_table.farmland_code = result_table.farmland_code
                        where result_table.scenario=?
                        group by result_table.farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,(scenario,))
        rows=cursor.fetchall()

        return rows

    def renderer(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmers.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmers.item(i,0).checkState()==Qt.Checked:
                list_farmers.append((self.ui.tablewidget_farmers.item(i,1).text()))

        list_rule=[]
        for farmer in list_farmers:
            label_string=   farmer
            query_string= '\"result_table_farm_name\" ='+ '\''+ farmer +'\' '
            list_rule.append([label_string,query_string])

        farmland_table=pyqgis_processing.get_farmland_table()
        pyqgis_processing.renderer_map1(farmland_table, list_rule)
        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()

        self.populate_tablewidget_farmers_area(list_farmers)
        self.populate_cmbbox_farm_name(list_farmers)


    def populate_tablewidget_farmers_area(self,farmers_list):

        if self.ui.rbtn_new.isChecked()==True:
            scenario=self.ui.lineedit_scenario_name.text()
        else:
            row = self.ui.tablewidget_scenario.currentRow()
            scenario=self.ui.tablewidget_scenario.item(row,0).text()


        self.ui.tablewidget_farmers_area.clear()
        self.ui.tablewidget_farmers_area.setSortingEnabled(True)
        self.ui.tablewidget_farmers_area.setRowCount(0)
        headers=[u"耕作者名",u"調整案面積小計"]
        self.ui.tablewidget_farmers_area.setColumnCount(len(headers))
        self.ui.tablewidget_farmers_area.setHorizontalHeaderLabels(headers)
        list_farmers_area=self.make_farmers_area_list()
        #print list_farmer

#         widget = QWidget()
#         widget.setGeometry(100, 100, 250, 100)
#         widget.setWindowTitle(u'圃場分散度計算中')
#         max = len(list_farmers_area)
#         pbar = QProgressBar(widget)
#         pbar.setGeometry(25, 40, 200, 25)
#         pbar.setRange(0, max)
#         widget.show()
#         widget.raise_()
#         process_counter=1
        i=0
#         for farmer in list_farmers_area:
#             pbar.setValue(process_counter)
        for farmer in farmers_list:
#             if self.sum_area_plan(scenario,farmer[0], farmer[1])!=None:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_farmers_area.insertRow(i)
            self.ui.tablewidget_farmers_area.setItem(i,0,QTableWidgetItem(farmer))
#             self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem(farmer[1]))
#             self.ui.tablewidget_farmers_area.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[2])))
#             self.ui.tablewidget_farmers_area.setItem(i,3,QTableWidgetItem("{:,.0f}".format(self.calc_length(farmer[0], farmer[1], farmer[2]))))
            try:
                self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem("{:,.0f}".format(self.sum_area_plan2(scenario,farmer)[0])))
            except:
                self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem(str(0)))
#             self.ui.tablewidget_farmers_area.setItem(i,5,QTableWidgetItem("{:,.0f}".format(self.calc_length_plan(farmer[0], farmer[1], farmer[2]))))
            i=i+1
#                 process_counter=process_counter+1
        #self.sum_area()
        self.ui.tablewidget_farmers_area.resizeColumnsToContents()

    def calc_length(self,farm_name,district,area):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('farm_name')] ==farm_name:
                if feature[feature.fieldNameIndex('district')] ==district:
                    land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)

        dist=0
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql_string=""" select  dist from dist_table where id_from=? and id_to=?"""

        for i in xrange(0,len(best_route)-2):
            land_from=best_route[i]
            land_to=best_route[i+1]
            id_from=land_from[1]
            id_to=land_to[1]
            query_row=(id_from,id_to)
            cursor=db.cursor()
            cursor.execute(sql_string,query_row)
            row=cursor.fetchone()
            if row is None:
                distance_x = abs(land_from[2]-land_to[2])
                distance_y = abs(land_from[3]-land_to[3])
                dist_part = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
                dist=dist+dist_part

        return dist/area*1000

#         from land_management_tsp1 import run_simple_tsp
#         farmland_table=pyqgis_processing.get_farmland_table()
#         land_list=[]
#         for feature in farmland_table.getFeatures():
#             if feature[feature.fieldNameIndex('farm_name')] ==farm_name:
#                 if feature[feature.fieldNameIndex('district')] ==district:
#                     land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#         best_route=run_simple_tsp(land_list)
#         qpoint=[]
#
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         crs = farmland_table.crs().authid()#toWkt()
#         geom = f.geometry()
#         return geom.length()/area*1000

    def make_farmers_area_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql_string="select farm_name,district,total(land_area) from farmland_table group by farm_name,district"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows

    def populate_cmbbox_farm_name(self,farmers):
        self.ui.cmbbox_farm_name.clear()
        for row in farmers:
            self.ui.cmbbox_farm_name.addItem(row)

    def sum_area_plan(self,scenario,farmer,district):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select total(farmland_table.land_area)
                        from farmland_table inner join result_table on farmland_table.farmland_code = result_table.farmland_code
                        where result_table.scenario=? and result_table.farm_name=? and farmland_table.district=?
                        group by result_table.farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,(scenario,farmer,district))
        row=cursor.fetchone()
        print row

        return row
    
    def sum_area_plan2(self,scenario,farmer):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select total(farmland_table.land_area)
                        from farmland_table inner join result_table on farmland_table.farmland_code = result_table.farmland_code
                        where result_table.scenario=? and result_table.farm_name=? 
                        group by result_table.farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,(scenario,farmer))
        row=cursor.fetchone()
        print row
        
        return row

    def calc_length_plan(self,farm_name,district,area):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('result_table_farm_name')] ==farm_name:
                if feature[feature.fieldNameIndex('district')] ==district:
                    land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)

        dist=0
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql_string=""" select  dist from dist_table where id_from=? and id_to=?"""

        for i in xrange(0,len(best_route)-2):
            land_from=best_route[i]
            land_to=best_route[i+1]
            id_from=land_from[1]
            id_to=land_to[1]
            query_row=(id_from,id_to)
            cursor=db.cursor()
            cursor.execute(sql_string,query_row)
            row=cursor.fetchone()
            if row is None:
                distance_x = abs(land_from[2]-land_to[2])
                distance_y = abs(land_from[3]-land_to[3])
                dist_part = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
                dist=dist+dist_part

        return dist/area*1000
#         from land_management_tsp1 import run_simple_tsp
#         farmland_table=pyqgis_processing.get_farmland_table()
#         land_list=[]
#         for feature in farmland_table.getFeatures():
#             if feature[feature.fieldNameIndex('result_table_farm_name')] ==farm_name:
#                 if feature[feature.fieldNameIndex('district')] ==district:
#                     land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#         best_route=run_simple_tsp(land_list)
#         qpoint=[]
#
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         crs = farmland_table.crs().authid()#toWkt()
#         geom = f.geometry()
#         return geom.length()/area*1000

    def re_calc(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmers.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmers.item(i,0).checkState()==Qt.Checked:
                list_farmers.append((self.ui.tablewidget_farmers.item(i,1).text()))

        self.populate_tablewidget_farmers_area(list_farmers)

    def update_info_selected(self):
        farmland_table=pyqgis_processing.get_farmland_table()
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        if self.ui.rbtn_new.isChecked()==True:
            scenario=self.ui.lineedit_scenario_name.text()
        else:
            row = self.ui.tablewidget_scenario.currentRow()
            scenario=self.ui.tablewidget_scenario.item(row,0).text()
        farm_name=self.ui.cmbbox_farm_name.currentText()
        features=farmland_table.selectedFeatures()

        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return

        for feature in features:
            farmland_code=feature['farmland_code']
            sql=""" update result_table set farm_name = ? where scenario=? and farmland_code=? """

            db.execute(sql,(farm_name,scenario,farmland_code))
        db.commit()

        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()
        self.renderer()

    def load_csv(self,csv_path):
#         prj_file=QFileInfo(QgsProject.instance().fileName())
#         path=prj_file.absolutePath()
        table_csv=open(csv_path)
        data=csv.reader(table_csv)
        header = data.next()
        return data

#         for row in data:
#             self.list_csv.append([row[0].decode("cp932"),row[1].decode("cp932"),row[2].decode("cp932"),row[3].decode("cp932"),row[4].decode("cp932"),row[5].decode("cp932")])





