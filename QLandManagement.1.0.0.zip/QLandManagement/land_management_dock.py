# -*- coding: utf-8- -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from land_management_dock_ui import Ui_DockWidget
from qgis.core import *
from qgis.gui import *
from QLandManagement import  pyqgis_processing
import sqlite3
import datetime
import math
import gc
from time import sleep
from QLandManagement import setup_db
import os,sys
from QLandManagement.pyqgis_processing import get_subdistrict_table
#from tornado.testing import gen
#from ogrmerge import process

class DockWidget(QDockWidget,Ui_DockWidget):

    def __init__(self,iface):
        QDockWidget.__init__(self)
        self.iface=iface

        self.crs=0

        if sys.platform == "win32":
            if not os.path.exists("c:/qfarmlandmanager/land_db.sqlite"):
                ret = QMessageBox.information(None, u"確認", u"必要なデータベースが見つかりません。セットアップしますか？", QMessageBox.Yes, QMessageBox.No)
                if ret == QMessageBox.Yes:
                    setup_db.select_crs(self)
                    setup_db.copy_from_resource(self.crs)
                    setup_db.create_tables(self.crs)
#                     pyqgis_processing.show_msgbox(u"データベース準備完了。c:/qfarmlandmanager/landmanagement.qgsから起動し直してください。")
#                 return
                    uri = QgsDataSourceURI()
                    #uri.setDatabase(u'C:/gisdata/地域戦略プロ/中条デモ/nakajo_db.sqlite')
                    uri.setDatabase("c:/qfarmlandmanager/land_db.sqlite")

                    schema = ''
                    table = 'area'
                    geom_column = 'geom'
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'area'
                    layer3 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(layer3)

                    schema = ''
                    table = 'subdistrict_table'
                    geom_column = 'geom'
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'subdistrict_table'
                    layer2 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(layer2)

                    schema = ''
                    table = 'farmland_table'
                    geom_column = 'geometry'
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'farmland_table'
                    layer1 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(layer1)

                    schema = ''
                    table = 'result_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'result_table'
                    table1 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table1)

                    schema = ''
                    table = 'scenario_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'scenario_table'
                    table2 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table2)

                    schema = ''
                    table = 'route_name_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'route_name_table'
                    table3 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table3)

                    schema = ''
                    table = 'route_table2'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'route_table2'
                    table4 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table4)

                    schema = ''
                    table = 'route_table_sub'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'route_table_sub'
                    table5 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table5)

                    schema = ''
                    table = 'dist_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'dist_table'
                    table5 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table5)

                    self.add_join_table()

                    project = QgsProject.instance()
                    file_path = QFileInfo("c:/qfarmlandmanager/landmanagement.qgs")
                    project.write(file_path)
                    pyqgis_processing.show_msgbox(u"データベース準備完了。次回からはc:/qfarmlandmanager/landmanagement.qgsから起動し直してください。")




        else:
            if not os.path.exists(os.path.expanduser('~/qfarmlandmanager/land_db.sqlite')):
                ret = QMessageBox.information(None, u"確認", u"必要なデータベースが見つかりません。セットアップしますか？", QMessageBox.Yes, QMessageBox.No)
                if ret == QMessageBox.Yes:
#                     setup_db.select_crs(self)
#                     setup_db.copy_from_resource(self.crs)
#                     setup_db.create_tables(self.crs)
#                     pyqgis_processing.show_msgbox(u"データベース準備完了。qfarmlandmanager/landmanagement.qgsから起動し直してください。")
                    setup_db.select_crs(self)
                    setup_db.copy_from_resource(self.crs)
                    setup_db.create_tables(self.crs)
#                     pyqgis_processing.show_msgbox(u"データベース準備完了。c:/qfarmlandmanager/landmanagement.qgsから起動し直してください。")
#                 return
                    uri = QgsDataSourceURI()
                    #uri.setDatabase(u'C:/gisdata/地域戦略プロ/中条デモ/nakajo_db.sqlite')
                    uri.setDatabase(os.path.expanduser('~/qfarmlandmanager/land_db.sqlite'))

                    schema = ''
                    table = 'area'
                    geom_column = 'geom'
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'area'
                    layer3 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(layer3)

                    schema = ''
                    table = 'subdistrict_table'
                    geom_column = 'geom'
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'subdistrict_table'
                    layer2 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(layer2)

                    schema = ''
                    table = 'farmland_table'
                    geom_column = 'geometry'
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'farmland_table'
                    layer1 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(layer1)

                    schema = ''
                    table = 'result_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'result_table'
                    table1 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table1)

                    schema = ''
                    table = 'scenario_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'scenario_table'
                    table2 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table2)

                    schema = ''
                    table = 'route_name_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'route_name_table'
                    table3 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table3)

                    schema = ''
                    table = 'route_table2'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'route_table2'
                    table4 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table4)

                    schema = ''
                    table = 'route_table_sub'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'route_table_sub'
                    table5 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table5)

                    schema = ''
                    table = 'dist_table'
                    geom_column = ''
                    uri.setDataSource(schema, table, geom_column)
                    display_name = 'dist_table'
                    table5 = QgsVectorLayer(uri.uri(), display_name, 'spatialite')
                    QgsMapLayerRegistry.instance().addMapLayer(table5)

                    self.add_join_table()

                    project = QgsProject.instance()
                    file_path = QFileInfo(os.path.expanduser('~/qfarmlandmanager/landmanagement.qgs'))
                    project.write(file_path)
                    pyqgis_processing.show_msgbox(u"データベース準備完了。次回からはqfarmlandmanager/landmanagement.qgsから起動し直してください。")
                #return


        self.ui=Ui_DockWidget()
        self.ui.setupUi(self)
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.subdistrict_table=pyqgis_processing.get_subdistrict_table()

        #QObject.connect(self.ui.btn_TSP,SIGNAL("clicked()"),self.open_tsp)
        #QObject.connect(self.ui.btn_make_initial_solution,SIGNAL("clicked()"),self.make_initial_solution)
        #QObject.connect(self.ui.btn_make_solution,SIGNAL("clicked()"),self.make_solution)
        #QObject.connect(self.ui.btn_open_main,SIGNAL("clicked()"),self.open_main)
        QObject.connect(self.ui.btn_renderer_current,SIGNAL("clicked()"),self.open_renderer_current)
        QObject.connect(self.ui.btn_manual_planning,SIGNAL("clicked()"),self.open_manual_planning)
        QObject.connect(self.ui.btn_adhoc_input,SIGNAL("clicked()"),self.open_manual_planning2)
        QObject.connect(self.ui.btn_partial_planning,SIGNAL("clicked()"),self.open_partial_planning)
        QObject.connect(self.ui.btn_all_planning,SIGNAL("clicked()"),self.open_all_planning)
        QObject.connect(self.ui.btn_all_planing2,SIGNAL("clicked()"),self.open_all_planning2)
        QObject.connect(self.ui.btn_input_information,SIGNAL("clicked()"),self.open_update_info)
        QObject.connect(self.ui.btn_read_csv,SIGNAL("clicked()"),self.open_read_csv)
        #QObject.connect(self.ui.btn_merge,SIGNAL("clicked()"),self.merge)
        QObject.connect(self.ui.btn_merge,SIGNAL("clicked()"),self.merge_on_mem)
        QObject.connect(self.ui.btn_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
        #QObject.connect(self.ui.btn_write_subdistid,SIGNAL("clicked()"),self.write_subdstrict_id_to_farmland)
#         QObject.connect(self.ui.btn_merge,SIGNAL("clicked()"),self.merge_on_hd)
        QObject.connect(self.ui.btn_calc_dist,SIGNAL("clicked()"),self.calc_dist)
        QObject.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.open_query)
        QObject.connect(self.ui.btn_open_point_data_importer,SIGNAL("clicked()"),self.open_point_data_importer)
        QObject.connect(self.ui.btn_make_base_route,SIGNAL("clicked()"),self.make_route)
        QObject.connect(self.ui.btn_show_base_route,SIGNAL("clicked()"),self.show_base_route)
        self.ui.cmbbox_label.addItem(u"ラベルなし")
        self.ui.cmbbox_label.addItem(u"現状耕作者")
        self.ui.cmbbox_label.addItem(u"地権者")
        self.ui.cmbbox_label.addItem(u"調整案耕作者")
        self.connect(self.ui.cmbbox_label, SIGNAL("currentIndexChanged(const QString&)"),self.set_label)

        self.ui.btn_write_subdistid.setVisible(False)

        #フィールドの表示設定
        #メインの圃区フィールド
        pyqgis_processing.hide_all_columns(self.farmland_table)
        #pyqgis_processing.hide_all_columns(self.subdistrict_table)
        pyqgis_processing.show_all_columns(self.subdistrict_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.hidden_label(self.farmland_table)
        
        #開発中のボタンを消す
        #
        self.ui.btn_write_area_id.setVisible(False)
        self.ui.btn_area_connect.setVisible(False)

    def show_attribute_table(self):
        pyqgis_processing.clear_attributetable()
        layer=self.farmland_table

        self.iface.showAttributeTable(layer)


    def add_join_table(self):
        farmland_table=pyqgis_processing.get_farmland_table()
        result_table=pyqgis_processing.get_result_table()
        joinObject = QgsVectorJoinInfo()
        joinObject.joinLayerId = result_table.id()
        joinObject.joinFieldName = "farmland_code"
        joinObject.targetFieldName = "farmland_code"
        joinObject.memoryCache=False
        farmland_table.addJoin(joinObject)

    def open_point_data_importer(self):
        from land_management_point_importer import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_query(self):
        from land_management_filter_landfield import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_read_csv(self):
        from land_management_planning_csv import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_update_info(self):
        from land_management_update_info import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def set_label(self):
        if self.ui.cmbbox_label.currentText()==u"ラベルなし":
            pyqgis_processing.hidden_label(pyqgis_processing.get_farmland_table())
        elif self.ui.cmbbox_label.currentText()==u"現状耕作者":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "farm_name")
        elif self.ui.cmbbox_label.currentText()==u"地権者":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "owner_name")
        elif self.ui.cmbbox_label.currentText()==u"調整案耕作者":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "result_table_farm_name")


    def merge_on_mem(self):

        ret = QMessageBox.information(None, u"確認", u"あなたはシステム管理者ですか？", QMessageBox.Yes, QMessageBox.No)
        if ret == QMessageBox.No:
            return
        ret = QMessageBox.information(None, u"確認", u"圃区データの作成は時間がかかります。作成しますか？", QMessageBox.Yes, QMessageBox.No)
        if ret == QMessageBox.No:
            return
        else:
            pyqgis_processing.show_msgbox(u"圃区データの作成を開始します。")

        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                farmland_table=lyr
            if lyr.name()=="subdistrict_table":
                subdistrict_table=lyr

        flag=True

        crs = farmland_table.crs().authid()
        memlayer=QgsVectorLayer("Polygon?crs=" + crs,'subdistrict_temp','memory')
        mempr=memlayer.dataProvider()
        features=farmland_table.getFeatures()
        for feature in features:
            mempr.addFeatures([feature])
            memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])


        i=0

        #whileが遅いので、forで出来ないか？
        #美しくはないが、forで処理が重くなって行くのを回避出来た

        feature_count=memlayer.featureCount()
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'メモリ内マージ処理中')
        pmax = feature_count
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, pmax)
        widget.show()
        widget.raise_()
        process_counter=0
        pbar.setValue(process_counter)
        import sys
        app = QApplication(sys.argv)
        app_processEvents=app.processEvents
        canvas_refresh=self.iface.mapCanvas().refresh
#         memlayer_startEditing=memlayer.startEditing
#         memlayer_endEditCommand=memlayer.endEditCommand
        new_feature=QgsFeature()
        geom=None
        geom_touch=None
        flag=False
        flag2=False
        feature_ids=[]
        #memlayer.startEditing()
        for j in xrange(feature_count):

            #print j

            pbar.setValue(j)
            pbar.setFormat(u'処理数'+":"+ str(j))
            #self.iface.mapCanvas().refresh()
            #canvas_refresh()
            app_processEvents()
            #gc.collect()
            sleep(0.01)
            flag=False
            #features=memlayer.getFeatures()
            #外に出す↓
#             for feature1 in features:
#                 flag2=False
#                 feature_ids=[]
#                 #↓全部のフィーチャをループすると時間かかりすぎるので、事前に絞る。
#                 geom = feature1.geometry()
#                 geom_touch=geom.touches
#                 feature_ids=[feature2.id() for feature2 in memlayer.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))
#                               if geom_touch(feature2.geometry())]
#
#                 memlayer.setSelectedFeatures(feature_ids)
#                 for selected_feature in memlayer.selectedFeatures():
#                     geom=geom.combine(selected_feature.geometry())
#                     flag2=True
#
#                 if flag2==True:
#                     new_feature.setGeometry(geom)
#                     mempr.addFeatures([new_feature])
#                     mempr.deleteFeatures(feature_ids)
#                     mempr.deleteFeatures([feature1.id()])
#                     flag=True
#                     break

            #外に出す↑
            if flag==self.subprocess1(memlayer):
#             if flag==False:
                break
        #memlayer.endEditCommand()
        process_counter=feature_count
        pbar.setValue(process_counter)
        pbar.setFormat(u'処理数'+":"+ str(process_counter))

#これが落ちる原因？
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'DB出力中')
        max = 1
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        pbar.setValue(process_counter)

        self.copy_to_DB(memlayer)
        QgsMapLayerRegistry.instance().removeMapLayers([memlayer])

        #重心座標の書き込み
        self.write_centroid()

        #圃場への圃区IDの書き込み
        self.write_subdstrict_id_to_farmland()


        pyqgis_processing.show_msgbox(u"圃区作成が完了しました")

    def gen_mem_features(self,memlayer):
        #features=memlayer.getFeatures()
        for feature in memlayer.getFeatures():
            yield feature
    def gen_mem_features2(self,memlayer,feature_ids):
        memlayer.setSelectedFeatures(feature_ids)
        for feature in memlayer.selectedFeatures():
            yield feature

    def gen_do(self,new_feature,feature_ids,feature,memlayer):
        yield memlayer.dataProvider().addFeatures([new_feature])
        yield memlayer.dataProvider().deleteFeatures(feature_ids)
        yield memlayer.dataProvider().deleteFeatures([feature.id()])
        del new_feature
        del feature_ids
        del feature
        yield gc.collect()

    def gen_do_test(self,new_feature,feature_ids,feature,memlayer):
        #yield memlayer.startEditing()
        yield memlayer.addFeatures([new_feature])
        yield memlayer.deleteFeatures(feature_ids)
        yield memlayer.deleteFeatures([feature.id()])
        yield memlayer.commitChanges()
        #yield memlayer.endEditCommand()
        del new_feature
        del feature_ids
        del feature
        #yield gc.collect()



    def subprocess1(self,memlayer):
        flag=False
        j=1
        mempr=memlayer.dataProvider()
        new_feature=QgsFeature()
        #yieldを試してみる
        #features=memlayer.getFeatures()
        feature_ids=[]
        features=self.gen_mem_features(memlayer)
        #↓の編集開始は比較的うまく行くので戻すこと
        memlayer.startEditing()
        for feature1 in features:
            flag2=False
            #feature_ids=[]
            #↓全部のフィーチャをループすると時間かかりすぎるので、事前に絞る。
            geom = feature1.geometry()
            geom_touch=geom.touches
            feature_ids=[feature2.id() for feature2 in memlayer.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))
                          if geom_touch(feature2.geometry())]
            #yieldを試してみる
#             memlayer.setSelectedFeatures(feature_ids)
#             for selected_feature in memlayer.selectedFeatures():
            for selected_feature in self.gen_mem_features2(memlayer,feature_ids):
#             for feature_id in feature_ids:
                geom=geom.combine(selected_feature.geometry())
                flag2=True

            if flag2==True:
                new_feature.setGeometry(geom)
#                 for i in self.gen_do(new_feature, feature_ids, feature1, memlayer):
#                     i
                gen=self.gen_do_test(new_feature, feature_ids, feature1, memlayer)
                gen.next()
                gen.next()
                gen.next()
                gen.next()
                #gen.next()
                #gen.next()
                #gen.next()
                del gen
                #gc.collect()
#                 mempr.addFeatures([new_feature])
#                 mempr.deleteFeatures(feature_ids)
#                 mempr.deleteFeatures([feature1.id()])
                flag=True
                break
        #下の編集終了は比較的馬行くので戻すこと
        memlayer.endEditCommand()
        del mempr
        gc.collect()
        return flag



    def write_subdstrict_id_to_farmland(self):
        #print u"圃区ID書き込み"
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            #print lyr.name()
            if lyr.name()=="farmland_table":
                farmland_table=lyr
               # print "get farmland!"
            if lyr.name()=="subdistrict_table":
                subdistrict_table=lyr
               # print "get subdist"
       # print "getlyr"

        #圃区のループ処理
        subdistrict_features=subdistrict_table.getFeatures()
        subdistrict_count=subdistrict_table.featureCount()
#         print subdistrict_count
#
#         print u"プログレスバー表示準備"

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'圃区データ書き込み中')
        pmax = subdistrict_count
        pbar = QProgressBar(widget)
        #pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, pmax)
        widget.show()
        widget.raise_()
        process_counter=0
        pbar.setValue(process_counter)

        import sys

        #app = QApplication(sys.argv)

        i=0
        feature_ids=[]

        farmland_table.startEditing()
        for subdistrict in subdistrict_features:
           # print subdistrict.id()
            pbar.setValue(i)
            pbar.setFormat(u'処理数'+":"+ str(i))
            #app.processEvents()
            #対象圃場を絞り込む
            geom = subdistrict.geometry()
            geom_touch=geom.touches
            geom_intersect=geom.intersects
            feature_ids=[feature.id() for feature in farmland_table.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))]
#                            if geom_touch(feature.geometry())]
#                         if geom_touch(feature.geometry().centroid())]

          #  print feature_ids
            farmland_table.setSelectedFeatures(feature_ids)
            for selected_feature in farmland_table.selectedFeatures():
#                 if geom_touch(selected_feature.geometry()):
                if geom_intersect(selected_feature.geometry()):
                    selected_feature[selected_feature.fieldNameIndex('subdistrict_code')]=subdistrict.id()
                    #print subdistrict.id()
                    farmland_table.updateFeature(selected_feature)
#                 else:
#                     print "None"
            i+=1

        farmland_table.commitChanges()
        farmland_table.endEditCommand()





    def write_centroid(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="subdistrict_table":
                subdistrict_table=lyr
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'重心座標計算中')
        max = subdistrict_table.featureCount()
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)

        widget.show()
        widget.raise_()
        subdistrict_table.startEditing()
        i=1
        features=subdistrict_table.getFeatures()
        for feature in features:
            pbar.setValue(i)
            geom=QgsGeometry(feature.geometry())
#             sourcecrs=subdistrict_table.crs()
#             targetcrs=QgsCoordinateReferenceSystem(4326)
#             crstransform=QgsCoordinateTransform(sourcecrs,targetcrs)
#             geom.transform(crstransform)
            cgeom=geom.centroid()
            point=cgeom.asPoint()
            str_point=""
            str_point=str_point + str(point.y())+"|"+str(point.x()) +","
            str_point=str_point[:-1]

            feature[feature.fieldNameIndex('centroid_X')]=point.x()
            feature[feature.fieldNameIndex('centroid_Y')]=point.y()
            subdistrict_table.updateFeature(feature)
            i=i+1
        subdistrict_table.commitChanges()
        subdistrict_table.endEditCommand()

    def copy_to_DB(self,memlayer):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="subdistrict_table":
                subdistrict_table=lyr

        flag=True


#         dp=subdistrict_table.dataProvider()
#         features=[]
#         for feature in subdistrict_m.getFeatures():
#             features.append(feature)
#         dp.addFeatures(features)
#         dp.updateExtents()
#         crs = subdistrict_table.crs().authid()
#         memlayer=QgsVectorLayer("Polygon?crs=" + crs,'subdistrict_m','memory')
#         mempr=memlayer.dataProvider()
#         features=subdistrict_table.getFeatures()
#         for feature in features:
#             mempr.addFeatures([feature])
#             memlayer.updateExtents()
#         QgsMapLayerRegistry.instance().addMapLayers([memlayer])


        for feature in memlayer.getFeatures():
            geom=feature.geometry()
            new_feature=QgsFeature()
            new_feature.setGeometry(geom)
            #subdistrict_table.startEditing()
            subdistrict_table.dataProvider().addFeatures([new_feature])
            #subdistrict_table.commitChanges()
            #subdistrict_table.endEditCommand()
            subdistrict_table.dataProvider().forceReload()
            subdistrict_table.triggerRepaint()




    def open_tsp(self):
        from land_management_tsp import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_main(self):
        from land_management_main import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_current(self):
        from land_management_renderer_current import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_manual_planning(self):
        from land_management_manual_planning import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_manual_planning2(self):
        from land_management_manual_planning2 import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_partial_planning(self):
        from land_management_partial_planning import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_all_planning(self):
        from land_management_all_planning import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_all_planning2(self):
        from land_management_all_planning2 import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()


    def make_initial_solution(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql="select farmland_code ,land_area,random from farmland_table where district=?"

        cursor=db.cursor()
        cursor.execute(sql,("A",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("B",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("C",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("D",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("E",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("F",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("G",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("H",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("I",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人A",u"法人B",u"法人C",u"法人D")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("J",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        #list_farmers=(u"法人D")
        i=0
        #for farmer in list_farmers:
        area=0
        while i <len(list_land):
            if area>100000:
                break
            else:
#                     print area
#                     print farmer
#                     print row[0]
                #print list_land[i][0]
                area=area+list_land[i][1]
                sql_update="update farmland_table set farm_name=? where farmland_code=?"
                db.execute(sql_update,(u"法人D",list_land[i][0],))
                i=i+1
        db.commit()

        cursor=db.cursor()
        cursor.execute(sql,("K",))
        rows=cursor.fetchall()
        list_land=[]
        for row in rows:
            list_land.append(row)
        list_land.sort(key=lambda x:x[2])
        list_farmers=(u"法人B",u"法人C")
        i=0
        for farmer in list_farmers:
            area=0
            while i <len(list_land):
                if area>100000:
                    break
                else:
#                     print area
#                     print farmer
#                     print row[0]
                    #print list_land[i]
                    area=area+list_land[i][1]
                    sql_update="update farmland_table set farm_name=? where farmland_code=?"
                    db.execute(sql_update,(farmer,list_land[i][0],))
                    i=i+1
        db.commit()

    def make_solution(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                farmland_table=lyr
            elif lyr.name()=="subdistrict_table":
                subdistrict_table=lyr
            elif lyr.name()=="area":
                area_table=lyr



        #エリアのリストを作成

        cursor=db.cursor()
        sql="select area_name from area"
        cursor.execute(sql)
        list_area=cursor.fetchall()

        #エリア毎の耕作者リストを作成
        #リストには面積の集計を含める
        list_farmer=[]
        for area in list_area:
            cursor=db.cursor()
            sql="select district ,farm_name from farmland_table where district=?"
            cursor.execute(sql,(area[0],))
            rows=cursor.fetchall()
            for row in rows:
                if  row  not in list_farmer:
                    list_farmer.append(row)

        list_farmer_area=[]
        for item in list_farmer:
            cursor=db.cursor()
            sql="select total (land_area) from farmland_table where district=? and farm_name=?"
            value=(item[0],item[1])
            cursor.execute(sql,value)
            total=cursor.fetchmany(1)
            list_farmer_area.append((item[0],item[1],total[0][0]))

#         for item in list_farmer_area:
#             print item[0]+item[1]+str(item[2])
#         list_partial= filter(lambda x: x[0]=="B", list_farmer_area)
#         print list_partial

        list_area.sort()
        for area in list_area:
            list_partial=filter(lambda x: x[0]==area[0], list_farmer_area)
            district=area[0]
            sql="select farmland_code ,land_area,route from farmland_table where district=?"
            cursor=db.cursor()
            cursor.execute(sql,(district,))
            rows=cursor.fetchall()
            list_land=[]
            for row in rows:
                list_land.append(row)
            list_land.sort(key=lambda x:x[2])
            i=0
            for item in list_partial:
                farm_name=item[1]
                farm_area=item[2]
                area_count=0
                while i <len(list_land):
                    if area_count>farm_area:
                        break
                    else:
    #                     print area
    #                     print farmer
    #                     print row[0]
                        #print list_land[i]
                        area_count=area_count+list_land[i][1]
                        sql_update="update farmland_table set solution=? where farmland_code=?"
                        db.execute(sql_update,(farm_name,list_land[i][0],))
                        i=i+1
                db.commit()

           # print list_partial

    def make_route(self):
        ret = QMessageBox.information(None, u"確認", u"あなたはシステム管理者ですか？", QMessageBox.Yes, QMessageBox.No)
        if ret == QMessageBox.No:
            return
        ret = QMessageBox.information(None, u"確認", u"圃場ネットワークデータの作成は時間がかかります。作成しますか？", QMessageBox.Yes, QMessageBox.No)
        if ret == QMessageBox.No:
            return
        else:
            pyqgis_processing.show_msgbox(u"圃場ネットワークデータの作成を開始します。")

        #まず既存データの削除
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        db.execute("delete from  route_table_sub where scenario=?", ("base",))
        db.commit()
        db.execute("delete from  route_table2 where scenario=?", ("base",))
        db.commit()

        #圃区巡回経路の作成
        self.run_subdistrict()

        #耕区巡回経路の作成
        self.run_main()

        pyqgis_processing.show_msgbox(u"圃場ネットワークデータの作成が完了しました")


    def run_subdistrict(self):
        from land_management_tsp_subdistrict import City
        from land_management_tsp_subdistrict import district
        from land_management_tsp_subdistrict import TourManager
        from land_management_tsp_subdistrict import OPT_2
        from land_management_tsp_subdistrict import Run_Greedy
        from land_management_tsp_subdistrict import re_define_start


        tourmanager=TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="subdistrict_table":
                layer1=lyr
            elif lyr.name()=="area":
                layer2=lyr

        list_area=[]
        for feature in layer2.getFeatures():
            list_area.append([feature[feature.fieldNameIndex('area_name')],feature[feature.fieldNameIndex('route')]])
        list_area.sort(key=lambda x:x[1])
      #  print list_area

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        for feature in layer1.getFeatures():
            city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('district')],feature.id())
            tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            #print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        #print "Finished"
        #print "Final distance: " + str(pop.getFittest().getDistance())
       # print "Final distance: " #+ str(besttour.getDistance())
       # print "Solution:"

        rds= re_define_start(besttour)
        besttour=rds.OperateRDS()

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        #route_name=self.ui.lineedit_scenario.text()
        route_name="base"
        sql=""" insert into route_table_sub (subdistrict_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

    def run_main(self):
        from land_management_tsp_main import City
        from land_management_tsp_main import district
        from land_management_tsp_main import TourManager
        from land_management_tsp_main import OPT_2
        from land_management_tsp_main import Run_Greedy


        tourmanager = TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
            elif lyr.name()=="subdistrict_table":
                layer2=lyr
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql="select subdistrict_id,route,scenario from route_table_sub where scenario=?"
        cursor.execute(sql,("base",))
        rows=cursor.fetchall()
        list_area=[]
        for row in rows:
            list_area.append((row[0],row[1],row[2]))


        list_area.sort(key=lambda x:x[1])

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        #layer1=iface.activeLayer()
        for feature in layer1.getFeatures():
            city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('subdistrict_code')],feature.id())
            tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
          #  print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
       # print "Finished"
       # print "Final distance: " #+ str(besttour.getDistance())
       # print "Solution:"


        route_name="base"
        sql=""" insert into route_table2 (farmland_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

    def show_base_route(self):

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        #ルート名を取得
        route_name="base"

        #選択されているルートで対象となっているエリアを抽出する
        cursor=db.cursor()
        #id?pkuid?
        sql="""select farmland_table.centroid_X ,farmland_table.centroid_Y from farmland_table  inner join route_table2 on farmland_table.id=route_table2.farmland_id
        where route_table2.scenario=? """
        cursor.execute(sql,(route_name,))
        rows=cursor.fetchall()
        qpoint=[]
        for row in rows:
            qpoint.append(QgsPoint(row[0],row[1]))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        crs =self.farmland_table.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,u'ベース経路_','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])

    def calc_dist(self):
        ret = QMessageBox.information(None, u"確認", u"あなたはシステム管理者ですか？", QMessageBox.Yes, QMessageBox.No)
        if ret == QMessageBox.No:
            return
        ret = QMessageBox.information(None, u"確認", u"距離テーブルの作成は時間がかかります。作成しますか？", QMessageBox.Yes, QMessageBox.No)
        if ret == QMessageBox.No:
            return
        else:
            pyqgis_processing.show_msgbox(u"距離テーブルの作成を開始します。")

        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                farmland_table=lyr
                break

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'距離テーブル計算中')
        max = farmland_table.featureCount() * farmland_table.featureCount()
        #print max
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        #pbar.setValue(0)



        for feature1 in farmland_table.getFeatures():
            geom=feature1.geometry()
            feature_ids=[feature.id() for feature in farmland_table.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))]
            farmland_table.setSelectedFeatures(feature_ids)
            for feature2 in farmland_table.selectedFeatures():
#
#                 #process_counter=1
#                 id_from=feature1.id()
#                 id_to=feature2.id()
#                 distance_x = abs(feature1[feature1.fieldNameIndex('centroid_X')] - feature2[feature2.fieldNameIndex('centroid_X')])
#                 distance_y = abs(feature1[feature1.fieldNameIndex('centroid_Y')] - feature2[feature2.fieldNameIndex('centroid_Y')])
#                 dist = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
#                 insert_row=(id_from,id_to,dist)
# #                 print id_from
# #                 print id_to
# #                 print dist
#
#                 sql=""" insert into dist_table (id_from,id_to,dist) values(?,?,?)"""
#                 db.execute(sql,insert_row)
                if geom.touches(feature2.geometry()):
                    id_from=feature1.id()
                    id_to=feature2.id()
                    dist=0
                    sql=""" insert into dist_table (id_from,id_to,dist) values(?,?,?)"""
                    insert_row=(id_from,id_to,dist)
                    db.execute(sql,insert_row)


                process_counter=process_counter+1
                #print process_counter
                pbar.setValue(process_counter)
        db.commit()

        pyqgis_processing.show_msgbox(u"距離テーブルの作成が完了しました")

    def merge_on_hd(self):


        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                farmland_table=lyr
            if lyr.name()=="subdistrict_table":
                subdistrict_table=lyr

        flag=True


#         dp=subdistrict_table.dataProvider()
#         features=farmland_table.getFeatures()
#         features=[feature for feature in features]
#
#
#         dp.addFeatures(features)
        #dp.updateExtents()

        i=0
        #memlayer_getFeatures=memlayer.getFeatures()
        #whileが遅いので、forで出来ないか？
        #美しくはないが、forで処理が重くなって行くのを回避出来た

        feature_count=subdistrict_table.featureCount()
#         widget = QWidget()
#         widget.setGeometry(100, 100, 250, 100)
#         widget.setWindowTitle(u'マージ処理中')
#         pmax = feature_count
#         #pmax=1
#         pbar = QProgressBar(widget)
#         pbar.setGeometry(25, 40, 200, 25)
#         pbar.setRange(0, pmax)
#         widget.show()
#         widget.raise_()
#         process_counter=0
#         pbar.setValue(process_counter)
        import sys
        app = QApplication(sys.argv)
        app_processEvents=app.processEvents()
#         subdistrict_table_startEditing=subdistrict_table.startEditing
#         subdistrict_table_endEditCommand=subdistrict_table.endEditCommand

    #    subdistrict_table.startEditing()
#         for j in xrange(feature_count):
        for j in xrange(10):
            #process_counter+=1
            #pbar.setValue(process_counter)
#             pbar.setValue(j)
#             pbar.setFormat(u'処理数'+":"+ str(j))
            self.iface.mapCanvas().refresh()
#             app.processEvents()
            #app_processEvents
            #print process_counter
        #while flag==True:
            flag=False
            #memlayer.dataProvider().forceReload()
            #dp.forceReload()
            #print memlayer.featureCount()
            features=subdistrict_table.getFeatures()
#             features=memlayer_getFeatures
#             memlayer.startEditing()

            #subdistrict_table_startEditing()
            for feature1 in features:
                flag2=False
                feature_ids=[]
                #feature_ids.append(feature1.id())
                #↓全部のフィーチャをループすると時間かかりすぎるので、事前に絞る。
                geom = feature1.geometry()
                geom_touch=geom.touches
#                 for feature2 in memlayer.getFeatures():
                #リスト内包表記に変えてみる
#                 append_ids=feature_ids.append
#                 for feature2 in memlayer.getFeatures(QgsFeatureRequest().setFilterRect(geom1.boundingBox())):
#                     if feature1.geometry().touches(feature2.geometry()):
#                         #feature_ids.append(feature2.id())
#                         append_ids(feature2.id())
                feature_ids=[feature2.id() for feature2 in subdistrict_table.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))
                              if geom_touch(feature2.geometry())]

                subdistrict_table.setSelectedFeatures(feature_ids)
                #geom = feature1.geometry()
                for selected_feature in subdistrict_table.selectedFeatures():
                    #geom=geom.combine(selected_feature.geometry())
                    geom.combine(selected_feature.geometry())
                        #subdistrict_table.deleteFeature(selected_feature.id())

                    flag2=True
                #new_feature=QgsFeature()
                if flag2==True:
                   # subdistrict_table_startEditing()

                    #new_feature=QgsFeature()
                    #new_feature.setGeometry(geom)
                    #subdistrict_table.dataProvider().addFeatures([new_feature])

                    #memlayer.startEditing()
                    #feature1.clearGeometry()
                    #print "clear"
                    #feature1.setGeometry(geom)
                    with edit(subdistrict_table):
                        new_feature=QgsFeature()
                        new_feature.setGeometry(geom)
#                         feature1.setGeometry(QgsGeometry(geom))
                    #print "set"
                        #subdistrict_table.updateFeature(feature1)
                        self.iface.actionAddFeature().trigger()
                        print subdistrict_table.addFeature(new_feature,True)
#                     dp.addFeatures([new_feature])
#                     print "add"
                    #subdistrict_table.commitChanges()
#                     memlayer.commitChanges()
#                     memlayer.endEditCommand()
#                     memlayer.startEditing()
                        print subdistrict_table.deleteFeatures(feature_ids)
#                     dp.deleteFeatures(feature_ids)
                    #subdistrict_table.commitChanges()
                    #print "delete1"
                        print subdistrict_table.deleteFeature(feature1.id())
#                     dp.deleteFeatures([feature1.id()])
#                     print "delete2"
#                     subdistrict_table.commitChanges()
#                     subdistrict_table.endEditCommand()
                    #print "commit"
#                     memlayer.updateExtents()
#                     memlayer.endEditCommand()
#                     self.iface.mapCanvas().refresh()
#                     app_processEvents
                    #memlayer.triggerRepaint()

                    #subdistrict_table.commitChanges()


                    #subdistrict_m.triggerRepaint()
#                     subdistrict_table.dataProvider().forceReload()
#                     subdistrict_table.triggerRepaint()

                    flag=True
                    #i=i+1
                    #pbar.setFormat(u'処理数'+":"+ str(j))
                    #print "merge!"
#                     del feature1
#                     del feature_ids
#                     del geom
#                     gc.collect()
                    break
#                 del feature1
#                 del feature_ids
#                 del geom
#                 gc.collect()

#             if flag==False:
#                 del features
#                 gc.collect()
                break
#             memlayer.endEditCommand()
    #        memlayer_endEditCommand()
#             del features
#             gc.collect()
            #subdistrict_table.commitChanges()
            #subdistrict_table.endEditCommand()
        #subdistrict_table.endEditCommand()
#         process_counter=feature_count
#         pbar.setValue(process_counter)
#         pbar.setFormat(u'処理数'+":"+ str(process_counter))
        #pyqgis_processing.show_msgbox(u"圃区作成が完了しました")















