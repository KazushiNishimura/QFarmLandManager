# from distutils.core import setup
# from distutils.extension import Extension
# from Cython.Distutils import build_ext
# import numpy
#
# setup(
#     cmdclass = {'build_ext': build_ext},
#     #ext_modules = [Extension("land_management_tsp_subdistrict", ["land_management_tsp_subdistrict.pyx"])],
#     ext_modules = [Extension("land_management_tsp1", ["land_management_tsp1.so"])],
#     include_dirs=[numpy.get_include()]
# )
from distutils.core import setup
from Cython.Build import cythonize

setup(
#     name = "land_management_tsp_subdistrict",
#     ext_modules = cythonize('land_management_tsp_subdistrict.pyx'),  # accepts a glob pattern
    name = "land_management_tsp_simple",
    ext_modules = cythonize('land_management_tsp_simple.pyx'),
)