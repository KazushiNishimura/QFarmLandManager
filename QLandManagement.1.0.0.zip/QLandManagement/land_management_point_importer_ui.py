# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_point_importer_ui.ui'
#
# Created: Mon Feb 18 15:31:43 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(238, 595)
        self.gridLayout_2 = QtGui.QGridLayout(Dialog)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.cmbbox_point_layer = QtGui.QComboBox(self.groupBox)
        self.cmbbox_point_layer.setObjectName(_fromUtf8("cmbbox_point_layer"))
        self.verticalLayout.addWidget(self.cmbbox_point_layer)
        self.gridLayout_2.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox_5 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout(self.groupBox_5)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.cmbbox_koaza = QtGui.QComboBox(self.groupBox_5)
        self.cmbbox_koaza.setObjectName(_fromUtf8("cmbbox_koaza"))
        self.horizontalLayout_3.addWidget(self.cmbbox_koaza)
        self.gridLayout.addWidget(self.groupBox_5, 2, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox_4)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.cmbbox_oaza = QtGui.QComboBox(self.groupBox_4)
        self.cmbbox_oaza.setObjectName(_fromUtf8("cmbbox_oaza"))
        self.horizontalLayout_2.addWidget(self.cmbbox_oaza)
        self.gridLayout.addWidget(self.groupBox_4, 1, 0, 1, 1)
        self.groupBox_8 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_8.setObjectName(_fromUtf8("groupBox_8"))
        self.horizontalLayout_5 = QtGui.QHBoxLayout(self.groupBox_8)
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        self.cmbbox_farm_name = QtGui.QComboBox(self.groupBox_8)
        self.cmbbox_farm_name.setObjectName(_fromUtf8("cmbbox_farm_name"))
        self.horizontalLayout_5.addWidget(self.cmbbox_farm_name)
        self.gridLayout.addWidget(self.groupBox_8, 4, 0, 1, 1)
        self.groupBox_6 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_6.setObjectName(_fromUtf8("groupBox_6"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox_6)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.cmbbox_tiban = QtGui.QComboBox(self.groupBox_6)
        self.cmbbox_tiban.setObjectName(_fromUtf8("cmbbox_tiban"))
        self.verticalLayout_2.addWidget(self.cmbbox_tiban)
        self.gridLayout.addWidget(self.groupBox_6, 3, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox_3)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.cmbbox_city = QtGui.QComboBox(self.groupBox_3)
        self.cmbbox_city.setObjectName(_fromUtf8("cmbbox_city"))
        self.horizontalLayout.addWidget(self.cmbbox_city)
        self.gridLayout.addWidget(self.groupBox_3, 0, 0, 1, 1)
        self.groupBox_9 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_9.setObjectName(_fromUtf8("groupBox_9"))
        self.horizontalLayout_6 = QtGui.QHBoxLayout(self.groupBox_9)
        self.horizontalLayout_6.setObjectName(_fromUtf8("horizontalLayout_6"))
        self.cmbbox_owner_name = QtGui.QComboBox(self.groupBox_9)
        self.cmbbox_owner_name.setObjectName(_fromUtf8("cmbbox_owner_name"))
        self.horizontalLayout_6.addWidget(self.cmbbox_owner_name)
        self.gridLayout.addWidget(self.groupBox_9, 5, 0, 1, 1)
        self.groupBox_10 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_10.setObjectName(_fromUtf8("groupBox_10"))
        self.horizontalLayout_7 = QtGui.QHBoxLayout(self.groupBox_10)
        self.horizontalLayout_7.setObjectName(_fromUtf8("horizontalLayout_7"))
        self.cmbbox_land_area = QtGui.QComboBox(self.groupBox_10)
        self.cmbbox_land_area.setObjectName(_fromUtf8("cmbbox_land_area"))
        self.horizontalLayout_7.addWidget(self.cmbbox_land_area)
        self.gridLayout.addWidget(self.groupBox_10, 6, 0, 1, 1)
        self.gridLayout_2.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.btn_read_point = QtGui.QPushButton(Dialog)
        self.btn_read_point.setObjectName(_fromUtf8("btn_read_point"))
        self.gridLayout_2.addWidget(self.btn_read_point, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "圃場点データの読込み", None))
        self.groupBox.setTitle(_translate("Dialog", "点データの指定", None))
        self.groupBox_2.setTitle(_translate("Dialog", "フィールド対応", None))
        self.groupBox_5.setTitle(_translate("Dialog", "小字", None))
        self.groupBox_4.setTitle(_translate("Dialog", "大字", None))
        self.groupBox_8.setTitle(_translate("Dialog", "耕作者", None))
        self.groupBox_6.setTitle(_translate("Dialog", "地番", None))
        self.groupBox_3.setTitle(_translate("Dialog", "市町村", None))
        self.groupBox_9.setTitle(_translate("Dialog", "地権者", None))
        self.groupBox_10.setTitle(_translate("Dialog", "面積", None))
        self.btn_read_point.setText(_translate("Dialog", "点データの読込み", None))

