# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_dock_ui.ui'
#
# Created: Thu Feb 21 13:08:11 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_DockWidget(object):
    def setupUi(self, DockWidget):
        DockWidget.setObjectName(_fromUtf8("DockWidget"))
        DockWidget.resize(379, 431)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.gridLayout = QtGui.QGridLayout(self.dockWidgetContents)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tabWidget = QtGui.QTabWidget(self.dockWidgetContents)
        self.tabWidget.setObjectName(_fromUtf8("tabWidget"))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.verticalLayout = QtGui.QVBoxLayout(self.tab)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_input_information = QtGui.QPushButton(self.tab)
        self.btn_input_information.setObjectName(_fromUtf8("btn_input_information"))
        self.verticalLayout.addWidget(self.btn_input_information)
        self.btn_open_point_data_importer = QtGui.QPushButton(self.tab)
        self.btn_open_point_data_importer.setObjectName(_fromUtf8("btn_open_point_data_importer"))
        self.verticalLayout.addWidget(self.btn_open_point_data_importer)
        self.btn_merge = QtGui.QPushButton(self.tab)
        self.btn_merge.setObjectName(_fromUtf8("btn_merge"))
        self.verticalLayout.addWidget(self.btn_merge)
        self.btn_write_subdistid = QtGui.QPushButton(self.tab)
        self.btn_write_subdistid.setObjectName(_fromUtf8("btn_write_subdistid"))
        self.verticalLayout.addWidget(self.btn_write_subdistid)
        self.btn_write_area_id = QtGui.QPushButton(self.tab)
        self.btn_write_area_id.setObjectName(_fromUtf8("btn_write_area_id"))
        self.verticalLayout.addWidget(self.btn_write_area_id)
        self.btn_area_connect = QtGui.QPushButton(self.tab)
        self.btn_area_connect.setObjectName(_fromUtf8("btn_area_connect"))
        self.verticalLayout.addWidget(self.btn_area_connect)
        self.btn_calc_dist = QtGui.QPushButton(self.tab)
        self.btn_calc_dist.setObjectName(_fromUtf8("btn_calc_dist"))
        self.verticalLayout.addWidget(self.btn_calc_dist)
        self.btn_make_base_route = QtGui.QPushButton(self.tab)
        self.btn_make_base_route.setObjectName(_fromUtf8("btn_make_base_route"))
        self.verticalLayout.addWidget(self.btn_make_base_route)
        self.btn_show_base_route = QtGui.QPushButton(self.tab)
        self.btn_show_base_route.setObjectName(_fromUtf8("btn_show_base_route"))
        self.verticalLayout.addWidget(self.btn_show_base_route)
        self.tabWidget.addTab(self.tab, _fromUtf8(""))
        self.tab_2 = QtGui.QWidget()
        self.tab_2.setObjectName(_fromUtf8("tab_2"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.tab_2)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.btn_renderer_current = QtGui.QPushButton(self.tab_2)
        self.btn_renderer_current.setObjectName(_fromUtf8("btn_renderer_current"))
        self.verticalLayout_2.addWidget(self.btn_renderer_current)
        self.btn_manual_planning = QtGui.QPushButton(self.tab_2)
        self.btn_manual_planning.setObjectName(_fromUtf8("btn_manual_planning"))
        self.verticalLayout_2.addWidget(self.btn_manual_planning)
        self.btn_partial_planning = QtGui.QPushButton(self.tab_2)
        self.btn_partial_planning.setObjectName(_fromUtf8("btn_partial_planning"))
        self.verticalLayout_2.addWidget(self.btn_partial_planning)
        self.btn_all_planning = QtGui.QPushButton(self.tab_2)
        self.btn_all_planning.setObjectName(_fromUtf8("btn_all_planning"))
        self.verticalLayout_2.addWidget(self.btn_all_planning)
        self.btn_all_planing2 = QtGui.QPushButton(self.tab_2)
        self.btn_all_planing2.setObjectName(_fromUtf8("btn_all_planing2"))
        self.verticalLayout_2.addWidget(self.btn_all_planing2)
        self.btn_read_csv = QtGui.QPushButton(self.tab_2)
        self.btn_read_csv.setObjectName(_fromUtf8("btn_read_csv"))
        self.verticalLayout_2.addWidget(self.btn_read_csv)
        self.btn_adhoc_input = QtGui.QPushButton(self.tab_2)
        self.btn_adhoc_input.setObjectName(_fromUtf8("btn_adhoc_input"))
        self.verticalLayout_2.addWidget(self.btn_adhoc_input)
        self.tabWidget.addTab(self.tab_2, _fromUtf8(""))
        self.gridLayout.addWidget(self.tabWidget, 3, 0, 1, 2)
        self.cmbbox_label = QtGui.QComboBox(self.dockWidgetContents)
        self.cmbbox_label.setObjectName(_fromUtf8("cmbbox_label"))
        self.gridLayout.addWidget(self.cmbbox_label, 0, 1, 1, 1)
        self.label = QtGui.QLabel(self.dockWidgetContents)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(self.dockWidgetContents)
        self.label_2.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.btn_show_attribute_table = QtGui.QPushButton(self.dockWidgetContents)
        self.btn_show_attribute_table.setObjectName(_fromUtf8("btn_show_attribute_table"))
        self.gridLayout.addWidget(self.btn_show_attribute_table, 1, 1, 1, 1)
        self.label_3 = QtGui.QLabel(self.dockWidgetContents)
        self.label_3.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)
        self.btn_attribute_table = QtGui.QPushButton(self.dockWidgetContents)
        self.btn_attribute_table.setObjectName(_fromUtf8("btn_attribute_table"))
        self.gridLayout.addWidget(self.btn_attribute_table, 2, 1, 1, 1)
        DockWidget.setWidget(self.dockWidgetContents)

        self.retranslateUi(DockWidget)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(DockWidget)

    def retranslateUi(self, DockWidget):
        DockWidget.setWindowTitle(_translate("DockWidget", "メインメニュー", None))
        self.btn_input_information.setText(_translate("DockWidget", "圃場基本情報", None))
        self.btn_open_point_data_importer.setText(_translate("DockWidget", "点データの読込み", None))
        self.btn_merge.setText(_translate("DockWidget", "圃区データの作成", None))
        self.btn_write_subdistid.setText(_translate("DockWidget", "圃区IDの書込み", None))
        self.btn_write_area_id.setText(_translate("DockWidget", "エリアIDの書込み", None))
        self.btn_area_connect.setText(_translate("DockWidget", "エリア接続設定", None))
        self.btn_calc_dist.setText(_translate("DockWidget", "距離テーブルの作成", None))
        self.btn_make_base_route.setText(_translate("DockWidget", "圃場ネットワークデータの作成", None))
        self.btn_show_base_route.setText(_translate("DockWidget", "圃場ネットワークの表示", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("DockWidget", "圃場データ管理", None))
        self.btn_renderer_current.setText(_translate("DockWidget", "現状土地利用の表示", None))
        self.btn_manual_planning.setText(_translate("DockWidget", "手動土地利用調整", None))
        self.btn_partial_planning.setText(_translate("DockWidget", "耕作者間土地利用調整", None))
        self.btn_all_planning.setText(_translate("DockWidget", "全域土地利用調整", None))
        self.btn_all_planing2.setText(_translate("DockWidget", "全域土地利用調整2", None))
        self.btn_read_csv.setText(_translate("DockWidget", "CSVファイルからの設定読込", None))
        self.btn_adhoc_input.setText(_translate("DockWidget", "土地利用調整簡易入力", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("DockWidget", "土地利用調整", None))
        self.label.setText(_translate("DockWidget", "圃場のラベリング", None))
        self.label_2.setText(_translate("DockWidget", "圃場絞込み", None))
        self.btn_show_attribute_table.setText(_translate("DockWidget", "圃場の検索・選択", None))
        self.label_3.setText(_translate("DockWidget", "属性テーブル", None))
        self.btn_attribute_table.setText(_translate("DockWidget", "テーブルを開く", None))

