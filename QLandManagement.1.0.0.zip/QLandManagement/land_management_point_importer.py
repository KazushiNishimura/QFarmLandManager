# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_point_importer_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import csv
import sqlite3
from multiprocessing.pool import ApplyResult

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.point_layer=None
        self.list_point_layer_fields=[]
        #self.load_csv()

        proc=pyqgis_processing

        #proc.remove_join()
#         proc.clear_query(self.farmland_table)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_point_layer()

#         self.populate_cmbbox_kind()

#         self.render_farmland()
        self.connect(self.ui.cmbbox_point_layer,SIGNAL("currentIndexChanged(const QString&)"),self.point_layer_changed)
        self.connect(self.ui.btn_read_point,SIGNAL("clicked()"),self.import_point_data)


#         self.farmland_table.selectionChanged.connect(self.selection_changed)
#         self.connect(self.ui.btn_update_info,SIGNAL("clicked()"),self.update_info)
#         self.connect(self.ui.btn_remarks1,SIGNAL("clicked()"),self.update_remarks1)
#         self.connect(self.ui.btn_remarks2,SIGNAL("clicked()"),self.update_remarks2)
#         self.connect(self.ui.btn_update_area_selected,SIGNAL("clicked()"),self.update_area_selected)
#         self.connect(self.ui.btn_update_all,SIGNAL("clicked()"),self.update_area_all)
#         self.connect(self.ui.btn_write_geom,SIGNAL("clicked()"),self.write_geom)
#         self.connect(self.ui.btn_farmland_code,SIGNAL("clicked()"),self.update_farmland_code)
#         self.connect(self.ui.btn_district,SIGNAL("clicked()"),self.update_district)
#         self.connect(self.ui.btn_kind,SIGNAL("clicked()"),self.update_kind)
#         self.connect(self.ui.btn_area,SIGNAL("clicked()"),self.update_area)

    def populate_cmbbox_point_layer(self):
        proc=pyqgis_processing
        #self.ui.cmbbox_point_layer.addItem(u"指定無し")
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            self.ui.cmbbox_point_layer.addItem(lyr.name())

    def point_layer_changed(self):

        self.list_point_layer_fields=[]
        self.ui.cmbbox_city.clear()
        self.ui.cmbbox_oaza.clear()
        self.ui.cmbbox_koaza.clear()
        self.ui.cmbbox_tiban.clear()
        #self.ui.cmbbox_edaban.clear()
        self.ui.cmbbox_farm_name.clear()
        self.ui.cmbbox_owner_name.clear()
        self.ui.cmbbox_land_area.clear()
        self.ui.cmbbox_city.addItem(u"指定無し")
        self.ui.cmbbox_oaza.addItem(u"指定無し")
        self.ui.cmbbox_koaza.addItem(u"指定無し")
        self.ui.cmbbox_tiban.addItem(u"指定無し")
        #self.ui.cmbbox_edaban.addItem(u"指定無し")
        self.ui.cmbbox_farm_name.addItem(u"指定無し")
        self.ui.cmbbox_owner_name.addItem(u"指定無し")
        self.ui.cmbbox_land_area.addItem(u"指定無し")

        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()==self.ui.cmbbox_point_layer.currentText():
                self.point_layer=lyr
                break

        for field in lyr.fields() :
            self.list_point_layer_fields.append(field.name())

        for field_name in self.list_point_layer_fields:
            self.ui.cmbbox_city.addItem(field_name)
            self.ui.cmbbox_oaza.addItem(field_name)
            self.ui.cmbbox_koaza.addItem(field_name)
            self.ui.cmbbox_tiban.addItem(field_name)
            #self.ui.cmbbox_edaban.addItem(field_name)
            self.ui.cmbbox_farm_name.addItem(field_name)
            self.ui.cmbbox_owner_name.addItem(field_name)
            self.ui.cmbbox_land_area.addItem(field_name)

    def import_point_data(self):

        farmland_table_features=self.farmland_table.getFeatures()
        farmland_count=self.farmland_table.featureCount()

        crsTransform = QgsCoordinateTransform(self.point_layer.crs(), self.farmland_table.crs())
        #crsTransform = QgsCoordinateTransform(self.farmland_table.crs(),self.point_layer.crs())

        crs = self.farmland_table.crs().authid()
        memlayer=QgsVectorLayer("Point?crs=" + crs,'point_temp','memory')

        mempr=memlayer.dataProvider()
        #features=self.point_layer.getFeatures()
        features = [feat for feat in self.point_layer.getFeatures()]
        for feature in features:
            feature.geometry().transform(crsTransform)
        attr = self.farmland_table.dataProvider().fields().toList()
        mempr.addAttributes(attr)
        memlayer.updateFields()
        mempr.addFeatures(features)
#         for feature in memlayer.getFeatures():
#             feature.geometry().transform(crsTransform)
#         for feature in features:
#             p_feature = QgsFeature()
#             geom = feature.geometry()
#             geom.transform(crsTransform)
#             p_feature.setGeometry(geom)
#             p_feature.setAttributes(feature.attributes())
#             mempr.addFeatures([p_feature])
#             memlayer.updateExtents()


        QgsMapLayerRegistry.instance().addMapLayers([memlayer])

#         crs_point=self.point_layer.crs()
#         crs_farmland=self.farmland_table.crs()
#         trans_crs = QgsCoordinateTransform(crs_farmland,crs_point)

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'ポイントデータ読み込み中')
        pmax = farmland_count
        pbar = QProgressBar(widget)
        #pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, pmax)
        widget.show()
        widget.raise_()
        process_counter=0
        pbar.setValue(process_counter)

        self.farmland_table.startEditing()
        i=0
        feature_ids=[]
        for farmland in farmland_table_features:
            #print farmland.id()
            city=None
            oaza=None
            koaza=None
            tiban=[]
            farmer=[]
            owner=[]
            land_area=0
            pbar.setValue(i)
            pbar.setFormat(u'処理数'+":"+ str(i))
            point_features=[]
            geom = farmland.geometry()
#             geom=copy.copy(geom_p)
#             geom.transform(trans_crs)
            #print geom
            geom_touch=geom.touches
            geom_intersect=geom.intersects
            feature_ids=[feature.id() for feature in memlayer.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))]
            #feature_ids=[feature.id() for feature in self.point_layer.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))]
            #feature_ids=[feature.id() for feature in farmland_table.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))]
            #feature_ids=[feature.id() for feature in self.point_layer.getFeatures()]
            #print feature_ids
           # return
            memlayer.setSelectedFeatures(feature_ids)
            #self.point_layer.setSelectedFeatures(feature_ids)
            for selected_feature in memlayer.selectedFeatures():
            #for selected_feature in self.point_layer.selectedFeatures():
                if geom_intersect(selected_feature.geometry()):
                    point_features.append(selected_feature)

            for point in point_features:
               # print point.id()
                if self.ui.cmbbox_city.currentText()!=u"指定無し":
                    city=point[point.fieldNameIndex(self.ui.cmbbox_city.currentText())]
                if self.ui.cmbbox_oaza.currentText()!=u"指定無し":
                    oaza=point[point.fieldNameIndex(self.ui.cmbbox_oaza.currentText())]
                if self.ui.cmbbox_koaza.currentText()!=u"指定無し":
                    koaza=point[point.fieldNameIndex(self.ui.cmbbox_koaza.currentText())]
                if self.ui.cmbbox_tiban.currentText()!=u"指定無し":
                    tiban.append(point[point.fieldNameIndex(self.ui.cmbbox_tiban.currentText())])
                if self.ui.cmbbox_farm_name.currentText()!=u"指定無し":
                    farmer.append(point[point.fieldNameIndex(self.ui.cmbbox_farm_name.currentText())])
                if self.ui.cmbbox_owner_name.currentText()!=u"指定無し":
                    owner.append(point[point.fieldNameIndex(self.ui.cmbbox_owner_name.currentText())])
                if self.ui.cmbbox_land_area.currentText()!=u"指定無し":
                    land_area=land_area+point[point.fieldNameIndex(self.ui.cmbbox_land_area.currentText())]

            farmer=list(set(farmer))
            owner=list(set(owner))

#             print city
#             print oaza
#             print koaza
#             print tiban
#             print farmer
#             print owner
#             print land_area

            if len(farmer)==1:
                if city is not None:
                   # print city
                    farmland[farmland.fieldNameIndex("address1")]=city
                if oaza is not None:
                 #   print oaza
                    farmland[farmland.fieldNameIndex("address2")]=oaza
                if koaza is not None:
                 #   print koaza
                    farmland[farmland.fieldNameIndex("address3")]=koaza
                if len(tiban)>0:
                 #   print tiban
                    tiban_string=""
                    for item_tiban in tiban:
                        try:
                            item_tiban=str(item_tiban)
                        except:
                            pass
                        tiban_string=tiban_string+item_tiban+","
                    tiban_string=tiban_string[:-1]
                    farmland[farmland.fieldNameIndex("address4")]=tiban_string
                for item_farmer in farmer:
                    farmland[farmland.fieldNameIndex("farm_name")]=item_farmer

               # print farmer
                if len(owner)>0:
                    owner_string=""
                    for item_owner in owner:
                        owner_string=owner_string+item_owner+","
                    owner_string=owner_string[:-1]
                   # print owner_string
                    farmland[farmland.fieldNameIndex("owner_name")]=owner_string
                if land_area!=0:
                    farmland[farmland.fieldNameIndex("land_area")]=land_area
            self.farmland_table.updateFeature(farmland)


            i+=1

        self.farmland_table.commitChanges()
        self.farmland_table.endEditCommand()
        #QgsMapLayerRegistry.instance().removeMapLayers([memlayer])

