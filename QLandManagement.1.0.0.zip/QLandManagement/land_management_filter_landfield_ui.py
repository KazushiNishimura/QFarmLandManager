# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_filter_landfield_ui.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(448, 342)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tabwidget = QtGui.QTabWidget(Dialog)
        self.tabwidget.setObjectName(_fromUtf8("tabwidget"))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.gridLayout_2 = QtGui.QGridLayout(self.tab)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.lineedit_farmer = QtGui.QLineEdit(self.tab)
        self.lineedit_farmer.setObjectName(_fromUtf8("lineedit_farmer"))
        self.gridLayout_2.addWidget(self.lineedit_farmer, 0, 1, 1, 1)
        self.label = QtGui.QLabel(self.tab)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.btn_search_farmer = QtGui.QPushButton(self.tab)
        self.btn_search_farmer.setObjectName(_fromUtf8("btn_search_farmer"))
        self.gridLayout_2.addWidget(self.btn_search_farmer, 0, 2, 1, 1)
        self.tablewidget_farmer = QtGui.QTableWidget(self.tab)
        self.tablewidget_farmer.setObjectName(_fromUtf8("tablewidget_farmer"))
        self.tablewidget_farmer.setColumnCount(0)
        self.tablewidget_farmer.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_farmer, 1, 0, 1, 3)
        self.btn_query_farmer = QtGui.QPushButton(self.tab)
        self.btn_query_farmer.setObjectName(_fromUtf8("btn_query_farmer"))
        self.gridLayout_2.addWidget(self.btn_query_farmer, 2, 0, 1, 3)
        self.tabwidget.addTab(self.tab, _fromUtf8(""))
        self.tab_2 = QtGui.QWidget()
        self.tab_2.setObjectName(_fromUtf8("tab_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.tab_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn_query_owner = QtGui.QPushButton(self.tab_2)
        self.btn_query_owner.setObjectName(_fromUtf8("btn_query_owner"))
        self.gridLayout_3.addWidget(self.btn_query_owner, 2, 0, 1, 3)
        self.label_2 = QtGui.QLabel(self.tab_2)
        self.label_2.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_3.addWidget(self.label_2, 0, 0, 1, 1)
        self.btn_search_owner = QtGui.QPushButton(self.tab_2)
        self.btn_search_owner.setObjectName(_fromUtf8("btn_search_owner"))
        self.gridLayout_3.addWidget(self.btn_search_owner, 0, 2, 1, 1)
        self.tablewidget_owner = QtGui.QTableWidget(self.tab_2)
        self.tablewidget_owner.setObjectName(_fromUtf8("tablewidget_owner"))
        self.tablewidget_owner.setColumnCount(0)
        self.tablewidget_owner.setRowCount(0)
        self.gridLayout_3.addWidget(self.tablewidget_owner, 1, 0, 1, 3)
        self.lineedit_owner = QtGui.QLineEdit(self.tab_2)
        self.lineedit_owner.setObjectName(_fromUtf8("lineedit_owner"))
        self.gridLayout_3.addWidget(self.lineedit_owner, 0, 1, 1, 1)
        self.tabwidget.addTab(self.tab_2, _fromUtf8(""))
        self.tab_3 = QtGui.QWidget()
        self.tab_3.setObjectName(_fromUtf8("tab_3"))
        self.gridLayout_4 = QtGui.QGridLayout(self.tab_3)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tablewidget_address = QtGui.QTableWidget(self.tab_3)
        self.tablewidget_address.setObjectName(_fromUtf8("tablewidget_address"))
        self.tablewidget_address.setColumnCount(0)
        self.tablewidget_address.setRowCount(0)
        self.gridLayout_4.addWidget(self.tablewidget_address, 0, 0, 1, 1)
        self.btn_query_address = QtGui.QPushButton(self.tab_3)
        self.btn_query_address.setObjectName(_fromUtf8("btn_query_address"))
        self.gridLayout_4.addWidget(self.btn_query_address, 1, 0, 1, 1)
        self.tabwidget.addTab(self.tab_3, _fromUtf8(""))
        self.gridLayout.addWidget(self.tabwidget, 0, 0, 1, 1)
        self.btn_reset_filter = QtGui.QPushButton(Dialog)
        self.btn_reset_filter.setObjectName(_fromUtf8("btn_reset_filter"))
        self.gridLayout.addWidget(self.btn_reset_filter, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        self.tabwidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "圃場検索・絞込み", None))
        self.label.setText(_translate("Dialog", "検索ワード", None))
        self.btn_search_farmer.setText(_translate("Dialog", "検索", None))
        self.btn_query_farmer.setText(_translate("Dialog", "絞込み", None))
        self.tabwidget.setTabText(self.tabwidget.indexOf(self.tab), _translate("Dialog", "耕作者で検索", None))
        self.btn_query_owner.setText(_translate("Dialog", "絞込み", None))
        self.label_2.setText(_translate("Dialog", "検索ワード", None))
        self.btn_search_owner.setText(_translate("Dialog", "検索", None))
        self.tabwidget.setTabText(self.tabwidget.indexOf(self.tab_2), _translate("Dialog", "地権者で検索", None))
        self.btn_query_address.setText(_translate("Dialog", "絞込み", None))
        self.tabwidget.setTabText(self.tabwidget.indexOf(self.tab_3), _translate("Dialog", "住所で検索", None))
        self.btn_reset_filter.setText(_translate("Dialog", "絞込みのリセット", None))

