# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_planning_csv_ui.ui'
#
# Created: Thu Feb 21 15:48:19 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(894, 578)
        self.gridLayout_2 = QtGui.QGridLayout(Dialog)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.lineedit_export_folder = QtGui.QLineEdit(self.groupBox)
        self.lineedit_export_folder.setObjectName(_fromUtf8("lineedit_export_folder"))
        self.gridLayout.addWidget(self.lineedit_export_folder, 0, 1, 1, 1)
        self.btn_write_csv = QtGui.QPushButton(self.groupBox)
        self.btn_write_csv.setObjectName(_fromUtf8("btn_write_csv"))
        self.gridLayout.addWidget(self.btn_write_csv, 1, 0, 1, 2)
        self.btn_export_folder = QtGui.QPushButton(self.groupBox)
        self.btn_export_folder.setObjectName(_fromUtf8("btn_export_folder"))
        self.gridLayout.addWidget(self.btn_export_folder, 0, 0, 1, 1)
        self.gridLayout_2.addWidget(self.groupBox, 0, 0, 1, 1)
        self.tabWidget = QtGui.QTabWidget(Dialog)
        self.tabWidget.setObjectName(_fromUtf8("tabWidget"))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.tab)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.tablewidget_farmers = QtGui.QTableWidget(self.tab)
        self.tablewidget_farmers.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tablewidget_farmers.setObjectName(_fromUtf8("tablewidget_farmers"))
        self.tablewidget_farmers.setColumnCount(0)
        self.tablewidget_farmers.setRowCount(0)
        self.verticalLayout_3.addWidget(self.tablewidget_farmers)
        self.btn_renderer = QtGui.QPushButton(self.tab)
        self.btn_renderer.setObjectName(_fromUtf8("btn_renderer"))
        self.verticalLayout_3.addWidget(self.btn_renderer)
        self.tabWidget.addTab(self.tab, _fromUtf8(""))
        self.tab_2 = QtGui.QWidget()
        self.tab_2.setObjectName(_fromUtf8("tab_2"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.tab_2)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.tablewidget_farmers_area = QtGui.QTableWidget(self.tab_2)
        self.tablewidget_farmers_area.setObjectName(_fromUtf8("tablewidget_farmers_area"))
        self.tablewidget_farmers_area.setColumnCount(0)
        self.tablewidget_farmers_area.setRowCount(0)
        self.verticalLayout_4.addWidget(self.tablewidget_farmers_area)
        self.btn_show_scattered = QtGui.QPushButton(self.tab_2)
        self.btn_show_scattered.setObjectName(_fromUtf8("btn_show_scattered"))
        self.verticalLayout_4.addWidget(self.btn_show_scattered)
        self.tabWidget.addTab(self.tab_2, _fromUtf8(""))
        self.gridLayout_2.addWidget(self.tabWidget, 0, 1, 2, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.groupBox_3 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox_3)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.btn_import_file_scenario = QtGui.QPushButton(self.groupBox_3)
        self.btn_import_file_scenario.setObjectName(_fromUtf8("btn_import_file_scenario"))
        self.horizontalLayout.addWidget(self.btn_import_file_scenario)
        self.lineedit_import_file_scenario = QtGui.QLineEdit(self.groupBox_3)
        self.lineedit_import_file_scenario.setObjectName(_fromUtf8("lineedit_import_file_scenario"))
        self.horizontalLayout.addWidget(self.lineedit_import_file_scenario)
        self.verticalLayout_2.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox_4)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.btn_import_file_remove = QtGui.QPushButton(self.groupBox_4)
        self.btn_import_file_remove.setObjectName(_fromUtf8("btn_import_file_remove"))
        self.horizontalLayout_2.addWidget(self.btn_import_file_remove)
        self.lineedit_import_file_remove = QtGui.QLineEdit(self.groupBox_4)
        self.lineedit_import_file_remove.setObjectName(_fromUtf8("lineedit_import_file_remove"))
        self.horizontalLayout_2.addWidget(self.lineedit_import_file_remove)
        self.verticalLayout_2.addWidget(self.groupBox_4)
        self.tablewidget_configuration = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_configuration.setObjectName(_fromUtf8("tablewidget_configuration"))
        self.tablewidget_configuration.setColumnCount(0)
        self.tablewidget_configuration.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_configuration)
        self.groupBox_5 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox_5)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.lineedit_scenario = QtGui.QLineEdit(self.groupBox_5)
        self.lineedit_scenario.setObjectName(_fromUtf8("lineedit_scenario"))
        self.verticalLayout.addWidget(self.lineedit_scenario)
        self.btn_make_plan = QtGui.QPushButton(self.groupBox_5)
        self.btn_make_plan.setObjectName(_fromUtf8("btn_make_plan"))
        self.verticalLayout.addWidget(self.btn_make_plan)
        self.verticalLayout_2.addWidget(self.groupBox_5)
        self.gridLayout_2.addWidget(self.groupBox_2, 1, 0, 1, 1)

        self.retranslateUi(Dialog)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "CSVファイルからの調整案作成", None))
        self.groupBox.setTitle(_translate("Dialog", "現状耕作者情報の出力", None))
        self.btn_write_csv.setText(_translate("Dialog", "意向確認用リストを出力する", None))
        self.btn_export_folder.setText(_translate("Dialog", "保存先フォルダの指定", None))
        self.btn_renderer.setText(_translate("Dialog", "表示の更新", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("Dialog", "耕作者一覧", None))
        self.btn_show_scattered.setText(_translate("Dialog", "圃場分散度の算出・表示", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("Dialog", "耕作者・エリア毎集計結果", None))
        self.groupBox_2.setTitle(_translate("Dialog", "CSVファイルからの設定読み込み", None))
        self.groupBox_3.setTitle(_translate("Dialog", "面積配分シナリオ", None))
        self.btn_import_file_scenario.setText(_translate("Dialog", "CSVファイルの指定", None))
        self.groupBox_4.setTitle(_translate("Dialog", "除外設定", None))
        self.btn_import_file_remove.setText(_translate("Dialog", "除外圃場リストの指定", None))
        self.groupBox_5.setTitle(_translate("Dialog", "調整案の作成", None))
        self.btn_make_plan.setText(_translate("Dialog", "調整案の作成", None))

