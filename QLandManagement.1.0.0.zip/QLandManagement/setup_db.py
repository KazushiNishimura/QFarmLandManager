# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
#from renderer_contract_plan_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv
#from resource import *
import shutil




def copy_from_resource(crs):
    if sys.platform == "win32":
        if not os.path.exists("c:/qfarmlandmanager"):
            os.mkdir("c:/qfarmlandmanager")
    else:
        if not os.path.exists(os.path.expanduser('~/qfarmlandmanager')):
            os.mkdir(os.path.expanduser('~/qfarmlandmanager'))

    prj_file=os.path.expanduser('~/.qgis2/python/plugins/QLandManagement/resource/landmanagement.qgs')  
    #db_file=os.path.expanduser('~/.qgis2/python/plugins/QLandManagement/resource/management_db.sqlite') %("/"+str(crs))
    #land_list_file=os.path.expanduser(u'~/.qgis2/python/plugins/QAgriSupport/resource%s/農地台帳.csv') %("/"+str(crs))
    #mail_list_file=os.path.expanduser(u'~/.qgis2/python/plugins/QAgriSupport/resource%s/メールリスト.csv') %("/"+str(crs))
    if sys.platform == "win32":
        #prj_file=os.path.expanduser('~/.qgis2/python/plugins/QLandManagement/resource/landmanagement.qgs')  
        shutil.copy(prj_file, "c:/qfarmlandmanager/landmanagement.qgs")
        #shutil.copy(db_file, "c:/qfarmlandmanager/management_db.sqlite")
        #shutil.copy(land_list_file,u"c:/gisdata/農地台帳.csv")
        #land_list_file= u"c:/gisdata/農地台帳.csv"

        #shutil.copy(land_list_file,u"c:/gisdata/メールリスト.csv")
        #mail_list_file=u"c:/gisdata/メールリスト.csv"

    else:
        #prj_file=os.path.expanduser('~/.qgis2/python/plugins/QLandManagement/resource/landmanagement.qgs')  
        prj_to=os.path.expanduser('~/qfarmlandmanager/landmanagement.qgs')
        shutil.copy(prj_file, prj_to)
        #db_to=os.path.expanduser('~/qfarmlandmanager/management_db.sqlite')
        #shutil.copy(db_file, db_to)
       # land_list_file=os.path.expanduser(u'~/gisdata/農地台帳.csv')
        #shutil.copy(land_list_file,land_list_to)
        #mail_list_file=os.path.expanduser(u'~/gisdata/メールリスト.csv')
        #shutil.copy(mail_list_file,mail_list_to)

#     table_csv=open(land_list_file, 'w')
#     dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
#     list_csv=[]
#     field_name1=u"エリア"
#     field_name2=u"呼名"
#     field_name3=u"地名地番"
#     field_name4=u"台帳面積"
#     field_name5=u"実利用面積"
#     field_name6=u"地権者"
# 
#     list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
#                      field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"')])
#     dataWriter.writerows(list_csv)
#     table_csv.close()
# 
#     table_csv=open(mail_list_file, 'w')
#     dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
#     list_csv=[]
#     field_name1=u"名前"
#     field_name2=u"アドレス"
#     field_name3=u"種別"
# 
# 
#     list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"')])
#     dataWriter.writerows(list_csv)
#     table_csv.close()
# 
#     os.mkdir("c:/gisdata/mapimage")


def create_tables(crs):

    #from pyspatialite import dbapi2 as db
    if sys.platform == "win32":
        db_path="c:/qfarmlandmanager/land_db.sqlite"
    else:
        db_path=os.path.expanduser('~/qfarmlandmanager/land_db.sqlite')

    conn = sqlite3.connect(db_path)
    conn.enable_load_extension(True)
    
    #mod_spatialite (recommended)
    conn.execute('SELECT load_extension("mod_spatialite")')   
    conn.execute('SELECT InitSpatialMetaData(1);')  
    
    # libspatialite
#     conn.execute('SELECT load_extension("libspatialite")')
#     conn.execute('SELECT InitSpatialMetaData();')
    
#     sql = 'SELECT InitSpatialMetadata()'
#     cursor=conn.cursor()
#     cursor.execute(sql)

    #圃場図テーブル
    sql_string = """CREATE TABLE  farmland_table (
                    id INTEGER NOT NULL PRIMARY KEY,
                    district text,
                    district_code  integer,
                    subdistrict_code integer,
                    farmland_code  text ,
                    land_area FLOAT,
                    address1 text,
                    address2 text,
                    address3 text,
                    address4 text,
                    address5 text,
                    farm_name text,
                    owner_name text,
                    remarks1 text,
                    remarks2 text,
                    borrowing_year integer,
                    centroid_X FLOAT,
                    centroid_Y FLOAT)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    sql_string ="""SELECT AddGeometryColumn('farmland_table','geometry', %d, 'POLYGON', 'XY')""" %(return_epsg(crs))
    cursor.execute(sql_string)
    conn.commit()
    print "make_farmland"
    
    #圃区テーブル
    sql_string = """CREATE TABLE  subdistrict_table (
                    id INTEGER NOT NULL PRIMARY KEY,
                    district text,
                    district_code  integer,
                    centroid_X FLOAT,
                    centroid_Y FLOAT)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    sql_string ="""SELECT AddGeometryColumn('subdistrict_table','geom', %d, 'POLYGON', 'XY')""" %(return_epsg(crs))
    cursor.execute(sql_string)
    conn.commit()
    print "make_subdistrict"
    #エリアテーブル
    sql_string = """CREATE TABLE  area (
                    id INTEGER NOT NULL PRIMARY KEY,
                    area_name text,
                    route integer)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    sql_string ="""SELECT AddGeometryColumn('area','geom', %d, 'POLYGON', 'XY')""" %(return_epsg(crs))
    cursor.execute(sql_string)
    conn.commit()
    print "area"
    
    #結果テーブル（result_table）
    sql_string = """CREATE TABLE  result_table (
                    id  integer NOT NULL PRIMARY KEY,
                    scenario text NOT NULL,
                    farmland_code  text NOT NULL,
                    farm_name  text not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    conn.commit()
    
    #シナリオテーブル（scenario_table）
    sql_string = """CREATE TABLE  scenario_table (
                    id  integer NOT NULL PRIMARY KEY,
                    scenario text NOT NULL)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    conn.commit()
    
    #ルート名テーブル（route_name_table）
    sql_string = """CREATE TABLE  route_name_table (
                    id  integer NOT NULL PRIMARY KEY,
                    route_name text NOT NULL)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    conn.commit()
    
    #耕区ルートテーブル（route_table2）
    sql_string = """CREATE TABLE  route_table2 (
                    id  integer NOT NULL PRIMARY KEY,
                    farmland_id integer not null,
                    route integer not null,
                    scenario text NOT NULL)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    conn.commit()
    
    #圃区ルートテーブル（route_table_sub）
    sql_string = """CREATE TABLE  route_table_sub (
                    id  integer NOT NULL PRIMARY KEY,
                    subdistrict_id integer not null,
                    route integer not null,
                    scenario text NOT NULL)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    conn.commit()
    
    #距離テーブル（dist_table）
    sql_string = """CREATE TABLE  dist_table (
                    id  integer NOT NULL PRIMARY KEY,
                    id_from integer not null,
                    id_to integer not null,
                    dist float)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    conn.commit()

    

def select_crs(dlg):
    p_iface=iface
    from selection_crs import Dialog
    pdlg=Dialog(dlg)
    pdlg.show()
    pdlg.exec_()

def return_epsg(i):
    if i==1:
        epsg=6669
    elif i==2:
        epsg=6670
    elif i==3:
        epsg=6671
    elif i==4:
        epsg=6672
    elif i==5:
        epsg=6673
    elif i==6:
        epsg=6674
    elif i==7:
        epsg=6675
    elif i==8:
        epsg=6676
    elif i==9:
        epsg=6677
    elif i==10:
        epsg=6678
    elif i==11:
        epsg=6679
    elif i==12:
        epsg=6680
    elif i==13:
        epsg=6681
    elif i==14:
        epsg=6682
    elif i==15:
        epsg=6683
    elif i==16:
        epsg=6684
    elif i==17:
        epsg=6685
    elif i==18:
        epsg=6686
    elif i==19:
        epsg=6687
    else:
        print i
    return epsg










