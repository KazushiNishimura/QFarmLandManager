# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_update_info_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import csv
import sqlite3
import types

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.list_csv=[]
        #self.load_csv()

        proc=pyqgis_processing

        #proc.remove_join()
#         proc.clear_query(self.farmland_table)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

#         self.populate_cmbbox_kind()

#         self.render_farmland()

        self.farmland_table.selectionChanged.connect(self.selection_changed)
        self.connect(self.ui.btn_update_info,SIGNAL("clicked()"),self.update_info)
        self.connect(self.ui.btn_remarks1,SIGNAL("clicked()"),self.update_remarks1)
        self.connect(self.ui.btn_remarks2,SIGNAL("clicked()"),self.update_remarks2)
#         self.connect(self.ui.btn_update_area_selected,SIGNAL("clicked()"),self.update_area_selected)
#         self.connect(self.ui.btn_update_all,SIGNAL("clicked()"),self.update_area_all)
#         self.connect(self.ui.btn_write_geom,SIGNAL("clicked()"),self.write_geom)
#         self.connect(self.ui.btn_farmland_code,SIGNAL("clicked()"),self.update_farmland_code)
#         self.connect(self.ui.btn_district,SIGNAL("clicked()"),self.update_district)
#         self.connect(self.ui.btn_kind,SIGNAL("clicked()"),self.update_kind)
#         self.connect(self.ui.btn_area,SIGNAL("clicked()"),self.update_area)

   

    def selection_changed(self):
        #self.population_tablewidget_land()
        self.get_farmland_info()
        
    def update_info(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        
            #pyqgis_processing.show_msgbox(u"圃場名を入力してください")
            
        for feature in features:
            #圃場名
            if self.ui.lineEdit_farmland_code.text()!='':
                new_value={feature.fieldNameIndex('farmland_code'):self.ui.lineEdit_farmland_code.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                self.ui.lbl_landfield.setText(self.ui.lineEdit_farmland_code.text())

            #地区名
            if self.ui.lineEdit_district.text()!='':
                new_value={feature.fieldNameIndex('district'):self.ui.lineEdit_district.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                
            #面積
            if self.ui.lineEdit_area.text()!='':
                try:
                    new_value={feature.fieldNameIndex('land_area'):float(self.ui.lineEdit_area.text())}
                    self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                except:
                    pyqgis_processing.show_msgbox(u"面積には数値を入力してください。面積更新はスキップします。")
            
            #市町村
            if self.ui.lineedit_ad1.text()!='':
                new_value={feature.fieldNameIndex('address1'):self.ui.lineedit_ad1.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            #大字
            if self.ui.lineedit_ad2.text()!='':
                new_value={feature.fieldNameIndex('address2'):self.ui.lineedit_ad2.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            #小字
            if self.ui.lineedit_ad3.text()!='':
                new_value={feature.fieldNameIndex('address3'):self.ui.lineedit_ad3.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            #地番
            if self.ui.lineedit_ad4.text()!='':
                new_value={feature.fieldNameIndex('address4'):self.ui.lineedit_ad4.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            #枝番
            if self.ui.lineedit_ad5.text()!='':
                new_value={feature.fieldNameIndex('address5'):self.ui.lineedit_ad5.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            #耕作者
            if self.ui.lineedit_farmer.text()!='':
                new_value={feature.fieldNameIndex('farm_name'):self.ui.lineedit_farmer.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            #地権者
            if self.ui.lineedit_owner.text()!='':
                new_value={feature.fieldNameIndex('owner_name'):self.ui.lineedit_owner.text()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                
            #借入年
            if self.ui.lineedit_borrowing_year.text()!='':
                try:
                    new_value={feature.fieldNameIndex('borrowing_year'):int(self.ui.lineedit_borrowing_year.text())}
                    self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                except:
                    pass
                
            self.get_farmland_info()
            farmland_table=pyqgis_processing.get_farmland_table()
            #farmland_table.dataProvider().forceReload()
            farmland_table.triggerRepaint()
            pyqgis_processing.show_msgbox(u"圃場データを更新しました")   
            break
        
    def update_remarks1(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        
            #pyqgis_processing.show_msgbox(u"圃場名を入力してください")
            
        for feature in features:
            #圃場名
            if self.ui.textedit_remarks1.toPlainText()!='':
                new_value={feature.fieldNameIndex('remarks1'):self.ui.textedit_remarks1.toPlainText()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                
                
            else:
                new_value={feature.fieldNameIndex('remarks1'):""}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            self.get_farmland_info()
            pyqgis_processing.show_msgbox(u"圃場データを更新しました")   
            break
    def update_remarks2(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        
            #pyqgis_processing.show_msgbox(u"圃場名を入力してください")
            
        for feature in features:
            #圃場名
            if self.ui.textedit_remarks2.toPlainText()!='':
                new_value={feature.fieldNameIndex('remarks2'):self.ui.textedit_remarks2.toPlainText()}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
                
                
            else:
                new_value={feature.fieldNameIndex('remarks2'):""}
                self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            self.get_farmland_info()
            pyqgis_processing.show_msgbox(u"圃場データを更新しました")   
            break

    def update_farmland_code(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        if self.ui.lineEdit_farmland_code.text()=='':
            pyqgis_processing.show_msgbox(u"圃場名を入力してください")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('farmland_code'):self.ui.lineEdit_farmland_code.text()}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            self.ui.lbl_landfield.setText(self.ui.lineEdit_farmland_code.text())
            break

    def update_district(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        if self.ui.lineEdit_district.text()=='':
            pyqgis_processing.show_msgbox(u"地区名を入力してください")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('district'):self.ui.lineEdit_district.text()}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})

            break
    def update_kind(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('kind'):self.ui.cmbbox_kind.currentText()}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})

            break

    def update_area(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        if self.ui.lineEdit_area.text()=='':
            pyqgis_processing.show_msgbox(u"面積を入力してください")
            return
        for feature in features:
            try:
                new_value={feature.fieldNameIndex('land_area'):float(self.ui.lineEdit_area.text())}
            except:
                pyqgis_processing.show_msgbox(u"数値を入力してください")
                return
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            self.get_farmland_info()

            break

    def get_farmland_info(self):
        features=self.farmland_table.selectedFeatures()
        for feature in features:
            try:
                self.ui.lineEdit_farmland_code.setText(feature['farmland_code'])
                self.ui.lbl_landfield.setText(feature['farmland_code'])
            except:
                self.ui.lineEdit_farmland_code.setText('')
                self.ui.lbl_landfield.setText('')
            try:
                self.ui.lineEdit_district.setText(feature['district'])
            except:
                self.ui.lineEdit_district.setText('')
            
            try:
                self.ui.lineEdit_area.setText(str(feature['land_area']))
            except:
                self.ui.lineEdit_area.setText('')
            
            try:
                self.ui.lineedit_farmer.setText(feature['farm_name'])
            except:
                self.ui.lineedit_farmer.setText('')    
            try:
                self.ui.lineedit_owner.setText(feature['owner_name'])
            except:
                self.ui.lineedit_owner.setText('')    
            try:
                self.ui.lineedit_ad1.setText(feature['address1'])
            except:
                self.ui.lineedit_ad1.setText('')    
            try:
                self.ui.lineedit_ad2.setText(feature['address2'])
            except:
                self.ui.lineedit_ad2.setText('')    
            try:
                self.ui.lineedit_ad3.setText(feature['address3'])
            except:
                self.ui.lineedit_ad3.setText('')  
            try:
                self.ui.lineedit_ad4.setText(feature['address4'])
            except:
                self.ui.lineedit_ad4.setText('')  
            try:
                self.ui.lineedit_ad5.setText(feature['address5'])
            except:
                self.ui.lineedit_ad5.setText('')   
            try:
                if str(feature['borrowing_year']) !='NULL':
                    self.ui.lineedit_borrowing_year.setText(str(feature['borrowing_year']))
                        
                else:
                    self.ui.lineedit_borrowing_year.setText('')    
            except:
                self.ui.lineedit_borrowing_year.setText('')        
                
            try:
                self.ui.textedit_remarks1.setText(feature['remarks1'])
            except:
                self.ui.textedit_remarks1.setText('')  
            try:
                self.ui.textedit_remarks2.setText(feature['remarks2'])
            except:
                self.ui.textedit_remarks2.setText('')  

            break

    

    def update_area_selected(self):
        area=float(self.ui.lbl_area.text())
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('land_area'):area}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            break

    




