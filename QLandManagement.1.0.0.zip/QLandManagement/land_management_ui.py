# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_ui.ui'
#
# Created: Sat Feb 18 15:33:39 2017
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

