# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_main_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import random
import time
from sympy.logic.boolalg import false


class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.remove_join()
        self.join_table()

        self.ui.rbtn_all.setChecked(1)

        self.populate_cmbbox()
        self.populate_tablewidget_area()
        self.populate_tablewidget_farmer()
        self.populate_tablewidget_route()
        self.populate_tablewidget_scenario()

        self.connect(self.ui.btn_run, SIGNAL("clicked()"),self.run)
        self.connect(self.ui.btn_make_solution,SIGNAL("clicked()"),self.make_solution)
        self.connect(self.ui.btn_show_route,SIGNAL("clicked()"),self.show_route)
        self.connect(self.ui.btn_renderer,SIGNAL("clicked()"),self.render_result)
        self.ui.tablewidget_scenario.itemClicked.connect(self.tabelwidget_scenario_clicked)







    def run(self):
        if self.ui.rbtn_all.isChecked()==True:
            self.run_subdistrict()
            self.run_main()
            self.populate_tablewidget_route()
        elif self.ui.rbtn_area.isChecked()==True:
            self.run_subdistrict_partial()
            self.run_main_partial()
            self.populate_tablewidget_route()
        elif self.ui.rbtn_select.isChecked()==True:
            self.run_main_select()
            self.populate_tablewidget_route()



    def populate_cmbbox(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():

            if isinstance(lyr, QgsVectorLayer):
                self.ui.cmbbox_area.addItem(lyr.name())
                self.ui.cmbbox_subdistrict.addItem(lyr.name())
                self.ui.cmbbox_farmland.addItem(lyr.name())

    def make_area_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        #エリアのリストを作成
        cursor=db.cursor()
        sql="select area_name from area"
        cursor.execute(sql)
        list_area=cursor.fetchall()

        return list_area

    def make_farmer_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        list_area=self.make_area_list()
        list_area.sort()
        list_farmer=[]
        for area in list_area:
            cursor=db.cursor()
            sql="select district ,farm_name from farmland_table where district=?"
            cursor.execute(sql,(area[0],))
            rows=cursor.fetchall()
            for row in rows:
                if  row  not in list_farmer:
                    list_farmer.append(row)

        list_farmer_area=[]
        for item in list_farmer:
            cursor=db.cursor()
            sql="select total (land_area) from farmland_table where district=? and farm_name=?"
            value=(item[0],item[1])
            cursor.execute(sql,value)
            total=cursor.fetchmany(1)
            list_farmer_area.append((item[0],item[1],total[0][0]))

        return list_farmer_area

    def populate_tablewidget_area(self):
        self.ui.tablewidget_area.clear()
        self.ui.tablewidget_area.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"エリア名"]
        self.ui.tablewidget_area.setColumnCount(len(headers))
        self.ui.tablewidget_area.setHorizontalHeaderLabels(headers)
        #self.tableWidget_crop.setEditTriggers(QAbstractItemView.NoEditTriggers)
        #self.tableWidget_crop.setSelectionBehavior(QAbstractItemView.SelectRows)
        list_area=self.make_area_list()
        list_area.sort()
        i=0
        for area in list_area:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tablewidget_area.insertRow(i)
            self.ui.tablewidget_area.setItem(i,0,chk)
            self.ui.tablewidget_area.setItem(i,1,QTableWidgetItem(area[0]))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_area.resizeColumnsToContents()

    def populate_tablewidget_farmer(self):
        self.ui.tablewidget_farmer.clear()
        self.ui.tablewidget_farmer.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"エリア名",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_farmer.setColumnCount(len(headers))
        self.ui.tablewidget_farmer.setHorizontalHeaderLabels(headers)
        list_farmer=self.make_farmer_list()
        #print list_farmer
        i=0
        for farmer in list_farmer:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_farmer.insertRow(i)
            self.ui.tablewidget_farmer.setItem(i,0,chk)
            self.ui.tablewidget_farmer.setItem(i,1,QTableWidgetItem(farmer[0]))
            self.ui.tablewidget_farmer.setItem(i,2,QTableWidgetItem(farmer[1]))
            self.ui.tablewidget_farmer.setItem(i,3,QTableWidgetItem(str(round(farmer[2],1))))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_farmer.resizeColumnsToContents()

    def run_subdistrict(self):
        from land_management_tsp_subdistrict import City
        from land_management_tsp_subdistrict import district
        from land_management_tsp_subdistrict import TourManager
        from land_management_tsp_subdistrict import OPT_2
        from land_management_tsp_subdistrict import Run_Greedy
        from land_management_tsp_subdistrict import re_define_start




        start = time.time()
        tourmanager=TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="subdistrict_table":
                layer1=lyr
            elif lyr.name()=="area":
                layer2=lyr

        list_area=[]
        for feature in layer2.getFeatures():
            list_area.append([feature[feature.fieldNameIndex('area_name')],feature[feature.fieldNameIndex('route')]])
        list_area.sort(key=lambda x:x[1])
      #  print list_area

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        for feature in layer1.getFeatures():
            city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('district')],feature.id())
            tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        print "Finished"
        #print "Final distance: " + str(pop.getFittest().getDistance())
        print "Final distance: " #+ str(besttour.getDistance())
        print "Solution:"

        rds= re_define_start(besttour)
        besttour=rds.OperateRDS()

        result= str(besttour).strip('|')
        list_points=result.split('|')
        qpoint=[]
        for point in list_points:
            xy=point.split(',')
            qpoint.append(QgsPoint(float(xy[0]),float(xy[1])))
            #print point

#         settings = QSettings()
#         # Take the "CRS for new layers" config, overwrite it while loading layers and...
#         oldProjValue = settings.value( "/Projections/defaultBehaviour", "prompt", type=str )
#         settings.setValue( "/Projections/defaultBehaviour", "useProject" )


        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        #memlayer=QgsVectorLayer('LineString','Line_subdistrict','memory')
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_subdistrict','memory')
        #memlayer.setCrs(layer1.crs(),True)
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])

        #settings.setValue( "/Projections/defaultBehaviour", oldProjValue )

        iface.mapCanvas().refresh()

        print('finis')

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        route_name=self.ui.lineedit_route.text()
        sql=""" insert into route_table_sub (subdistrict_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

        elapsed_time = time.time() - start
        print ("elapsed_time:{0}".format(elapsed_time)) + "[sec]"

    def run_main(self):
        from land_management_tsp_main import City
        from land_management_tsp_main import district
        from land_management_tsp_main import TourManager
        from land_management_tsp_main import OPT_2
        from land_management_tsp_main import Run_Greedy
        start = time.time()

        tourmanager = TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
            elif lyr.name()=="subdistrict_table":
                layer2=lyr
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql="select subdistrict_id,route,scenario from route_table_sub where scenario=?"
        cursor.execute(sql,(self.ui.lineedit_route.text(),))
        rows=cursor.fetchall()
        list_area=[]
        for row in rows:
            list_area.append((row[0],row[1],row[2]))


        list_area.sort(key=lambda x:x[1])

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        #layer1=iface.activeLayer()
        for feature in layer1.getFeatures():
            city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('subdistrict_code')],feature.id())
            tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        print "Finished"
        print "Final distance: " #+ str(besttour.getDistance())
        print "Solution:"

        result= str(besttour).strip('|')
        list_points=result.split('|')
        qpoint=[]
        for point in list_points:
            xy=point.split(',')
            qpoint.append(QgsPoint(float(xy[0]),float(xy[1])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        #memlayer=QgsVectorLayer('LineString','Line','memory')
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_main','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])
        iface.mapCanvas().refresh()

        print('finis')


        route_name=self.ui.lineedit_route.text()
        sql=""" insert into route_table2 (farmland_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

        sql=""" insert into route_name_table (route_name) values(?)"""
        db.execute(sql,(route_name,))
        db.commit()

#

        elapsed_time = time.time() - start
        print ("elapsed_time:{0}".format(elapsed_time)) + "[sec]"

    def populate_tablewidget_route(self):
        self.ui.tablewidget_route.clear()
        self.ui.tablewidget_route.setRowCount(0)
        self.ui.tablewidget_route.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"ルート名"]
        self.ui.tablewidget_route.setColumnCount(len(headers))
        self.ui.tablewidget_route.setHorizontalHeaderLabels(headers)

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        cursor=db.cursor()
        sql="""select route_name from route_name_table  """
        cursor.execute(sql)
        rows=cursor.fetchall()
        i=0
        for scenario in rows:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_route.insertRow(i)
            self.ui.tablewidget_route.setItem(i,0,chk)
            self.ui.tablewidget_route.setItem(i,1,QTableWidgetItem(scenario[0]))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_farmer.resizeColumnsToContents()


    def make_solution(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        #選択されているルート名を取得
        row_count=self.ui.tablewidget_route.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_route.item(i,0).checkState()==Qt.Checked:
                route_name=self.ui.tablewidget_route.item(i,1).text()
                break
        #選択されているルートで対象となっているエリアを抽出する
        cursor=db.cursor()
        sql="""select farmland_table.district from farmland_table  inner join route_table2 on farmland_table.id=route_table2.farmland_id
        where route_table2.scenario=? """
        cursor.execute(sql,(route_name,))
        rows=cursor.fetchall()
        list_area=[]
        for row in rows:
            if row[0] not in list_area:
                list_area.append(row[0])
        list_area.sort()
        print list_area
        #耕作者・エリア別の面積はテーブルウィジェットから取得→クエリで抽出し直す
        list_farmer=[]
        for area in list_area:
            cursor=db.cursor()
            #sql="select district ,farm_name from farmland_table where district=?"
            sql="""select farmland_table.district,farmland_table.farm_name from farmland_table
            inner join route_table2 on farmland_table.id=route_table2.farmland_id
            where farmland_table.district=? and route_table2.scenario=?  """
            cursor.execute(sql,(area[0],route_name))
            rows=cursor.fetchall()
            for row in rows:
                if  row  not in list_farmer:
                    list_farmer.append(row)
        print list_farmer
        list_farmer_area=[]
        for item in list_farmer:
            cursor=db.cursor()
            sql="""select total (farmland_table.land_area) from farmland_table
            inner join route_table2 on farmland_table.id=route_table2.farmland_id
            where farmland_table.district=? and farmland_table.farm_name=? and route_table2.scenario=?"""
            value=(item[0],item[1],route_name)
            cursor.execute(sql,value)
            total=cursor.fetchmany(1)
            list_farmer_area.append((item[0],item[1],total[0][0]))

        #list_farmer_area=[]

#         row_count=self.ui.tablewidget_farmer.rowCount()
#         for i in range(row_count):
#             if self.ui.tablewidget_farmer.item(i,1).text() in list_area:
#                 list_farmer_area.append((self.ui.tablewidget_farmer.item(i,1).text(),
#                                           self.ui.tablewidget_farmer.item(i,2).text(),
#                                            self.ui.tablewidget_farmer.item(i,3).text() ))

        for area in list_area:
            list_partial=filter(lambda x: x[0]==area, list_farmer_area)
            district=area
            sql="""select farmland_table.farmland_code ,farmland_table.land_area,route_table2.route from farmland_table inner join
            route_table2 on farmland_table.id = route_table2.farmland_id  where farmland_table.district=? and route_table2.scenario=? """
            cursor=db.cursor()
            cursor.execute(sql,(district,route_name))
            rows=cursor.fetchall()
            list_land=[]
            for row in rows:
                list_land.append(row)
            list_land.sort(key=lambda x:x[2])
            i=0
            for item in list_partial:
                farm_name=item[1]
                farm_area=float(item[2])
                area_count=0
                while i <len(list_land):
                    if area_count>farm_area:
                        break
                    else:
    #                     print area
    #                     print farmer
    #                     print row[0]
                        #print list_land[i]
                        area_count=area_count+list_land[i][1]
                        #sql_update="update farmland_table set solution=? where farmland_code=?"
                        sql_insert="""insert into result_table ( scenario,farmland_code,farm_name) values(?,?,?) """
                        #db.execute(sql_update,(farm_name,list_land[i][0],))
                        db.execute(sql_insert,(self.ui.lineedit_scenario.text(),list_land[i][0],farm_name,))
                        i=i+1
                db.commit()
        db.execute("insert into scenario_table (scenario) values(?)",(self.ui.lineedit_scenario.text(),))
        db.commit()

        self.populate_tablewidget_scenario()

    def show_route(self):
        #選択されているルートを取得
        row_count=self.ui.tablewidget_route.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_route.item(i,0).checkState()==Qt.Checked:
                route_name=self.ui.tablewidget_route.item(i,1).text()
                break
        #ルートテーブルと圃場テーブルを結合して重心座標を取得
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql="""select farmland_table.centroid_X ,farmland_table.centroid_Y,route_table2.route from farmland_table inner join
            route_table2 on farmland_table.id = route_table2.farmland_id  where route_table2.scenario=? """
        cursor=db.cursor()
        cursor.execute(sql,(route_name,))
        rows=cursor.fetchall()
        list_route=[]
        for row in rows:
            list_route.append((row[0],row[1],row[2]))
        list_route.sort(key=lambda x:x[2])
        qpoint=[]
        for point in list_route:
            qpoint.append(QgsPoint(float(point[0]),float(point[1])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        #memlayer=QgsVectorLayer('LineString','Line','memory')
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
                break
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,'route_temp','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])
        iface.mapCanvas().refresh()


    def join_table(self):
        farmland_table=self.get_farmland_table()
        result_table=self.get_result_table()
        joinObject = QgsVectorJoinInfo()
        joinObject.joinLayerId = result_table.id()
        joinObject.joinFieldName = "farmland_code"
        joinObject.targetFieldName = "farmland_code"
        joinObject.memoryCache=True
        farmland_table.addJoin(joinObject)

    def get_farmland_table(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=='farmland_table':
                layer1=lyr
                return layer1
                break
    def get_result_table(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=='result_table':
                layer1=lyr
                return layer1
                break
    def remove_join(self):
        farmland_table=self.get_farmland_table()
        result_table=self.get_result_table()
        farmland_table.removeJoin(result_table.id())

    def populate_tablewidget_scenario(self):
        self.ui.tablewidget_scenario.clear()
        self.ui.tablewidget_scenario.setRowCount(0)
        self.ui.tablewidget_scenario.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"シナリオ名"]
        self.ui.tablewidget_scenario.setColumnCount(len(headers))
        self.ui.tablewidget_scenario.setHorizontalHeaderLabels(headers)
        #self.ui.tablewidget_.setSelectionBehavior(QAbstractItemView.SelectRows)

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")

        cursor=db.cursor()
        sql="""select scenario from scenario_table  """
        cursor.execute(sql)
        rows=cursor.fetchall()
        i=0
        for scenario in rows:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_scenario.insertRow(i)
            #self.ui.tablewidget_scenario.setItem(i,0,chk)
            self.ui.tablewidget_scenario.setItem(i,0,QTableWidgetItem(scenario[0]))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_scenario.resizeColumnsToContents()

    def populate_tablewidget_result(self,scenario):
        self.ui.tablewidget_result.clear()
        self.ui.tablewidget_result.setRowCount(0)
        self.ui.tablewidget_result.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"エリア名",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_result.setColumnCount(len(headers))
        self.ui.tablewidget_result.setHorizontalHeaderLabels(headers)
        list_farmer=self.make_farmer_list2(scenario)
        #print list_farmer
        i=0
        for farmer in list_farmer:
#             chk =QTableWidgetItem()
#             chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
#             chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_result.insertRow(i)
            #self.ui.tablewidget_farmer.setItem(i,0,chk)
            self.ui.tablewidget_result.setItem(i,0,QTableWidgetItem(farmer[0]))
            self.ui.tablewidget_result.setItem(i,1,QTableWidgetItem(farmer[1]))
            self.ui.tablewidget_result.setItem(i,2,QTableWidgetItem(str(round(farmer[2],1))))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_result.resizeColumnsToContents()

    def make_farmer_list2(self,scenario):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        list_area=self.make_area_list()
        list_area.sort()
        list_farmer=[]
        for area in list_area:
            cursor=db.cursor()
            #sql="select district ,farm_name from farmland_table where district=?"
            sql="""select farmland_table.district,result_table.farm_name from farmland_table
            inner join result_table on farmland_table.farmland_code=result_table.farmland_code
            where farmland_table.district=? and result_table.scenario=? """
            cursor.execute(sql,(area[0],scenario))
            rows=cursor.fetchall()
            for row in rows:
                if  row  not in list_farmer:
                    list_farmer.append(row)

        list_farmer_area=[]
        for item in list_farmer:
            cursor=db.cursor()
            sql="""select total (farmland_table.land_area) from farmland_table
            inner join result_table on farmland_table.farmland_code=result_table.farmland_code
            where farmland_table.district=? and result_table.farm_name=? and result_table.scenario=?"""
            value=(item[0],item[1],scenario)
            cursor.execute(sql,value)
            total=cursor.fetchmany(1)
            list_farmer_area.append((item[0],item[1],total[0][0]))

        return list_farmer_area

    def tabelwidget_scenario_clicked(self):
        row_count=self.ui.tablewidget_scenario.rowCount()
        row = self.ui.tablewidget_scenario.currentRow()
        print row

        for i in range(row_count):
            if i==row:
                if self.ui.tablewidget_scenario.item(i,0).isSelected() == True:
                    scenario=self.ui.tablewidget_scenario.item(i,0).text()
                    self.populate_tablewidget_result(scenario)
            else:
                self.ui.tablewidget_scenario.item(i,0).setSelected(False)

    def get_farmer_list_from_result(self):
        row_count=self.ui.tablewidget_result.rowCount()
        list_farmer=[]
        for i in range(row_count):
            if self.ui.tablewidget_result.item(i,1).text() not in list_farmer:
                list_farmer.append(self.ui.tablewidget_result.item(i,1).text())
        list_farmer.sort()
        return list_farmer

    def create_renderer_rule(self):
        row = self.ui.tablewidget_scenario.currentRow()
        scenario=self.ui.tablewidget_scenario.item(row,0).text()
        list_rule=[]
        list_farmer=self.get_farmer_list_from_result()
        for farmer in list_farmer:
            label_string=   farmer
            query_string= '\"result_table_farm_name\" ='+ '\''+ farmer +'\' and \"result_table_scenario\" =' + '\''+ scenario +'\''
            list_rule.append([label_string,query_string])
        return list_rule

    def render_result(self):
        self.set_query_result_table()
        self.remove_join()
        self.join_table()
        list_rule=self.create_renderer_rule()
        farmland_table=self.get_farmland_table()
        print list_rule
        pyqgis_processing.renderer_map1(farmland_table, list_rule)
        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()

    def set_query_result_table(self):
        result_table=self.get_result_table()
        row = self.ui.tablewidget_scenario.currentRow()
        scenario=self.ui.tablewidget_scenario.item(row,0).text()
        print scenario
        query_string=""" "scenario" = '""" + scenario + """' """
        pyqgis_processing.set_query(result_table, query_string)

    def run_subdistrict_partial(self):
        from land_management_tsp_subdistrict import City
        from land_management_tsp_subdistrict import district
        from land_management_tsp_subdistrict import TourManager
        from land_management_tsp_subdistrict import OPT_2
        from land_management_tsp_subdistrict import Run_Greedy




        start = time.time()
        tourmanager=TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="subdistrict_table":
                layer1=lyr
            elif lyr.name()=="area":
                layer2=lyr

        list_area_=[]

        row_count=self.ui.tablewidget_area.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_area.item(i,0).checkState()==Qt.Checked:
                list_area_.append(self.ui.tablewidget_area.item(i,1).text())


        list_area=[]
        for feature in layer2.getFeatures():
            if feature[feature.fieldNameIndex('area_name')] in list_area_:
                list_area.append([feature[feature.fieldNameIndex('area_name')],feature[feature.fieldNameIndex('route')]])
        list_area.sort(key=lambda x:x[1])
      #  print list_area

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        for feature in layer1.getFeatures():
            if feature[feature.fieldNameIndex('district')] in list_area_:
                city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('district')],feature.id())
                tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        print "Finished"
        #print "Final distance: " + str(pop.getFittest().getDistance())
        print "Final distance: " #+ str(besttour.getDistance())
        print "Solution:"

        result= str(besttour).strip('|')
        list_points=result.split('|')
        qpoint=[]
        for point in list_points:
            xy=point.split(',')
            qpoint.append(QgsPoint(float(xy[0]),float(xy[1])))
            #print point

#         settings = QSettings()
#         # Take the "CRS for new layers" config, overwrite it while loading layers and...
#         oldProjValue = settings.value( "/Projections/defaultBehaviour", "prompt", type=str )
#         settings.setValue( "/Projections/defaultBehaviour", "useProject" )


        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        #memlayer=QgsVectorLayer('LineString','Line_subdistrict','memory')
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_subdistrict','memory')
        #memlayer.setCrs(layer1.crs(),True)
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])

        #settings.setValue( "/Projections/defaultBehaviour", oldProjValue )

        iface.mapCanvas().refresh()

        print('finis')

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        route_name=self.ui.lineedit_route.text()
        sql=""" insert into route_table_sub (subdistrict_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

        elapsed_time = time.time() - start
        print ("elapsed_time:{0}".format(elapsed_time)) + "[sec]"

    def run_main_partial(self):
        from land_management_tsp_main import City
        from land_management_tsp_main import district
        from land_management_tsp_main import TourManager
        from land_management_tsp_main import OPT_2
        from land_management_tsp_main import Run_Greedy
        start = time.time()

        tourmanager = TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
            elif lyr.name()=="subdistrict_table":
                layer2=lyr
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql="select subdistrict_id,route,scenario from route_table_sub where scenario=?"
        cursor.execute(sql,(self.ui.lineedit_route.text(),))
        rows=cursor.fetchall()
        list_area=[]
        list_area_=[]
        for row in rows:
            list_area.append((row[0],row[1],row[2]))
            list_area_.append(row[0])


        list_area.sort(key=lambda x:x[1])

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        #layer1=iface.activeLayer()
        for feature in layer1.getFeatures():
            if feature[feature.fieldNameIndex('subdistrict_code')] in list_area_:
                city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('subdistrict_code')],feature.id())
                tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        print "Finished"
        print "Final distance: " #+ str(besttour.getDistance())
        print "Solution:"

        result= str(besttour).strip('|')
        list_points=result.split('|')
        qpoint=[]
        for point in list_points:
            xy=point.split(',')
            qpoint.append(QgsPoint(float(xy[0]),float(xy[1])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        #memlayer=QgsVectorLayer('LineString','Line','memory')
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_main','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])
        iface.mapCanvas().refresh()

        print('finis')


        route_name=self.ui.lineedit_route.text()
        sql=""" insert into route_table2 (farmland_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

        sql=""" insert into route_name_table (route_name) values(?)"""
        db.execute(sql,(route_name,))
        db.commit()

#

        elapsed_time = time.time() - start
        print ("elapsed_time:{0}".format(elapsed_time)) + "[sec]"



    def run_main_select(self):
        from land_management_tsp_simple import City
        #from land_management_tsp_simple import district
        from land_management_tsp_simple import TourManager
        from land_management_tsp_simple import OPT_2
        from land_management_tsp_simple import Run_Greedy
        start = time.time()

        tourmanager = TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
            elif lyr.name()=="subdistrict_table":
                layer2=lyr

        list_farmer=[]

        row_count=self.ui.tablewidget_farmer.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmer.item(i,0).checkState()==Qt.Checked:
                list_farmer.append((self.ui.tablewidget_farmer.item(i,1).text(),self.ui.tablewidget_farmer.item(i,2).text()))


        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
#         cursor=db.cursor()
#         sql="select subdistrict_id,route,scenario from route_table_sub where scenario=?"
#         cursor.execute(sql,(self.ui.lineedit_route.text(),))
#         rows=cursor.fetchall()
#         list_area=[]
#         list_area_=[]
#         for row in rows:
#             list_area.append((row[0],row[1],row[2]))
#             list_area_.append(row[0])
#
#
#         list_area.sort(key=lambda x:x[1])

#         for d in list_area:
#             dist=district(d[0],d[1])
#             tourmanager.adddistrict(dist)

        #layer1=iface.activeLayer()
        for feature in layer1.getFeatures():
            if (feature[feature.fieldNameIndex('district')],feature[feature.fieldNameIndex('farm_name')]) in list_farmer:
                city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id())
                tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        print "Finished"
        print "Final distance: " #+ str(besttour.getDistance())
        print "Solution:"


        result= str(besttour).strip('|')
        list_points=result.split('|')
        print list_points
        qpoint=[]
        for point in list_points:
            xy=point.split(',')
            qpoint.append(QgsPoint(float(xy[0]),float(xy[1])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        #memlayer=QgsVectorLayer('LineString','Line','memory')
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_main','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])
        iface.mapCanvas().refresh()

        print('finis')


        route_name=self.ui.lineedit_route.text()
        sql=""" insert into route_table2 (farmland_id,route,scenario) values(?,?,?)"""
        for city in besttour:
            insert_row=(city.getid(),city.getroute(),route_name)
            db.execute(sql,insert_row)
        db.commit()

        sql=""" insert into route_name_table (route_name) values(?)"""
        db.execute(sql,(route_name,))
        db.commit()

#

        elapsed_time = time.time() - start
        print ("elapsed_time:{0}".format(elapsed_time)) + "[sec]"









