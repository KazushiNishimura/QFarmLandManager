# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_filter_landfield_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import random
import time
import math



class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.farmland_table=pyqgis_processing.get_farmland_table()


        #self.ui.rbtn_all.setChecked(1)


        #self.populate_tablewidget_farmers()
        #self.populate_tablewidget_farmers_area()
        #self.populate_tablewidget_scenario()


        #self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
        #self.connect(self.ui.btn_calc_route, SIGNAL("clicked()"),self.calc_route)
        #self.connect(self.ui.btn_show_route,SIGNAL("clicked()"),self.show_route)
#         self.connect(self.ui.btn_start,SIGNAL("clicked()"),self.start_edit)
#         self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
#         self.connect(self.ui.btn_re_calc,SIGNAL("clicked()"),self.re_calc)
#         self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_info_selected)
        self.connect(self.ui.btn_search_farmer,SIGNAL("clicked()"),self.populate_tablewidget_farmer) 
        self.connect(self.ui.btn_search_owner,SIGNAL("clicked()"),self.populate_tablewidget_owner)  
        self.connect(self.ui.btn_query_farmer,SIGNAL("clicked()"),self.filter_farmer)  
        self.connect(self.ui.btn_query_owner,SIGNAL("clicked()"),self.filter_owner)  
        self.connect(self.ui.btn_query_address,SIGNAL("clicked()"),self.filter_address)  
        self.connect(self.ui.btn_reset_filter,SIGNAL("clicked()"),self.reset_filter)  
        self.populate_tablewidget_address()
        
    def populate_tablewidget_address(self):
        self.ui.tablewidget_address.clear()
        self.ui.tablewidget_address.setRowCount(0)
        self.ui.tablewidget_address.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"住所1",u"住所2",u"住所3"]
        self.ui.tablewidget_address.setColumnCount(len(headers))
        self.ui.tablewidget_address.setHorizontalHeaderLabels(headers)
        
        
        list_address=self.make_address_list()
        #print list_farmer
        i=0
        if list_address:
            for address in list_address:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_address.insertRow(i)
                self.ui.tablewidget_address.setItem(i,0,chk)
                self.ui.tablewidget_address.setItem(i,1,QTableWidgetItem(address[0]))
                self.ui.tablewidget_address.setItem(i,2,QTableWidgetItem(address[1]))
                self.ui.tablewidget_address.setItem(i,3,QTableWidgetItem(address[2]))
                i=i+1
        
        self.ui.tablewidget_address.resizeColumnsToContents()
        
    def reset_filter(self):
        pyqgis_processing.set_query(self.farmland_table,"")
        
    def filter_farmer(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmer.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_farmer.item(i,0).checkState()==Qt.Checked:
                list_farmers.append(self.ui.tablewidget_farmer.item(i,1).text())
        count=0
        if len(list_farmers)>0:
            for farmer in list_farmers:
                if count==0:
                    query_string=""" "farm_name"= '%s' """ % farmer
                    count+=1
                else:
                    query_string=query_string +  """ or "farm_name"= '%s' """ % farmer
                    count+=1
            
            pyqgis_processing.set_query(self.farmland_table,query_string )
        else:
            pyqgis_processing.show_msgbox(u"対象耕作者を選択してください")
            
    def filter_owner(self):
        list_owners=[]
        row_count=self.ui.tablewidget_owner.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_owner.item(i,0).checkState()==Qt.Checked:
                list_owners.append(self.ui.tablewidget_owner.item(i,1).text())
        count=0
        if len(list_owners)>0:
            for owner in list_owners:
                if count==0:
                    query_string=""" "owner_name"= '%s' """ % owner
                    count+=1
                else:
                    query_string=query_string +  """ or "owner_name"= '%s' """ % owner
                    count+=1
            
            pyqgis_processing.set_query(self.farmland_table,query_string )
        else:
            pyqgis_processing.show_msgbox(u"対象地権者を選択してください")
            
    def filter_address(self):
        list_address=[]
        row_count=self.ui.tablewidget_address.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_address.item(i,0).checkState()==Qt.Checked:
                list_address.append((self.ui.tablewidget_address.item(i,1).text(),
                                     self.ui.tablewidget_address.item(i,2).text(),
                                     self.ui.tablewidget_address.item(i,3).text()))
        count=0
        if len(list_address)>0:
            for address in list_address:
                if count==0:
                    query_string=""" "address1"= '%s' and "address2"= '%s' and "address3"= '%s' """ % address
                    count+=1
                else:
                    query_string=query_string +  """ or "address1"= '%s' and "address2"= '%s' and "address3"= '%s' """ % address
                    count+=1
            
            pyqgis_processing.set_query(self.farmland_table,query_string )
        else:
            pyqgis_processing.show_msgbox(u"対象地域を選択してください")
    
    def populate_tablewidget_farmer(self):
        self.ui.tablewidget_farmer.clear()
        self.ui.tablewidget_farmer.setRowCount(0)
        self.ui.tablewidget_farmer.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_farmer.setColumnCount(len(headers))
        self.ui.tablewidget_farmer.setHorizontalHeaderLabels(headers)
        list_farmers=self.make_farmers_list(self.ui.lineedit_farmer.text())
        #print list_farmer
        i=0
        if list_farmers:
            for farmer in list_farmers:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_farmer.insertRow(i)
                self.ui.tablewidget_farmer.setItem(i,0,chk)
                self.ui.tablewidget_farmer.setItem(i,1,QTableWidgetItem(farmer[0]))
                self.ui.tablewidget_farmer.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[1])))
                i=i+1
        else:
            pyqgis_processing.show_msgbox(u"条件に適合する耕作者が見つかりません")
            return
        #self.sum_area()
        self.ui.tablewidget_farmer.resizeColumnsToContents()
        
    def populate_tablewidget_owner(self):
        self.ui.tablewidget_owner.clear()
        self.ui.tablewidget_owner.setRowCount(0)
        self.ui.tablewidget_owner.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"地権者名",u"面積小計"]
        self.ui.tablewidget_owner.setColumnCount(len(headers))
        self.ui.tablewidget_owner.setHorizontalHeaderLabels(headers)
        list_owners=self.make_owners_list(self.ui.lineedit_owner.text())
        #print list_farmer
        i=0
        if list_owners:
            for owner in list_owners:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_owner.insertRow(i)
                self.ui.tablewidget_owner.setItem(i,0,chk)
                self.ui.tablewidget_owner.setItem(i,1,QTableWidgetItem(owner[0]))
                self.ui.tablewidget_owner.setItem(i,2,QTableWidgetItem("{:,.0f}".format(owner[1])))
                i=i+1
        else:
            pyqgis_processing.show_msgbox(u"条件に適合する耕作者が見つかりません")
            return
        #self.sum_area()
        self.ui.tablewidget_owner.resizeColumnsToContents()
    
    def make_farmers_list(self,search_word):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select farm_name,total(land_area)
                        from farmland_table 
                        where farm_name like ?
                        group by farm_name
                        """


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,('%'+search_word+'%',))
        rows=cursor.fetchall()
        print rows

        return rows
    
    def make_owners_list(self,search_word):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select owner_name,total(land_area)
                        from farmland_table 
                        where owner_name like ?
                        group by owner_name
                        """


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string,('%'+search_word+'%',))
        rows=cursor.fetchall()
        print rows

        return rows
    def make_address_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select address1,address2,address3 from farmland_table group by address1,address2,address3"""
        cursor.execute(sql_string)
        rows=cursor.fetchall()
        print rows

        return rows
    
    def show_attribute_table(self):
        pyqgis_processing.clear_attributetable()
        layer=self.farmland_table
        iface.showAttributeTable(layer)
        
        
        
        
        
    
        