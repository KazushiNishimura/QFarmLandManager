# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_all_select_borrower_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import random
import time
import math



class Dialog(QDialog,Ui_Dialog):


    def __init__(self,dlg):
        QDialog.__init__(self)
        self.dlg=dlg
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.populate_tablewidget_farmer()


        #self.ui.rbtn_all.setChecked(1)


        #self.populate_tablewidget_farmers()
        #self.populate_tablewidget_farmers_area()
        #self.populate_tablewidget_scenario()


        #self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
        #self.connect(self.ui.btn_calc_route, SIGNAL("clicked()"),self.calc_route)
        #self.connect(self.ui.btn_show_route,SIGNAL("clicked()"),self.show_route)
        #self.connect(self.ui.btn_start,SIGNAL("clicked()"),self.start_edit)
        #self.connect(self.ui.btn_select_farmer, SIGNAL("clicked()"),self.select_farmer)
        #self.connect(self.ui.btn_run,SIGNAL("clicked()"),self.run_main_select)
        #self.connect(self.ui.btn_re_calc,SIGNAL("clicked()"),self.re_calc)
        #self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_info_selected)
        #self.connect(self.ui.btn_run,SIGNAL("clicked()"),self.run_planning)
        self.connect(self.ui.btn_select,SIGNAL("clicked()"),self.return_farmers_list)

    def populate_tablewidget_farmer(self):
        self.ui.tablewidget_farmer.clear()
        self.ui.tablewidget_farmer.setRowCount(0)
        self.ui.tablewidget_farmer.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_farmer.setColumnCount(len(headers))
        self.ui.tablewidget_farmer.setHorizontalHeaderLabels(headers)
        list_farmers=self.make_farmers_list()
        #print list_farmer
        i=0
        for farmer in list_farmers:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            flag=False
            for item in self.dlg.list_borrower:
                if farmer[0]==item[0]:
                    flag=True
                    break

            if flag==True:
                chk.setCheckState(Qt.Checked)
            else:
                chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_farmer.insertRow(i)
            self.ui.tablewidget_farmer.setItem(i,0,chk)
            self.ui.tablewidget_farmer.setItem(i,1,QTableWidgetItem(farmer[0]))
            self.ui.tablewidget_farmer.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[1])))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_farmer.resizeColumnsToContents()

    def make_farmers_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select farm_name ,total(land_area)
                        from farmland_table
                        group by farm_name"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows

    def get_list_district(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()

        sql_string="""select district
                        from farmland_table
                        group by district"""


        #sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows


    def return_farmers_list(self):
        self.dlg.list_borrower=[]

        row_count=self.ui.tablewidget_farmer.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmer.item(i,0).checkState()==Qt.Checked:
                self.dlg.list_borrower.append((self.ui.tablewidget_farmer.item(i,1).text(),self.ui.tablewidget_farmer.item(i,1).text()))
                #print self.ui.tablewidget_farmer.item(i,1).text()



        self.close()






