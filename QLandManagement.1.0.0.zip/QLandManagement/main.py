# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic
import os
import shutil
from QLandManagement import pyqgis_processing


# リソース読み込み
try:
  from . import resource
except ImportError:
  pass


# メインクラス
class main:

  # Pythonのクラスを作ったら（多分）必ず要るやつ
  def __init__(self, iface):
    self.iface = iface

  # QGISのメニューに表示するときに呼ばれるやつ
  def initGui(self):
    # 小メニューを作る

    self.start_land_management=QAction(u"メインメニュー",self.iface.mainWindow())
    self.start_land_management.setObjectName("start_land_management")
    self.load_sample_data=QAction(u"サンプルデータ",self.iface.mainWindow())
    self.load_sample_data.setObjectName("load_sample_data")

    # 大メニューを作る
    self.menu = QMenu(self.iface.mainWindow())
    self.menu.setObjectName("QFarmLandManager")
    self.menu.setTitle("QFarmLandManager")
    self.menu.addAction(self.start_land_management)
    self.menu.addAction(self.load_sample_data)

    # 大メニューをメニューバーに挿入する
    menuBar = self.iface.mainWindow().menuBar()
    menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)

    # 小メニューを押したとき実行するよう、トリガーをセット
    QObject.connect(self.start_land_management,SIGNAL("triggered()"),self.run_land_management)
    QObject.connect(self.load_sample_data,SIGNAL("triggered()"),self.load_data)

    #カスタムツールバー
    self.toolbar = self.iface.addToolBar(u"管理ツール")
    # Create actions
    self.someact = QAction(QCoreApplication.translate("main", "My Action"),
                           self.iface.mainWindow())

    # Connect action signals to slots
    self.someact.triggered.connect(self.doSomething)

    # Add actions to the toolbar
    self.toolbar.addAction(self.someact)
     
  def load_data(self):
    
    ret = QMessageBox.information(None, u"確認", u"サンプルデータをセットアップしますか？", QMessageBox.Yes, QMessageBox.No)
    if ret == QMessageBox.Yes:
        folder_path=QFileDialog.getExistingDirectory()
        if folder_path !="":           
            prj_file1=os.path.expanduser('~/.qgis2/python/plugins/QLandManagement/resource/demo.qgs')  
            prj_file2=os.path.expanduser('~/.qgis2/python/plugins/QLandManagement/resource/land_db.sqlite')
            shutil.copy(prj_file1, folder_path+"/demo.qgs")  
            shutil.copy(prj_file2, folder_path+"/land_db.sqlite")  
            pyqgis_processing.show_msgbox(u"セットアップが完了しました。"+ folder_path+"/demo.qgs" +u"から再起動してください")

  def doSomething(self):
        # slot for action
    pass

  # メニューを無効にしたときに呼ばれるやつ
  def unload(self):
    #メニューを消す
    self.menu.deleteLater()

  # メニューでクリックした時、実行されるやつ。処理本体。


  def run_land_management(self):
    #path = os.path.dirname(os.path.abspath(__file__))
    #self.dock = uic.loadUi(os.path.join(path, "dockwidgetui.ui"))
    from land_management_dock import DockWidget
    self.doc=DockWidget(self.iface)
    self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.doc)
    #self.dlg=DockWidget(self.iface)
    #self.dlg.show()


