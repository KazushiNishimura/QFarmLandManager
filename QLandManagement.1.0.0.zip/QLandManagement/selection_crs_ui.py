# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'selection_crs_ui.ui'
#
# Created: Fri Jun 09 15:24:42 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(754, 589)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.btn_cancel = QtGui.QPushButton(Dialog)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.gridLayout.addWidget(self.btn_cancel, 1, 1, 1, 1)
        self.btn_ok = QtGui.QPushButton(Dialog)
        self.btn_ok.setObjectName(_fromUtf8("btn_ok"))
        self.gridLayout.addWidget(self.btn_ok, 1, 0, 1, 1)
        self.scrollArea = QtGui.QScrollArea(Dialog)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, -857, 717, 1477))
        self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
        self.gridLayout_3 = QtGui.QGridLayout(self.scrollAreaWidgetContents)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.rbtn2 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn2.setObjectName(_fromUtf8("rbtn2"))
        self.gridLayout_2.addWidget(self.rbtn2, 1, 0, 1, 1)
        self.textBrowser_16 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_16.setObjectName(_fromUtf8("textBrowser_16"))
        self.gridLayout_2.addWidget(self.textBrowser_16, 15, 1, 1, 1)
        self.textBrowser_4 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_4.setObjectName(_fromUtf8("textBrowser_4"))
        self.gridLayout_2.addWidget(self.textBrowser_4, 3, 1, 1, 1)
        self.textBrowser_18 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_18.setObjectName(_fromUtf8("textBrowser_18"))
        self.gridLayout_2.addWidget(self.textBrowser_18, 17, 1, 1, 1)
        self.textBrowser_2 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_2.setObjectName(_fromUtf8("textBrowser_2"))
        self.gridLayout_2.addWidget(self.textBrowser_2, 1, 1, 1, 1)
        self.textBrowser_17 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_17.setObjectName(_fromUtf8("textBrowser_17"))
        self.gridLayout_2.addWidget(self.textBrowser_17, 16, 1, 1, 1)
        self.rbtn1 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn1.setChecked(True)
        self.rbtn1.setObjectName(_fromUtf8("rbtn1"))
        self.gridLayout_2.addWidget(self.rbtn1, 0, 0, 1, 1)
        self.textBrowser_15 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_15.setObjectName(_fromUtf8("textBrowser_15"))
        self.gridLayout_2.addWidget(self.textBrowser_15, 14, 1, 1, 1)
        self.textBrowser_14 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_14.setObjectName(_fromUtf8("textBrowser_14"))
        self.gridLayout_2.addWidget(self.textBrowser_14, 13, 1, 1, 1)
        self.textBrowser_3 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_3.setObjectName(_fromUtf8("textBrowser_3"))
        self.gridLayout_2.addWidget(self.textBrowser_3, 2, 1, 1, 1)
        self.rbtn3 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn3.setObjectName(_fromUtf8("rbtn3"))
        self.gridLayout_2.addWidget(self.rbtn3, 2, 0, 1, 1)
        self.textBrowser_6 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_6.setObjectName(_fromUtf8("textBrowser_6"))
        self.gridLayout_2.addWidget(self.textBrowser_6, 5, 1, 1, 1)
        self.textBrowser_5 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_5.setObjectName(_fromUtf8("textBrowser_5"))
        self.gridLayout_2.addWidget(self.textBrowser_5, 4, 1, 1, 1)
        self.textBrowser = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser.setFrameShape(QtGui.QFrame.Panel)
        self.textBrowser.setFrameShadow(QtGui.QFrame.Raised)
        self.textBrowser.setObjectName(_fromUtf8("textBrowser"))
        self.gridLayout_2.addWidget(self.textBrowser, 0, 1, 1, 1)
        self.textBrowser_7 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_7.setObjectName(_fromUtf8("textBrowser_7"))
        self.gridLayout_2.addWidget(self.textBrowser_7, 6, 1, 1, 1)
        self.rbtn4 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn4.setObjectName(_fromUtf8("rbtn4"))
        self.gridLayout_2.addWidget(self.rbtn4, 3, 0, 1, 1)
        self.rbtn5 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn5.setObjectName(_fromUtf8("rbtn5"))
        self.gridLayout_2.addWidget(self.rbtn5, 4, 0, 1, 1)
        self.rbtn6 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn6.setObjectName(_fromUtf8("rbtn6"))
        self.gridLayout_2.addWidget(self.rbtn6, 5, 0, 1, 1)
        self.rbtn7 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn7.setObjectName(_fromUtf8("rbtn7"))
        self.gridLayout_2.addWidget(self.rbtn7, 6, 0, 1, 1)
        self.textBrowser_8 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_8.setObjectName(_fromUtf8("textBrowser_8"))
        self.gridLayout_2.addWidget(self.textBrowser_8, 7, 1, 1, 1)
        self.textBrowser_9 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_9.setObjectName(_fromUtf8("textBrowser_9"))
        self.gridLayout_2.addWidget(self.textBrowser_9, 8, 1, 1, 1)
        self.textBrowser_10 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_10.setObjectName(_fromUtf8("textBrowser_10"))
        self.gridLayout_2.addWidget(self.textBrowser_10, 9, 1, 1, 1)
        self.textBrowser_11 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_11.setObjectName(_fromUtf8("textBrowser_11"))
        self.gridLayout_2.addWidget(self.textBrowser_11, 10, 1, 1, 1)
        self.textBrowser_12 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_12.setObjectName(_fromUtf8("textBrowser_12"))
        self.gridLayout_2.addWidget(self.textBrowser_12, 11, 1, 1, 1)
        self.textBrowser_13 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_13.setObjectName(_fromUtf8("textBrowser_13"))
        self.gridLayout_2.addWidget(self.textBrowser_13, 12, 1, 1, 1)
        self.textBrowser_19 = QtGui.QTextBrowser(self.scrollAreaWidgetContents)
        self.textBrowser_19.setObjectName(_fromUtf8("textBrowser_19"))
        self.gridLayout_2.addWidget(self.textBrowser_19, 18, 1, 1, 1)
        self.rbtn8 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn8.setObjectName(_fromUtf8("rbtn8"))
        self.gridLayout_2.addWidget(self.rbtn8, 7, 0, 1, 1)
        self.rbtn9 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn9.setObjectName(_fromUtf8("rbtn9"))
        self.gridLayout_2.addWidget(self.rbtn9, 8, 0, 1, 1)
        self.rbtn10 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn10.setObjectName(_fromUtf8("rbtn10"))
        self.gridLayout_2.addWidget(self.rbtn10, 9, 0, 1, 1)
        self.rbtn11 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn11.setObjectName(_fromUtf8("rbtn11"))
        self.gridLayout_2.addWidget(self.rbtn11, 10, 0, 1, 1)
        self.rbtn12 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn12.setObjectName(_fromUtf8("rbtn12"))
        self.gridLayout_2.addWidget(self.rbtn12, 11, 0, 1, 1)
        self.rbtn13 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn13.setObjectName(_fromUtf8("rbtn13"))
        self.gridLayout_2.addWidget(self.rbtn13, 12, 0, 1, 1)
        self.rbtn14 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn14.setObjectName(_fromUtf8("rbtn14"))
        self.gridLayout_2.addWidget(self.rbtn14, 13, 0, 1, 1)
        self.rbtn15 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn15.setObjectName(_fromUtf8("rbtn15"))
        self.gridLayout_2.addWidget(self.rbtn15, 14, 0, 1, 1)
        self.rbtn16 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn16.setObjectName(_fromUtf8("rbtn16"))
        self.gridLayout_2.addWidget(self.rbtn16, 15, 0, 1, 1)
        self.rbtn17 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn17.setObjectName(_fromUtf8("rbtn17"))
        self.gridLayout_2.addWidget(self.rbtn17, 16, 0, 1, 1)
        self.rbtn18 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn18.setObjectName(_fromUtf8("rbtn18"))
        self.gridLayout_2.addWidget(self.rbtn18, 17, 0, 1, 1)
        self.rbtn19 = QtGui.QRadioButton(self.scrollAreaWidgetContents)
        self.rbtn19.setObjectName(_fromUtf8("rbtn19"))
        self.gridLayout_2.addWidget(self.rbtn19, 18, 0, 1, 1)
        self.gridLayout_3.addLayout(self.gridLayout_2, 0, 0, 1, 1)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.gridLayout.addWidget(self.scrollArea, 0, 0, 1, 2)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "地域の選択", None))
        self.btn_cancel.setText(_translate("Dialog", "キャンセル", None))
        self.btn_ok.setText(_translate("Dialog", "決定", None))
        self.rbtn2.setText(_translate("Dialog", "Ⅱ系", None))
        self.textBrowser_16.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">沖縄県のうち東経126度から西である区域</span></p></body></html>", None))
        self.textBrowser_4.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">香川県 愛媛県 徳島県 高知県</span></p></body></html>", None))
        self.textBrowser_18.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">東京都のうち北緯28度から南であり、かつ東経140度30分から西である区域</span></p></body></html>", None))
        self.textBrowser_2.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">福岡県 佐賀県 熊本県 大分県 宮崎県 鹿児島県（I系に規定する区域を除く。)</span></p></body></html>", None))
        self.textBrowser_17.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">沖縄県のうち東経130度から東である区域</span></p></body></html>", None))
        self.rbtn1.setText(_translate("Dialog", "Ⅰ系", None))
        self.textBrowser_15.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">沖縄県のうち東経126度から東であり、かつ東経130度から西である区域</span></p></body></html>", None))
        self.textBrowser_14.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">東京都のうち北緯28度から南であり、かつ東経140度30分から東であり東経143度から西である区域</span></p></body></html>", None))
        self.textBrowser_3.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">山口県 島根県 広島県</span></p></body></html>", None))
        self.rbtn3.setText(_translate("Dialog", "Ⅲ系", None))
        self.textBrowser_6.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">京都府 大阪府 福井県 滋賀県 三重県 奈良県 和歌山県</span></p></body></html>", None))
        self.textBrowser_5.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">兵庫県 鳥取県 岡山県</span></p></body></html>", None))
        self.textBrowser.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">長崎県 鹿児島県のうち北方北緯32度南方北緯27度西方東経128度18分東方東経130度を境界線とする区域内（奄美群島は東経130度13分までを含む。)にあるすべての島、小島、環礁及び岩礁</span></p></body></html>", None))
        self.textBrowser_7.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">石川県 富山県 岐阜県 愛知県</span></p></body></html>", None))
        self.rbtn4.setText(_translate("Dialog", "Ⅳ系", None))
        self.rbtn5.setText(_translate("Dialog", "Ⅴ系", None))
        self.rbtn6.setText(_translate("Dialog", "Ⅵ系", None))
        self.rbtn7.setText(_translate("Dialog", "Ⅶ系", None))
        self.textBrowser_8.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">新潟県 長野県 山梨県 静岡県</span></p></body></html>", None))
        self.textBrowser_9.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">東京都（XIV系、XVIII系及びXIX系に規定する区域を除く。) 福島県 栃木県 茨城県 埼玉県 千葉県 群馬県 神奈川県</span></p></body></html>", None))
        self.textBrowser_10.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">青森県 秋田県 山形県 岩手県 宮城県</span></p></body></html>", None))
        self.textBrowser_11.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">小樽市 函館市 伊達市 北斗市 北海道後志総合振興局の所管区域 北海道胆振総合振興局の所管区域のうち豊浦町、壮瞥町及び洞爺湖町 北海道渡島総合振興局の所管区域 北海道檜山振興局の所管区域</span></p></body></html>", None))
        self.textBrowser_12.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">北海道（XI系及びXIII系に規定する区域を除く。）</span></p></body></html>", None))
        self.textBrowser_13.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; font-size:10pt; color:#000000; background-color:#ffffff;\">北見市 帯広市 釧路市 網走市 根室市 北海道オホーツク総合振興局の所管区域のうち美幌町、津別町、斜里町、清里町、小清水町、訓子府町、置戸町、佐呂間町及び大空町 北海道十勝総合振興局の所管区域 北海道釧路総合振興局の所管区域 北海道根室振興局の所管区域</span></p></body></html>", None))
        self.textBrowser_19.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS UI Gothic\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Verdana,MS UI Gothic,Osaka\'; color:#000000; background-color:#ffffff;\">東京都のうち北緯28度から南であり、かつ東経143度から東である区域</span></p></body></html>", None))
        self.rbtn8.setText(_translate("Dialog", "Ⅷ系", None))
        self.rbtn9.setText(_translate("Dialog", "Ⅸ系", None))
        self.rbtn10.setText(_translate("Dialog", "Ⅹ系", None))
        self.rbtn11.setText(_translate("Dialog", "Ⅺ系", None))
        self.rbtn12.setText(_translate("Dialog", "Ⅻ系", None))
        self.rbtn13.setText(_translate("Dialog", "ⅩⅢ系", None))
        self.rbtn14.setText(_translate("Dialog", "ⅩⅣ系", None))
        self.rbtn15.setText(_translate("Dialog", "ⅩⅤ系", None))
        self.rbtn16.setText(_translate("Dialog", "ⅩⅥ系", None))
        self.rbtn17.setText(_translate("Dialog", "ⅩⅦ系", None))
        self.rbtn18.setText(_translate("Dialog", "ⅩⅧ系", None))
        self.rbtn19.setText(_translate("Dialog", "ⅩⅨ系", None))

