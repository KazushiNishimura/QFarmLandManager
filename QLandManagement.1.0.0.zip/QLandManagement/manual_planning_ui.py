# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_manual_planning_ui.ui'
#
# Created: Wed May 23 13:50:39 2018
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(431, 640)
        self.verticalLayout_3 = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.radioButton = QtGui.QRadioButton(self.groupBox)
        self.radioButton.setObjectName(_fromUtf8("radioButton"))
        self.verticalLayout.addWidget(self.radioButton)
        self.lineEdit = QtGui.QLineEdit(self.groupBox)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.verticalLayout.addWidget(self.lineEdit)
        self.radioButton_2 = QtGui.QRadioButton(self.groupBox)
        self.radioButton_2.setObjectName(_fromUtf8("radioButton_2"))
        self.verticalLayout.addWidget(self.radioButton_2)
        self.tableWidget = QtGui.QTableWidget(self.groupBox)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtGui.QPushButton(self.groupBox)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.verticalLayout.addWidget(self.pushButton)
        self.verticalLayout_3.addWidget(self.groupBox)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tablewidget_farmers = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_farmers.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tablewidget_farmers.setObjectName(_fromUtf8("tablewidget_farmers"))
        self.tablewidget_farmers.setColumnCount(0)
        self.tablewidget_farmers.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_farmers)
        self.btn_renderer = QtGui.QPushButton(self.groupBox_2)
        self.btn_renderer.setObjectName(_fromUtf8("btn_renderer"))
        self.verticalLayout_2.addWidget(self.btn_renderer)
        self.verticalLayout_3.addWidget(self.groupBox_2)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox_3)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.tablewidget_farmers_area = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_farmers_area.setObjectName(_fromUtf8("tablewidget_farmers_area"))
        self.tablewidget_farmers_area.setColumnCount(0)
        self.tablewidget_farmers_area.setRowCount(0)
        self.horizontalLayout_2.addWidget(self.tablewidget_farmers_area)
        self.verticalLayout_3.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.groupBox_4)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.tablewidget_scenario = QtGui.QTableWidget(self.groupBox_4)
        self.tablewidget_scenario.setObjectName(_fromUtf8("tablewidget_scenario"))
        self.tablewidget_scenario.setColumnCount(0)
        self.tablewidget_scenario.setRowCount(0)
        self.verticalLayout_4.addWidget(self.tablewidget_scenario)
        self.verticalLayout_3.addWidget(self.groupBox_4)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "手動土地利用調整", None))
        self.groupBox.setTitle(_translate("Dialog", "土地利用調整案の作成・選択", None))
        self.radioButton.setText(_translate("Dialog", "新規に土地利用調整案を作成する", None))
        self.radioButton_2.setText(_translate("Dialog", "既存の土地利用調整案を修正する", None))
        self.pushButton.setText(_translate("Dialog", "作成開始", None))
        self.groupBox_2.setTitle(_translate("Dialog", "耕作者の選択", None))
        self.btn_renderer.setText(_translate("Dialog", "決定", None))
        self.groupBox_3.setTitle(_translate("Dialog", "現状の集計結果", None))
        self.groupBox_4.setTitle(_translate("Dialog", "調整案の集計結果", None))

