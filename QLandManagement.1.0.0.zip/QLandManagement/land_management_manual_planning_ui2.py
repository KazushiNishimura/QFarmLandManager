# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_manual_planning_ui2.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(424, 645)
        self.gridLayout_3 = QtGui.QGridLayout(Dialog)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tablewidget_farmers_area = QtGui.QTableWidget(self.groupBox_4)
        self.tablewidget_farmers_area.setObjectName(_fromUtf8("tablewidget_farmers_area"))
        self.tablewidget_farmers_area.setColumnCount(0)
        self.tablewidget_farmers_area.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_farmers_area, 0, 0, 1, 2)
        self.groupBox_5 = QtGui.QGroupBox(self.groupBox_4)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_5)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.groupBox_5)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.cmbbox_farm_name = QtGui.QComboBox(self.groupBox_5)
        self.cmbbox_farm_name.setObjectName(_fromUtf8("cmbbox_farm_name"))
        self.gridLayout.addWidget(self.cmbbox_farm_name, 0, 1, 1, 1)
        self.btn_update = QtGui.QPushButton(self.groupBox_5)
        self.btn_update.setObjectName(_fromUtf8("btn_update"))
        self.gridLayout.addWidget(self.btn_update, 1, 1, 1, 1)
        self.gridLayout_2.addWidget(self.groupBox_5, 1, 0, 1, 2)
        self.gridLayout_3.addWidget(self.groupBox_4, 2, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.rbtn_new = QtGui.QRadioButton(self.groupBox)
        self.rbtn_new.setObjectName(_fromUtf8("rbtn_new"))
        self.verticalLayout.addWidget(self.rbtn_new)
        self.lineedit_scenario_name = QtGui.QLineEdit(self.groupBox)
        self.lineedit_scenario_name.setObjectName(_fromUtf8("lineedit_scenario_name"))
        self.verticalLayout.addWidget(self.lineedit_scenario_name)
        self.rbtn_update = QtGui.QRadioButton(self.groupBox)
        self.rbtn_update.setObjectName(_fromUtf8("rbtn_update"))
        self.verticalLayout.addWidget(self.rbtn_update)
        self.tablewidget_scenario = QtGui.QTableWidget(self.groupBox)
        self.tablewidget_scenario.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_scenario.setObjectName(_fromUtf8("tablewidget_scenario"))
        self.tablewidget_scenario.setColumnCount(0)
        self.tablewidget_scenario.setRowCount(0)
        self.verticalLayout.addWidget(self.tablewidget_scenario)
        self.btn_start = QtGui.QPushButton(self.groupBox)
        self.btn_start.setObjectName(_fromUtf8("btn_start"))
        self.verticalLayout.addWidget(self.btn_start)
        self.gridLayout_3.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.lineedit_csv = QtGui.QLineEdit(self.groupBox_2)
        self.lineedit_csv.setObjectName(_fromUtf8("lineedit_csv"))
        self.gridLayout_4.addWidget(self.lineedit_csv, 0, 1, 1, 1)
        self.tablewidget_farmers = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_farmers.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tablewidget_farmers.setObjectName(_fromUtf8("tablewidget_farmers"))
        self.tablewidget_farmers.setColumnCount(0)
        self.tablewidget_farmers.setRowCount(0)
        self.gridLayout_4.addWidget(self.tablewidget_farmers, 1, 0, 1, 2)
        self.btn_renderer = QtGui.QPushButton(self.groupBox_2)
        self.btn_renderer.setObjectName(_fromUtf8("btn_renderer"))
        self.gridLayout_4.addWidget(self.btn_renderer, 2, 0, 1, 2)
        self.btn_csv = QtGui.QPushButton(self.groupBox_2)
        self.btn_csv.setObjectName(_fromUtf8("btn_csv"))
        self.gridLayout_4.addWidget(self.btn_csv, 0, 0, 1, 1)
        self.gridLayout_3.addWidget(self.groupBox_2, 1, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "簡易土地利用調整", None))
        self.groupBox_4.setTitle(_translate("Dialog", "調整案の面積集計", None))
        self.groupBox_5.setTitle(_translate("Dialog", "選択圃場の耕作者の登録", None))
        self.label.setText(_translate("Dialog", "入力耕作者", None))
        self.btn_update.setText(_translate("Dialog", "耕作者の登録", None))
        self.groupBox.setTitle(_translate("Dialog", "土地利用調整案の作成・選択", None))
        self.rbtn_new.setText(_translate("Dialog", "新規に土地利用調整案を作成する", None))
        self.rbtn_update.setText(_translate("Dialog", "既存の土地利用調整案を修正する", None))
        self.btn_start.setText(_translate("Dialog", "作成開始", None))
        self.groupBox_2.setTitle(_translate("Dialog", "耕作者の選択", None))
        self.btn_renderer.setText(_translate("Dialog", "決定", None))
        self.btn_csv.setText(_translate("Dialog", "目標設定ファイルの指定", None))

