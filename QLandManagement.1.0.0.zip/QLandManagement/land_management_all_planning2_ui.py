# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'land_management_all_planning2_ui.ui'
#
# Created: Mon Jul 02 14:06:38 2018
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(519, 728)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.lineedit_scenario = QtGui.QLineEdit(self.groupBox)
        self.lineedit_scenario.setObjectName(_fromUtf8("lineedit_scenario"))
        self.verticalLayout_3.addWidget(self.lineedit_scenario)
        self.verticalLayout.addWidget(self.groupBox)
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_5)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 4, 0, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 1, 0, 1, 1)
        self.tablewidget_configuration = QtGui.QTableWidget(self.groupBox_5)
        self.tablewidget_configuration.setObjectName(_fromUtf8("tablewidget_configuration"))
        self.tablewidget_configuration.setColumnCount(0)
        self.tablewidget_configuration.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_configuration, 0, 0, 1, 3)
        self.tablewidget_lender = QtGui.QTableWidget(self.groupBox_5)
        self.tablewidget_lender.setObjectName(_fromUtf8("tablewidget_lender"))
        self.tablewidget_lender.setColumnCount(0)
        self.tablewidget_lender.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_lender, 3, 0, 1, 3)
        self.btn_select_borrower = QtGui.QPushButton(self.groupBox_5)
        self.btn_select_borrower.setObjectName(_fromUtf8("btn_select_borrower"))
        self.gridLayout.addWidget(self.btn_select_borrower, 1, 1, 1, 1)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem2, 6, 0, 1, 1)
        self.tablewidget_exclusion = QtGui.QTableWidget(self.groupBox_5)
        self.tablewidget_exclusion.setObjectName(_fromUtf8("tablewidget_exclusion"))
        self.tablewidget_exclusion.setColumnCount(0)
        self.tablewidget_exclusion.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_exclusion, 5, 0, 1, 3)
        self.btn_select_lender = QtGui.QPushButton(self.groupBox_5)
        self.btn_select_lender.setObjectName(_fromUtf8("btn_select_lender"))
        self.gridLayout.addWidget(self.btn_select_lender, 4, 1, 1, 2)
        self.btn_select_exclusion = QtGui.QPushButton(self.groupBox_5)
        self.btn_select_exclusion.setObjectName(_fromUtf8("btn_select_exclusion"))
        self.gridLayout.addWidget(self.btn_select_exclusion, 6, 1, 1, 2)
        self.verticalLayout.addWidget(self.groupBox_5)
        self.btn_run = QtGui.QPushButton(Dialog)
        self.btn_run.setObjectName(_fromUtf8("btn_run"))
        self.verticalLayout.addWidget(self.btn_run)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.groupBox_3 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox_3)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tablewidget_farmers = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_farmers.setSelectionMode(QtGui.QAbstractItemView.NoSelection)
        self.tablewidget_farmers.setObjectName(_fromUtf8("tablewidget_farmers"))
        self.tablewidget_farmers.setColumnCount(0)
        self.tablewidget_farmers.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_farmers)
        self.btn_renderer = QtGui.QPushButton(self.groupBox_3)
        self.btn_renderer.setObjectName(_fromUtf8("btn_renderer"))
        self.verticalLayout_2.addWidget(self.btn_renderer)
        self.verticalLayout_4.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(self.groupBox_2)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox_4)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.tablewidget_farmers_area = QtGui.QTableWidget(self.groupBox_4)
        self.tablewidget_farmers_area.setObjectName(_fromUtf8("tablewidget_farmers_area"))
        self.tablewidget_farmers_area.setColumnCount(0)
        self.tablewidget_farmers_area.setRowCount(0)
        self.horizontalLayout_2.addWidget(self.tablewidget_farmers_area)
        self.verticalLayout_4.addWidget(self.groupBox_4)
        self.verticalLayout.addWidget(self.groupBox_2)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "全域土地利用調整", None))
        self.groupBox.setTitle(_translate("Dialog", "土地利用調整案の名前", None))
        self.groupBox_5.setTitle(_translate("Dialog", "担い手、貸し出し希望者、調整除外設定", None))
        self.btn_select_borrower.setText(_translate("Dialog", "担い手追加", None))
        self.btn_select_lender.setText(_translate("Dialog", "貸出希望者設定", None))
        self.btn_select_exclusion.setText(_translate("Dialog", "除外者設定", None))
        self.btn_run.setText(_translate("Dialog", "調整案の作成", None))
        self.groupBox_2.setTitle(_translate("Dialog", "調整案の表示", None))
        self.groupBox_3.setTitle(_translate("Dialog", "耕作者一覧", None))
        self.btn_renderer.setText(_translate("Dialog", "表示の更新", None))
        self.groupBox_4.setTitle(_translate("Dialog", "耕作者・エリア毎集計結果", None))

