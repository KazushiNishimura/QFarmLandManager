# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from land_management_renderer_current_ui import Ui_Dialog
from QLandManagement import pyqgis_processing
import sqlite3
import random
import time
import math



class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)


        #self.ui.rbtn_all.setChecked(1)


        self.populate_tablewidget_farmers()
        #self.populate_tablewidget_farmers_area()


        self.connect(self.ui.btn_renderer, SIGNAL("clicked()"),self.renderer)
        #self.connect(self.ui.btn_calc_route, SIGNAL("clicked()"),self.calc_route)
        self.connect(self.ui.btn_show_route,SIGNAL("clicked()"),self.show_route)
        self.connect(self.ui.btn_show_scattered,SIGNAL("clicked()"),self.show_scattered)


    def populate_tablewidget_farmers(self):
        self.ui.tablewidget_farmers.clear()
        self.ui.tablewidget_farmers.setRowCount(0)
        self.ui.tablewidget_farmers.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"耕作者名",u"面積小計"]
        self.ui.tablewidget_farmers.setColumnCount(len(headers))
        self.ui.tablewidget_farmers.setHorizontalHeaderLabels(headers)
        list_farmers=self.make_farmers_list()
        #print list_farmer
        i=0
        for farmer in list_farmers:
            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            #print farmer[0]
            #print farmer[1]
            self.ui.tablewidget_farmers.insertRow(i)
            self.ui.tablewidget_farmers.setItem(i,0,chk)
            self.ui.tablewidget_farmers.setItem(i,1,QTableWidgetItem(farmer[0]))
            self.ui.tablewidget_farmers.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[1])))
            i=i+1
        #self.sum_area()
        self.ui.tablewidget_farmers.resizeColumnsToContents()

    def show_scattered(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmers.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_farmers.item(i,0).checkState()==Qt.Checked:
                list_farmers.append((self.ui.tablewidget_farmers.item(i,1).text()))
        self.populate_tablewidget_farmers_area(list_farmers)

    def populate_tablewidget_farmers_area(self,farmers_list):

        self.ui.tablewidget_farmers_area.clear()
        self.ui.tablewidget_farmers_area.setSortingEnabled(True)
        self.ui.tablewidget_farmers_area.setRowCount(0)
        headers=[u"耕作者名",u"エリア",u"面積小計",u"圃場分散度"]
        self.ui.tablewidget_farmers_area.setColumnCount(len(headers))
        self.ui.tablewidget_farmers_area.setHorizontalHeaderLabels(headers)
        list_farmers_area=self.make_farmers_area_list()
        #print list_farmer

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'圃場分散度計算中')
        max = len(list_farmers_area)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        i=0
        for farmer in list_farmers_area:
            pbar.setValue(process_counter)
            if farmer[0] in farmers_list:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_farmers_area.insertRow(i)
                self.ui.tablewidget_farmers_area.setItem(i,0,QTableWidgetItem(farmer[0]))
                self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem(farmer[1]))
                self.ui.tablewidget_farmers_area.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[2])))
                self.ui.tablewidget_farmers_area.setItem(i,3,QTableWidgetItem("{:,.0f}".format(self.calc_length(farmer[0], farmer[1], farmer[2]))))
                i=i+1
            process_counter=process_counter+1
        #self.sum_area()
        self.ui.tablewidget_farmers_area.resizeColumnsToContents()

    def populate_tablewidget_farmers_area_not_scattered(self,farmers_list):

        self.ui.tablewidget_farmers_area.clear()
        self.ui.tablewidget_farmers_area.setSortingEnabled(True)
        self.ui.tablewidget_farmers_area.setRowCount(0)
        headers=[u"耕作者名",u"エリア",u"面積小計",u"圃場分散度"]
        self.ui.tablewidget_farmers_area.setColumnCount(len(headers))
        self.ui.tablewidget_farmers_area.setHorizontalHeaderLabels(headers)
        list_farmers_area=self.make_farmers_area_list()
        #print list_farmer

#         widget = QWidget()
#         widget.setGeometry(100, 100, 250, 100)
#         widget.setWindowTitle(u'圃場分散度計算中')
#         max = len(list_farmers_area)
#         pbar = QProgressBar(widget)
#         pbar.setGeometry(25, 40, 200, 25)
#         pbar.setRange(0, max)
#         widget.show()
#         widget.raise_()
#         process_counter=1
        i=0
        for farmer in list_farmers_area:
            #pbar.setValue(process_counter)
            if farmer[0] in farmers_list:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                #print farmer[0]
                #print farmer[1]
                self.ui.tablewidget_farmers_area.insertRow(i)
                self.ui.tablewidget_farmers_area.setItem(i,0,QTableWidgetItem(farmer[0]))
                self.ui.tablewidget_farmers_area.setItem(i,1,QTableWidgetItem(farmer[1]))
                self.ui.tablewidget_farmers_area.setItem(i,2,QTableWidgetItem("{:,.0f}".format(farmer[2])))
                #self.ui.tablewidget_farmers_area.setItem(i,3,QTableWidgetItem("{:,.0f}".format(self.calc_length(farmer[0], farmer[1], farmer[2]))))
                i=i+1
            #process_counter=process_counter+1
        #self.sum_area()
        self.ui.tablewidget_farmers_area.resizeColumnsToContents()

    def make_farmers_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql_string="select farm_name ,total(land_area) from farmland_table group by farm_name"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows

    def make_farmers_area_list(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        cursor=db.cursor()
        sql_string="select farm_name,district,total(land_area) from farmland_table group by farm_name,district"
        cursor.execute(sql_string)
        rows=cursor.fetchall()

        return rows

    def renderer(self):
        list_farmers=[]
        row_count=self.ui.tablewidget_farmers.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_farmers.item(i,0).checkState()==Qt.Checked:
                list_farmers.append((self.ui.tablewidget_farmers.item(i,1).text()))

        list_rule=[]
        for farmer in list_farmers:
            label_string=   farmer
            query_string= '\"farm_name\" ='+ '\''+ farmer +'\' '
            list_rule.append([label_string,query_string])

        farmland_table=pyqgis_processing.get_farmland_table()
        pyqgis_processing.renderer_map1(farmland_table, list_rule)
        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()

        #圃場分散度の計算に時間がかかるので、デフォルトでは色分け表示のみ
        #self.populate_tablewidget_farmers_area(list_farmers)
        self.populate_tablewidget_farmers_area_not_scattered(list_farmers)


    def calc_route(self):
        #print u"実行"
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        #land_list=[]
        #試験的に耕作者Aで実行
#         for feature in farmland_table.getFeatures():
#             if feature[feature.fieldNameIndex('farm_name')] ==u"法人A":
#                 land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#         best_route=run_simple_tsp(land_list)

        #テーブルでチェックの入ってる耕作者を取得
        list_farmers_area=[]
        row_count=self.ui.tablewidget_farmers_area.rowCount()
        for i in range(row_count):
            list_farmers_area.append([self.ui.tablewidget_farmers_area.item(i,0).text(),self.ui.tablewidget_farmers_area.item(i,1).text()])

        #単一耕作者テスト用
#         qpoint=[]
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         #memlayer=QgsVectorLayer('LineString','Line_subdistrict','memory')
#         crs = farmland_table.crs().authid()#toWkt()
#         memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_test','memory')
#         #memlayer.setCrs(layer1.crs(),True)
#         mempr=memlayer.dataProvider()
#         mempr.addFeatures([f])
#         memlayer.updateExtents()
#         QgsMapLayerRegistry.instance().addMapLayers([memlayer])
#         geom = f.geometry()
#         print "Length:", geom.length()

        #リストの耕作者の経路を全て計算
        for farmer_area in list_farmers_area:
            land_list=[]
            for feature in farmland_table.getFeatures():
                if feature[feature.fieldNameIndex('farm_name')] ==farmer_area[0]:
                    if feature[feature.fieldNameIndex('district')] ==farmer_area[1]:
                        land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
            best_route=run_simple_tsp(land_list)
            qpoint=[]

            for point in best_route:
                qpoint.append(QgsPoint(float(point[2]),float(point[3])))

            line=QgsGeometry.fromPolyline(qpoint)
            f=QgsFeature()
            f.setGeometry(line)
            crs = farmland_table.crs().authid()#toWkt()
            memlayer=QgsVectorLayer("LineString?crs=" + crs,u'経路_'+farmer_area[0]+'_'+farmer_area[1],'memory')
            mempr=memlayer.dataProvider()
            mempr.addFeatures([f])
            memlayer.updateExtents()
            QgsMapLayerRegistry.instance().addMapLayers([memlayer])
            geom = f.geometry()
            print "Length:", geom.length()

#         #リストの耕作者の重心からの距離を全て計算
#         for farmer_area in list_farmers_area:
#             land_list=[]
#             distance_sum=0
#             crs = farmland_table.crs().authid()#toWkt()
#             memlayer=QgsVectorLayer("LineString?crs=" + crs,u'重心からの距離_'+farmer_area[0]+'_'+farmer_area[1],'memory')
#             mempr=memlayer.dataProvider()
#             for feature in farmland_table.getFeatures():
#                 if feature[feature.fieldNameIndex('farm_name')] ==farmer_area[0]:
#                     if feature[feature.fieldNameIndex('district')] ==farmer_area[1]:
#                         land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#
#             centroid_x=sum([land[0] for land in land_list])/len(land_list)
#             centroid_y=sum([land[1] for land in land_list])/len(land_list)
#
#
#             #重心からの平均距離を算出
#             for land in land_list:
#
#                 distance_x = abs(centroid_x - land[0])
#                 distance_y = abs(centroid_y - land[1])
#                 distance = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
#                 distance_sum=distance_sum+distance
#
#
#             for point in land_list:
#                 f=QgsFeature()
#                 qpoint=[]
#                 qpoint.append(QgsPoint(float(point[0]),float(point[1])))
#                 qpoint.append(QgsPoint(centroid_x,centroid_y))
#                 line=QgsGeometry.fromPolyline(qpoint)
#                 f.setGeometry(line)
#
#                 mempr.addFeatures([f])
#                 memlayer.updateExtents()
#             QgsMapLayerRegistry.instance().addMapLayers([memlayer])
#
#             print distance_sum/len(land_list)



    def calc_length(self,farm_name,district,area):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('farm_name')] ==farm_name:
                if feature[feature.fieldNameIndex('district')] ==district:
                    land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)

        dist=0
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"land_db.sqlite")
        sql_string=""" select  dist from dist_table where id_from=? and id_to=?"""

        for i in xrange(0,len(best_route)-2):
            land_from=best_route[i]
            land_to=best_route[i+1]
            id_from=land_from[1]
            id_to=land_to[1]
            query_row=(id_from,id_to)
            cursor=db.cursor()
            cursor.execute(sql_string,query_row)
            row=cursor.fetchone()
            if row is None:
                distance_x = abs(land_from[2]-land_to[2])
                distance_y = abs(land_from[3]-land_to[3])
                dist_part = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
                dist=dist+dist_part

        return dist/area*1000


#         qpoint=[]
#
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         crs = farmland_table.crs().authid()#toWkt()
# #         memlayer=QgsVectorLayer("LineString?crs=" + crs,u'経路_'+farmer_area[0]+'_'+farmer_area[1],'memory')
# #         mempr=memlayer.dataProvider()
# #         mempr.addFeatures([f])
# #         memlayer.updateExtents()
#         #QgsMapLayerRegistry.instance().addMapLayers([memlayer])
#         geom = f.geometry()
#         return geom.length()/area*1000

    def create_route(self,farm_name,district):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('farm_name')] ==farm_name:
                if feature[feature.fieldNameIndex('district')] ==district:
                    land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)
        qpoint=[]

        for point in best_route:
            qpoint.append(QgsPoint(float(point[2]),float(point[3])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        crs = farmland_table.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,u'経路_'+farm_name+'_'+district,'memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])

    def show_route(self):
        from land_management_tsp1 import run_simple_tsp
        farmland_table=pyqgis_processing.get_farmland_table()
        list_farmers_area=[]
        row_count=self.ui.tablewidget_farmers_area.rowCount()
        for i in range(row_count):
            list_farmers_area.append([self.ui.tablewidget_farmers_area.item(i,0).text(),self.ui.tablewidget_farmers_area.item(i,1).text()])

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'ルート探索中')
        max = len(list_farmers_area)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)
        widget.show()
        widget.raise_()
        process_counter=1
        for farmer_area in list_farmers_area:
            self.create_route(farmer_area[0], farmer_area[1])
            process_counter=process_counter+1















